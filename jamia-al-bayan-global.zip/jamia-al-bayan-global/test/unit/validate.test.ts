import test from 'node:test';
import assert from 'node:assert/strict';
import { generateTempPassword, isStatus, loginEmailFor, normaliseCode, originAllowed, validateCreateUser } from '../../netlify/functions/_lib/validate';

const student = { role: 'student', code: 's-1001', displayName: 'Aisha R.', email: '', language: 'bn',
  student: { track: 'qaida', level: 'L1', teacherId: 't1', enrollmentDate: '2026-01-05', country: 'BD', timeZone: 'Asia/Dhaka' }, private: { guardianPhone: '123' } };

test('valid student input is accepted and normalised', () => {
  const r = validateCreateUser(student); assert.equal(r.ok, true);
  if (r.ok) { assert.equal(r.data.code, 'S-1001'); assert.equal(r.data.student?.track, 'qaida'); }
});
test('client cannot smuggle a privileged role', () => {
  for (const role of ['principal', 'admin', '']) { const r = validateCreateUser({ ...student, role }); assert.equal(r.ok, false); }
});
test('only the three course tracks are accepted', () => {
  assert.equal(validateCreateUser({ ...student, student: { ...student.student, track: 'tajweed' } }).ok, false);
  for (const track of ['qaida', 'ampara', 'quran']) assert.equal(validateCreateUser({ ...student, student: { ...student.student, track } }).ok, true);
});
test('bad ids, emails, dates are rejected', () => {
  assert.equal(validateCreateUser({ ...student, code: 'x' }).ok, false);
  assert.equal(validateCreateUser({ ...student, code: 'bad id!' }).ok, false);
  assert.equal(validateCreateUser({ ...student, email: 'nope' }).ok, false);
  assert.equal(validateCreateUser({ ...student, student: { ...student.student, enrollmentDate: '5/1/2026' } }).ok, false);
});
test('teachers must have an email; unknown responsibilities are dropped', () => {
  assert.equal(validateCreateUser({ role: 'teacher', code: 'T-001', displayName: 'Teacher', email: '' }).ok, false);
  const r = validateCreateUser({ role: 'teacher', code: 'T-001', displayName: 'Teacher', email: 'T@Example.org', teacher: { responsibilities: ['progress', 'root'] } });
  assert.equal(r.ok, true); if (r.ok) { assert.deepEqual(r.data.teacher?.responsibilities, ['progress']); assert.equal(r.data.email, 't@example.org'); }
});
test('non-object bodies never throw', () => { for (const b of [null, undefined, 'x', 5, []]) assert.equal(validateCreateUser(b).ok, false); });
test('temporary passwords are 14 chars, unambiguous and unique', () => {
  const a = generateTempPassword(), b = generateTempPassword();
  assert.equal(a.length, 14); assert.notEqual(a, b); assert.ok(!/[0OIl1]/.test(a));
});
test('login email mapping is deterministic and lower-case', () => {
  assert.equal(loginEmailFor('S-1001', 'Login.Example'), 's-1001@login.example'); assert.equal(normaliseCode(' s 10 '), 'S10');
});
test('status and origin helpers', () => {
  assert.ok(isStatus('active') && isStatus('archived') && !isStatus('deleted'));
  assert.ok(originAllowed(null, [])); assert.ok(originAllowed('https://a.app', ['https://a.app'])); assert.ok(!originAllowed('https://evil.app', ['https://a.app']));
});
