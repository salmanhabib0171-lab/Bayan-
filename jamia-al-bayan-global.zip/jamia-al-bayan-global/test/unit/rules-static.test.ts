// STATIC checks of firestore.rules text. These catch regressions in the structure of the rules, but they do NOT
// execute the rules — behavioural tests live in test/rules (they need the Firestore emulator).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const rules = readFileSync('firestore.rules', 'utf8');
const block = (name: string) => { const i = rules.indexOf(`match /${name}`); assert.ok(i >= 0, `no block for ${name}`); const rest = rules.slice(i); return rest.slice(0, rest.indexOf('\n    }\n') + 7); };

test('deny-by-default catch-all exists and nothing is open to everyone', () => {
  assert.ok(/match \/\{document=\*\*\} \{ allow read, write: if false; \}/.test(rules));
  assert.ok(!/if true/.test(rules)); assert.ok(!/allow [a-z, ]+;/.test(rules));
});
test('private student data is Principal-only', () => {
  const b = block('studentPrivate/{id}'); assert.ok(b.includes('isPrincipal()')); assert.ok(!/isTeacher|isStudent|request\.auth\.uid == id/.test(b));
});
test('roles come from server claims and accounts must be active', () => {
  assert.ok(rules.includes('request.auth.token.role')); assert.ok(rules.includes(".data.status == 'active'"));
});
test('users: no client create/delete; only language and the password flag are self-editable', () => {
  const b = block('users/{uid}'); assert.ok(b.includes('allow create, delete: if false')); assert.ok(b.includes("changedOnly(['language', 'mustChangePassword'])"));
  assert.ok(!/'role'|'status'/.test(b.split('match /reads')[0].split('allow update')[1] ?? ''));
});
test('students/teachers cannot be deleted, history documents are never deleted', () => {
  for (const c of ['students/{id}', 'teachers/{id}', 'goals/{id}', 'progress/{id}', 'attendance/{id}', 'classes/{id}', 'studentPrivate/{id}']) assert.ok(block(c).includes('allow delete: if false'), c);
});
test('teacher access is tied to assignment (teacherId / teachesStudent)', () => {
  for (const c of ['progress/{id}', 'goals/{id}', 'attendance/{id}', 'classes/{id}', 'assignments/{id}']) assert.ok(/resource\.data\.teacherId == request\.auth\.uid/.test(block(c)), c);
  assert.ok(block('students/{id}').includes('resource.data.teacherId == request.auth.uid'));
});
test('students can only read their own records; no student directory', () => {
  assert.ok(block('students/{id}').includes('request.auth.uid == id'));
  for (const c of ['progress/{id}', 'goals/{id}', 'attendance/{id}']) assert.ok(block(c).includes('resource.data.studentId == request.auth.uid'), c);
  assert.ok(!/isStudent\(\)[^;]*students\/\$/.test(block('students/{id}')));
});
test('internal teacher notes are never readable by students', () => { assert.ok(!block('progressNotes/{id}').includes('isStudent')); });
test('messages: participants only, no deletes/edits, bounded length, sender = caller', () => {
  const b = block('conversations/{cid}'); assert.ok(b.includes('in resource.data.participants')); assert.ok(b.includes('allow update, delete: if false'));
  assert.ok(b.includes('senderId == request.auth.uid') && b.includes('size() <= max') === false); assert.ok(/reqText\(request\.resource\.data\.text, 1000\)/.test(b));
});
test('audit log is append-only; content cannot be published without verification', () => {
  const a = block('audit/{id}'); assert.ok(a.includes('allow update, delete: if false'));
  assert.ok(rules.includes('d.sourceVerified == true') && rules.includes('d.reviewedBy == request.auth.uid'));
});
test('Zoom links are restricted to https zoom hosts in the rules too', () => { assert.ok(rules.includes('zoom\\\\.us|zoom\\\\.com|zoomgov\\\\.com')); });
