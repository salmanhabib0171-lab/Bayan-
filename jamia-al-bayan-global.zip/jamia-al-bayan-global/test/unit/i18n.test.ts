import test from 'node:test';
import assert from 'node:assert/strict';
import { execSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { en } from '../../src/i18n/en';
import { bn } from '../../src/i18n/bn';

const vars = (s: string) => [...s.matchAll(/\{(\w+)\}/g)].map((m) => m[1]).sort().join(',');
test('Bangla defines exactly the same keys as English', () => {
  assert.deepEqual(Object.keys(bn).sort(), Object.keys(en).sort());
});
test('no empty translations and placeholders match', () => {
  for (const k of Object.keys(en) as (keyof typeof en)[]) {
    assert.ok(bn[k].trim().length > 0, `empty bn: ${k}`);
    assert.equal(vars(bn[k]), vars(en[k]), `placeholder mismatch: ${k}`);
  }
});
test('Bangla strings contain Bangla script (not left in English)', () => {
  const allowed = new Set(['dash.noLink', 'announce.new_badge']); const latinOnly: string[] = [];
  for (const [k, v] of Object.entries(bn)) if (!/[\u0980-\u09FF]/.test(v)) latinOnly.push(k);
  assert.deepEqual(latinOnly.filter((k) => !allowed.has(k)), [], 'untranslated keys');
});
test('every t(\'key\') used in source exists in the dictionary', () => {
  const files = execSync("grep -rl \"t('\" src --include=*.tsx --include=*.ts", { encoding: 'utf8' }).split('\n').filter(Boolean);
  const missing: string[] = [];
  for (const f of files) for (const m of readFileSync(f, 'utf8').matchAll(/\bt\('([a-zA-Z0-9_.]+)'/g)) if (!(m[1] in en)) missing.push(`${f}: ${m[1]}`);
  assert.deepEqual(missing, []);
});
