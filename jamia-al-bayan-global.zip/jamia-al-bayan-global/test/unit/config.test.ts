import test from 'node:test';
import assert from 'node:assert/strict';
import { execSync } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';

const read = (p: string) => readFileSync(p, 'utf8');

test('PWA manifest is valid and its icons exist', () => {
  const m = JSON.parse(read('public/manifest.webmanifest'));
  assert.equal(m.name, 'Jamia Al-Bayan Global'); assert.equal(m.display, 'standalone'); assert.ok(m.start_url && m.scope);
  assert.ok(m.icons.some((i: { sizes: string }) => i.sizes === '512x512')); assert.ok(m.icons.some((i: { purpose: string }) => i.purpose === 'maskable'));
  for (const i of m.icons) assert.ok(existsSync(`public${i.src}`), i.src);
});
test('service worker never caches API/Firestore traffic', () => {
  const sw = read('public/sw.js'); assert.ok(sw.includes("url.origin !== self.location.origin")); assert.ok(sw.includes('/.netlify/'));
  assert.ok(!/addAll\([^)]*(students|messages|progress)/i.test(sw));
});
test('netlify.toml: build, publish, functions, SPA fallback and security headers', () => {
  const n = read('netlify.toml');
  for (const s of ['command = "npm run build"', 'publish = "dist"', 'functions = "netlify/functions"', 'from = "/*"', 'to = "/index.html"', 'status = 200', 'Content-Security-Policy', 'X-Frame-Options', 'Strict-Transport-Security']) assert.ok(n.includes(s), s);
  assert.ok(!n.includes("'unsafe-eval'")); assert.ok(/script-src 'self';/.test(n));
});
test('.env.example holds names only, and secrets are never VITE_-prefixed', () => {
  const e = read('.env.example');
  for (const line of e.split('\n').filter((l) => /^[A-Z_]+=/.test(l))) { const [k, v] = line.split('='); if (!/^(VITE_LOGIN_EMAIL_DOMAIN|LOGIN_EMAIL_DOMAIN|VITE_DEMO_MODE|MAX_ACCOUNTS|ALLOWED_ORIGINS)$/.test(k)) assert.equal(v, '', `${k} must be empty`); }
  assert.ok(!/VITE_[A-Z_]*(PRIVATE|SECRET|SERVICE|ADMIN)/.test(e)); assert.ok(e.includes('VITE_DEMO_MODE=false'));
});
test('no credentials or Admin SDK in browser code', () => {
  const out = execSync("grep -rniE 'private_key|BEGIN PRIVATE|firebase-admin|service.?account' src || true", { encoding: 'utf8' }); assert.equal(out.trim(), '');
  assert.equal(execSync("grep -rn 'firebase-admin' src || true", { encoding: 'utf8' }).trim(), '');
});
test('browser storage is limited to the language preference', () => {
  const out = execSync("grep -rnE 'localStorage|sessionStorage|indexedDB' src --include=*.ts --include=*.tsx || true", { encoding: 'utf8' }).trim().split('\n').filter(Boolean);
  for (const l of out) assert.ok(/albayan\.lang|clearLocalState|sessionStorage\.clear|localStorage\.(get|set|remove)Item\(LS|Object\.keys\(localStorage\)|localStorage\.removeItem\(k\)/.test(l) || l.includes('LS'), l);
});
test('Quran is a course-track label only: no reader, no Quran text or audio', () => {
  const src = execSync("grep -rliE 'surah browser|quran reader|mushaf|<audio|recitation' src || true", { encoding: 'utf8' }).trim(); assert.equal(src, '');
  const seed = read('src/lib/demoSeed.ts'); assert.ok(!/﴿|بِسْمِ ٱللَّهِ/.test(seed));
  assert.ok(!existsSync('src/pages/quran') && !existsSync('public/audio'));
});
test('seed/demo data contains no fabricated dua text (placeholder only)', () => {
  const seed = read('src/lib/demoSeed.ts'); const m = seed.match(/seed\.duas\['d-placeholder'\] = \{[^}]*\}/)![0];
  assert.ok(m.includes("arabic: ''") && m.includes("status: 'draft'"));
});
test('demo mode is off by default and visibly flagged', () => {
  assert.ok(read('.env.example').includes('VITE_DEMO_MODE=false')); assert.ok(read('src/components/Shell.tsx').includes("mode === 'demo'"));
});
