import test from 'node:test';
import assert from 'node:assert/strict';
import { addDays, joinWindow, startOfWeek, zonedToUtcIso } from '../../src/lib/dates';
import { attendanceRate, goalCompletion, needingUpdate, rate, toCsv, weeklyAttendance } from '../../src/lib/stats';
import { isZoomUrl } from '../../src/lib/zoom';

test('zoned time → UTC is correct, including DST', () => {
  assert.equal(zonedToUtcIso('2026-01-15', '17:00', 'Asia/Dhaka'), '2026-01-15T11:00:00.000Z');       // UTC+6, no DST
  assert.equal(zonedToUtcIso('2026-01-15', '17:00', 'Europe/London'), '2026-01-15T17:00:00.000Z');    // winter
  assert.equal(zonedToUtcIso('2026-07-15', '17:00', 'Europe/London'), '2026-07-15T16:00:00.000Z');    // summer (BST)
  assert.equal(zonedToUtcIso('2026-07-15', '09:30', 'America/New_York'), '2026-07-15T13:30:00.000Z'); // EDT
});
test('date helpers', () => {
  assert.equal(addDays('2026-03-01', -1), '2026-02-28'); assert.equal(startOfWeek('2026-10-11'), '2026-10-05');
});
test('join window opens 15 min before and closes 15 min after the end', () => {
  const s = '2026-10-11T10:00:00.000Z', t = (m: number) => new Date(s).getTime() + m * 60_000;
  assert.equal(joinWindow(s, 30, t(-20)).open, false); assert.equal(joinWindow(s, 30, t(-10)).open, true);
  assert.equal(joinWindow(s, 30, t(40)).open, true); assert.equal(joinWindow(s, 30, t(50)).open, false); assert.equal(joinWindow(s, 30, t(50)).ended, true);
});
test('percentages are hidden when data is too thin', () => {
  assert.equal(rate(3, 4).value, null); assert.equal(rate(4, 5).value, 80);
  const rows = (...s: string[]) => s.map((status) => ({ status })) as never[];
  assert.equal(attendanceRate(rows('present', 'late', 'absent')).value, null);
  assert.equal(attendanceRate(rows('present', 'present', 'late', 'absent', 'excused', 'excused')).value, null); // 4 countable sessions < minimum of 5
  assert.equal(attendanceRate(rows('present', 'present', 'present', 'late', 'absent', 'excused', 'excused')).value, 80); // excused excluded: 4/5
  assert.equal(goalCompletion([{ status: 'achieved' }, { status: 'practicing' }] as never[]).value, null);
  assert.equal(goalCompletion([{ status: 'achieved' }, { status: 'practicing' }, { status: 'achieved' }, { status: 'not_started' }] as never[]).value, 50);
});
test('weekly attendance trend groups by Monday-based week', () => {
  const w = weeklyAttendance([{ date: '2026-10-05', status: 'present' }, { date: '2026-10-06', status: 'absent' }, { date: '2026-10-07', status: 'present' }, { date: '2026-10-13', status: 'present' }] as never[]);
  assert.equal(w.length, 2); assert.equal(w[0].week, '2026-10-05'); assert.equal(w[0].rate.value, 67); assert.equal(w[1].rate.value, null);
});
test('needingUpdate finds students without a recent entry', () => {
  const p = [{ studentId: 'a', date: '2026-10-10' }, { studentId: 'b', date: '2026-09-01' }];
  assert.deepEqual(needingUpdate(['a', 'b', 'c'], p, '2026-10-11', 7), ['b', 'c']);
});
test('CSV export neutralises spreadsheet formula injection and escapes quotes', () => {
  const csv = toCsv([{ name: '=HYPERLINK("x")', note: 'a,b', ok: 1 }]);
  assert.ok(csv.includes(`"'=HYPERLINK(""x"")"`)); assert.ok(csv.includes('"a,b"'));
});
test('only https Zoom links are accepted (no javascript:, http:, look-alike hosts)', () => {
  assert.ok(isZoomUrl('https://zoom.us/j/123456789?pwd=abc')); assert.ok(isZoomUrl('https://us02web.zoom.us/j/1'));
  for (const bad of ['javascript:alert(1)', 'http://zoom.us/j/1', 'https://zoom.us.evil.com/j/1', 'https://evilzoom.us/j/1', 'https://example.com/zoom.us/j/1', 'https://zoom.us/']) assert.equal(isZoomUrl(bad), false, bad);
});
