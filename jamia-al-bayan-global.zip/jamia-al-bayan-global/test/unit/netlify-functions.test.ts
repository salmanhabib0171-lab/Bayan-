import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
// Every privileged function must go through requirePrincipal (token verification + active Principal check).
test('all privileged functions authorise via handle()/requirePrincipal', () => {
  for (const f of ['create-user', 'update-user-status', 'update-user-profile', 'reset-password', 'reassign-teacher']) {
    const s = readFileSync(`netlify/functions/${f}.ts`, 'utf8'); assert.ok(/handle\(req,/.test(s), f);
  }
  const a = readFileSync('netlify/functions/_lib/admin.ts', 'utf8');
  for (const needle of ['verifyIdToken(token, true)', "decoded.role !== 'principal'", "status !== 'active'", 'originAllowed', 'rateLimit']) assert.ok(a.includes(needle), needle);
});
test('functions never log request bodies or passwords', () => {
  for (const f of ['create-user', 'update-user-status', 'update-user-profile', 'reset-password', 'reassign-teacher', '_lib/admin']) {
    const s = readFileSync(`netlify/functions/${f}.ts`, 'utf8'); assert.ok(!/console\.(log|info|debug)/.test(s), f); assert.ok(!/console\.error\([^)]*(body|password)/i.test(s), f);
  }
});
test('there is no public endpoint that can create a Principal', () => {
  for (const f of ['create-user']) { const s = readFileSync(`netlify/functions/${f}.ts`, 'utf8'); assert.ok(!s.includes("'principal'")); }
  assert.ok(readFileSync('scripts/bootstrap-principal.mjs', 'utf8').includes('A Principal already exists'));
});
