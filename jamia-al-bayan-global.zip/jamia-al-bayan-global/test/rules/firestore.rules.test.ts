/**
 * Behavioural Firestore Security Rules tests. They need the Firestore emulator (Java + firebase-tools):
 *     npm run test:rules
 * They could NOT be executed in the offline build sandbox, so treat them as unverified until you run them.
 */
import test, { after, before, beforeEach } from 'node:test';
import { readFileSync } from 'node:fs';
import { assertFails, assertSucceeds, initializeTestEnvironment, type RulesTestEnvironment } from '@firebase/rules-unit-testing';
import { addDoc, collection, doc, getDoc, getDocs, query, serverTimestamp, setDoc, updateDoc, where } from 'firebase/firestore';

let env: RulesTestEnvironment;
const P = { uid: 'p1', claims: { role: 'principal' } }, T1 = { uid: 't1', claims: { role: 'teacher' } }, T2 = { uid: 't2', claims: { role: 'teacher' } };
const S1 = { uid: 's1', claims: { role: 'student' } }, S2 = { uid: 's2', claims: { role: 'student' } };
const as = (u: { uid: string; claims: object }) => env.authenticatedContext(u.uid, u.claims).firestore();

before(async () => { env = await initializeTestEnvironment({ projectId: 'demo-jamia', firestore: { rules: readFileSync('firestore.rules', 'utf8') } }); });
after(async () => { await env.cleanup(); });
beforeEach(async () => {
  await env.clearFirestore();
  await env.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    for (const [id, role] of [['p1', 'principal'], ['t1', 'teacher'], ['t2', 'teacher'], ['s1', 'student'], ['s2', 'student']] as const)
      await setDoc(doc(db, 'users', id), { role, status: 'active', displayName: id, code: id, language: 'en', mustChangePassword: false });
    await setDoc(doc(db, 'students', 's1'), { studentCode: 'S1', displayName: 'One', track: 'qaida', level: '', teacherId: 't1', teacherName: 'T1', enrollmentDate: '2026-01-01', language: 'en', country: '', timeZone: 'UTC', status: 'active' });
    await setDoc(doc(db, 'students', 's2'), { studentCode: 'S2', displayName: 'Two', track: 'quran', level: '', teacherId: 't2', teacherName: 'T2', enrollmentDate: '2026-01-01', language: 'en', country: '', timeZone: 'UTC', status: 'active' });
    await setDoc(doc(db, 'studentPrivate', 's1'), { guardianName: 'Secret', guardianPhone: '1' });
    await setDoc(doc(db, 'progress', 'pr1'), { studentId: 's1', teacherId: 't1', track: 'qaida', date: '2026-10-01', lesson: 'L', status: 'achieved', feedback: '', homework: '', practice: '', followUp: '', createdBy: 't1' });
    await setDoc(doc(db, 'progressNotes', 'pr1'), { studentId: 's1', teacherId: 't1', note: 'private' });
    await setDoc(doc(db, 'conversations', 't1_s1'), { teacherId: 't1', studentId: 's1', participants: ['t1', 's1'] });
  });
});

test('unauthenticated users can read nothing', async () => { await assertFails(getDoc(doc(env.unauthenticatedContext().firestore(), 'students', 's1'))); });
test('PRINCIPAL can read private student details', async () => { await assertSucceeds(getDoc(doc(as(P), 'studentPrivate', 's1'))); });
test('a TEACHER cannot read private guardian details (even for their own student)', async () => { await assertFails(getDoc(doc(as(T1), 'studentPrivate', 's1'))); });
test('a STUDENT cannot read private details (even their own)', async () => { await assertFails(getDoc(doc(as(S1), 'studentPrivate', 's1'))); });
test('a teacher can list only their assigned students; others are refused', async () => {
  await assertSucceeds(getDocs(query(collection(as(T1), 'students'), where('teacherId', '==', 't1'))));
  await assertFails(getDocs(query(collection(as(T1), 'students'), where('teacherId', '==', 't2'))));
  await assertFails(getDocs(collection(as(T1), 'students')));
  await assertFails(getDoc(doc(as(T1), 'students', 's2')));
});
test('an unassigned teacher cannot read another teacher\'s progress or notes', async () => {
  await assertFails(getDoc(doc(as(T2), 'progress', 'pr1'))); await assertFails(getDoc(doc(as(T2), 'progressNotes', 'pr1')));
  await assertSucceeds(getDoc(doc(as(T1), 'progress', 'pr1')));
});
test('a student reads own progress but not another student\'s, and never internal notes', async () => {
  await assertSucceeds(getDoc(doc(as(S1), 'progress', 'pr1'))); await assertFails(getDoc(doc(as(S2), 'progress', 'pr1'))); await assertFails(getDoc(doc(as(S1), 'progressNotes', 'pr1')));
});
test('students have no directory access', async () => { await assertFails(getDocs(collection(as(S1), 'students'))); await assertSucceeds(getDoc(doc(as(S1), 'students', 's1'))); await assertFails(getDoc(doc(as(S1), 'students', 's2'))); });
test('role escalation is impossible', async () => {
  await assertFails(updateDoc(doc(as(S1), 'users', 's1'), { role: 'principal' }));
  await assertFails(updateDoc(doc(as(T1), 'users', 't1'), { role: 'principal' }));
  await assertFails(updateDoc(doc(as(S1), 'users', 's1'), { status: 'active', language: 'en' }));
  await assertFails(setDoc(doc(as(S1), 'users', 'evil'), { role: 'principal', status: 'active' }));
  await assertSucceeds(updateDoc(doc(as(S1), 'users', 's1'), { language: 'bn' }));
});
test('a forged role claim without an active user record is useless', async () => {
  await assertFails(getDoc(doc(env.authenticatedContext('ghost', { role: 'principal' }).firestore(), 'studentPrivate', 's1')));
});
test('a DISABLED account loses access immediately', async () => {
  await env.withSecurityRulesDisabled(async (c) => { await updateDoc(doc(c.firestore(), 'users', 't1'), { status: 'inactive' }); });
  await assertFails(getDoc(doc(as(T1), 'progress', 'pr1')));
  await assertFails(getDocs(query(collection(as(T1), 'students'), where('teacherId', '==', 't1'))));
});
test('teachers write progress only for their own assigned students', async () => {
  const entry = (studentId: string, teacherId: string) => ({ studentId, teacherId, track: 'qaida', date: '2026-10-02', lesson: 'x', status: 'practicing', feedback: '', homework: '', practice: '', followUp: '', createdBy: 't1', createdAt: serverTimestamp() });
  await assertSucceeds(addDoc(collection(as(T1), 'progress'), entry('s1', 't1')));
  await assertFails(addDoc(collection(as(T1), 'progress'), entry('s2', 't1')));   // not assigned
  await assertFails(addDoc(collection(as(T1), 'progress'), entry('s1', 't2')));   // forged owner
  await assertFails(addDoc(collection(as(S1), 'progress'), entry('s1', 't1')));   // students cannot write progress
});
test('progress history cannot be deleted', async () => { const { deleteDoc } = await import('firebase/firestore'); await assertFails(deleteDoc(doc(as(P), 'progress', 'pr1'))); await assertFails(deleteDoc(doc(as(T1), 'progress', 'pr1'))); });
test('only the Principal manages students and teachers', async () => {
  await assertFails(updateDoc(doc(as(T1), 'students', 's1'), { teacherId: 't1', level: 'x' })); await assertFails(updateDoc(doc(as(S1), 'students', 's1'), { level: 'x' }));
  await assertSucceeds(updateDoc(doc(as(P), 'students', 's1'), { level: 'Lesson 2' }));
});
test('messaging: only assigned teacher ↔ student; no student-to-student', async () => {
  await assertSucceeds(getDoc(doc(as(S1), 'conversations', 't1_s1'))); await assertFails(getDoc(doc(as(S2), 'conversations', 't1_s1'))); await assertFails(getDoc(doc(as(T2), 'conversations', 't1_s1')));
  const msg = { senderId: 's1', text: 'salam', createdAt: serverTimestamp() };
  await assertSucceeds(addDoc(collection(as(S1), 'conversations', 't1_s1', 'messages'), msg));
  await assertFails(addDoc(collection(as(S2), 'conversations', 't1_s1', 'messages'), { ...msg, senderId: 's2' }));
  await assertFails(addDoc(collection(as(S1), 'conversations', 't1_s1', 'messages'), { ...msg, senderId: 't1' })); // spoofed sender
  await assertFails(addDoc(collection(as(S1), 'conversations', 't1_s1', 'messages'), { ...msg, text: 'x'.repeat(1001) }));
  await assertFails(setDoc(doc(as(S1), 'conversations', 's1_s2'), { teacherId: 's1', studentId: 's2', participants: ['s1', 's2'] })); // student-to-student
  await assertFails(setDoc(doc(as(T2), 'conversations', 't2_s1'), { teacherId: 't2', studentId: 's1', participants: ['t2', 's1'] }));   // unassigned teacher
});
test('class links: only https Zoom hosts; students see only their own classes', async () => {
  const cls = (zoomUrl: string) => ({ title: 'Class', teacherId: 't1', studentIds: ['s1'], startsAt: '2026-10-12T10:00:00.000Z', timeZone: 'UTC', durationMin: 30, zoomUrl, notes: '', status: 'scheduled', createdBy: 't1' });
  await assertSucceeds(addDoc(collection(as(T1), 'classes'), cls('https://zoom.us/j/123')));
  await assertFails(addDoc(collection(as(T1), 'classes'), cls('javascript:alert(1)')));
  await assertFails(addDoc(collection(as(T1), 'classes'), cls('https://zoom.us.evil.com/j/1')));
  await assertSucceeds(getDocs(query(collection(as(S1), 'classes'), where('studentIds', 'array-contains', 's1'))));
  await assertFails(getDocs(query(collection(as(S1), 'classes'), where('studentIds', 'array-contains', 's2'))));
});
test('religious content cannot be published without a verified source and a named reviewer', async () => {
  const dua = (extra: object) => ({ title: 'D', category: 'daily', arabic: 'x', status: 'published', createdBy: 'p1', ...extra });
  await assertFails(setDoc(doc(as(P), 'duas', 'd1'), dua({ sourceVerified: false, reviewedBy: 'p1', reviewerName: 'A' })));
  await assertFails(setDoc(doc(as(P), 'duas', 'd1'), dua({ sourceVerified: true, reviewedBy: 'p1', reviewerName: '' })));
  await assertSucceeds(setDoc(doc(as(P), 'duas', 'd1'), dua({ sourceVerified: true, reviewedBy: 'p1', reviewerName: 'Mufti A' })));
  await assertSucceeds(getDoc(doc(as(S1), 'duas', 'd1')));
  await assertSucceeds(setDoc(doc(as(P), 'duas', 'd2'), dua({ status: 'draft', sourceVerified: false })));
  await assertFails(getDoc(doc(as(S1), 'duas', 'd2'))); // drafts are invisible to non-Principals
  await assertFails(setDoc(doc(as(T1), 'duas', 'd3'), dua({ status: 'draft' })));
});
test('audit log is append-only and Principal-only', async () => {
  const ref = await addDoc(collection(as(P), 'audit'), { actorId: 'p1', action: 'x', targetId: 'y', createdAt: serverTimestamp() }); await assertSucceeds(getDoc(ref));
  await assertFails(updateDoc(ref, { action: 'z' })); await assertFails(getDoc(doc(as(T1), 'audit', ref.id))); await assertFails(addDoc(collection(as(T1), 'audit'), { actorId: 't1', action: 'x', targetId: 'y', createdAt: serverTimestamp() }));
});
test('announcements honour their audience', async () => {
  await env.withSecurityRulesDisabled(async (c) => { const db = c.firestore();
    await setDoc(doc(db, 'announcements', 'a1'), { title: 't', body: 'b', audience: 'teachers' }); await setDoc(doc(db, 'announcements', 'a2'), { title: 't', body: 'b', audience: 'student', targetStudentId: 's1' }); });
  await assertSucceeds(getDoc(doc(as(T1), 'announcements', 'a1'))); await assertFails(getDoc(doc(as(S1), 'announcements', 'a1')));
  await assertSucceeds(getDoc(doc(as(S1), 'announcements', 'a2'))); await assertFails(getDoc(doc(as(S2), 'announcements', 'a2')));
  await assertFails(setDoc(doc(as(T1), 'announcements', 'a3'), { title: 'x', body: 'y', audience: 'all' }));
});
