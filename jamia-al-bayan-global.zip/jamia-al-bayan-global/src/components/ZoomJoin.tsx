import { LuVideo } from 'react-icons/lu';
import { isZoomUrl } from '../lib/data';
import { joinWindow } from '../lib/dates';
import { useNow } from '../lib/hooks';
import type { ClassSession } from '../lib/types';
import { useI18n } from '../i18n';
import { Button } from './ui';

/** Join button for a Zoom class. The link opens in a new context with no opener access. */
export function ZoomJoin({ cls, size = 'md' }: { cls: Pick<ClassSession, 'startsAt' | 'durationMin' | 'zoomUrl' | 'status'>; size?: 'sm' | 'md' | 'lg' }) {
  const { t } = useI18n(); const now = useNow(15_000);
  if (cls.status === 'cancelled') return <Button size={size} disabled>{t('class.cancelled')}</Button>;
  if (!cls.zoomUrl || !isZoomUrl(cls.zoomUrl)) return <Button size={size} disabled title={t('class.noLink')}>{t('class.noLink')}</Button>;
  const w = joinWindow(cls.startsAt, cls.durationMin, now);
  if (!w.open) return <Button size={size} disabled title={w.ended ? t('class.ended') : t('class.notYet')}>{w.ended ? t('class.ended') : t('class.joinSoon')}</Button>;
  return (
    <a className={`btn btn-gold btn-${size}`} href={cls.zoomUrl} target="_blank" rel="noopener noreferrer"><LuVideo aria-hidden />{t('class.join')}</a>
  );
}
