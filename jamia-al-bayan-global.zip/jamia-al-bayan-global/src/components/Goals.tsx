import { useState } from 'react';
import { LuPlus, LuTarget } from 'react-icons/lu';
import { useAuth } from '../lib/auth';
import { fmtDate } from '../lib/dates';
import { SERVER_TIME } from '../lib/services';
import { goalCompletion } from '../lib/stats';
import { PROGRESS_STATUSES, type Goal, type ProgressStatus, type StudentDoc } from '../lib/types';
import { useI18n, type Key } from '../i18n';
import { Badge, Button, EmptyState, Field, Input, Modal, ProgressBadge, Select, Textarea, useToast } from './ui';

export function GoalEditor({ open, onClose, student, goal, onSaved }: { open: boolean; onClose: () => void; student: StudentDoc; goal?: Goal; onSaved: () => void }) {
  const { t } = useI18n(); const { db, user } = useAuth(); const toast = useToast();
  const [title, setTitle] = useState(goal?.title ?? ''); const [description, setDescription] = useState(goal?.description ?? '');
  const [status, setStatus] = useState<ProgressStatus>(goal?.status ?? 'not_started'); const [targetDate, setTargetDate] = useState(goal?.targetDate ?? '');
  const [busy, setBusy] = useState(false); const [err, setErr] = useState('');
  async function save() {
    if (title.trim().length < 3) return setErr(t('validation.titleShort'));
    setBusy(true);
    try {
      const data = { studentId: student.id, teacherId: student.teacherId, title: title.trim(), description: description.trim(), status, targetDate };
      if (goal) await db.update('goals', goal.id, data);
      else await db.add('goals', { ...data, createdBy: user.id, createdAt: SERVER_TIME });
      toast('ok', t('toast.saved')); onSaved(); onClose();
    } catch { toast('err', t('error.save')); } finally { setBusy(false); }
  }
  return (
    <Modal open={open} onClose={onClose} title={goal ? t('goal.edit') : t('goal.add')} footer={<><Button variant="ghost" onClick={onClose}>{t('common.cancel')}</Button><Button variant="primary" loading={busy} onClick={save}>{t('common.save')}</Button></>}>
      <Field label={t('goal.title')} required error={err}>{(id, d) => <Input id={id} aria-describedby={d} maxLength={140} value={title} onChange={(e) => { setTitle(e.target.value); setErr(''); }} />}</Field>
      <Field label={t('goal.description')}>{(id) => <Textarea id={id} maxLength={600} value={description} onChange={(e) => setDescription(e.target.value)} />}</Field>
      <div className="form-grid">
        <Field label={t('field.status')}>{(id) => <Select id={id} value={status} onChange={(e) => setStatus(e.target.value as ProgressStatus)}>{PROGRESS_STATUSES.map((s) => <option key={s} value={s}>{t(`progress.${s}` as Key)}</option>)}</Select>}</Field>
        <Field label={t('goal.target')}>{(id) => <Input id={id} type="date" value={targetDate} onChange={(e) => setTargetDate(e.target.value)} />}</Field>
      </div>
    </Modal>
  );
}

/** Goal list + transparent completion metric. `canEdit` is a UI convenience; Firestore rules decide who may actually write. */
export function GoalList({ goals, student, canEdit, onChanged }: { goals: Goal[]; student?: StudentDoc; canEdit: boolean; onChanged?: () => void }) {
  const { t, lang } = useI18n(); const [editing, setEditing] = useState<Goal | 'new' | null>(null);
  const c = goalCompletion(goals);
  return (
    <div className="stack">
      <div className="row between">
        <span className="muted small">{c.value === null ? t('stats.notEnough') : t('stats.goalCompletion', { n: c.n, d: c.d, pct: c.value })}</span>
        {canEdit && student && <Button size="sm" icon={<LuPlus aria-hidden />} onClick={() => setEditing('new')}>{t('goal.add')}</Button>}
      </div>
      {goals.length === 0 ? <EmptyState icon={<LuTarget size={28} />} title={t('goal.none')} /> : (
        <ul className="list">{goals.map((g) => (
          <li key={g.id}>
            <div><strong>{g.title}</strong>{g.description && <p className="muted small">{g.description}</p>}{g.targetDate && <p className="muted small">{t('goal.target')}: {fmtDate(g.targetDate, lang)}</p>}</div>
            <div className="row"><ProgressBadge status={g.status} />{canEdit && student && <Button size="sm" variant="ghost" onClick={() => setEditing(g)}>{t('common.edit')}</Button>}</div>
          </li>))}
        </ul>)}
      {editing && student && <GoalEditor open student={student} goal={editing === 'new' ? undefined : editing} onClose={() => setEditing(null)} onSaved={() => onChanged?.()} />}
      <p className="muted small"><Badge tone="neutral">{t('stats.methodology')}</Badge> {t('stats.goalMethod')}</p>
    </div>
  );
}
