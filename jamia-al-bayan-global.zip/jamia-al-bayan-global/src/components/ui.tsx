import {
  createContext, useCallback, useContext, useEffect, useId, useMemo, useRef, useState,
  type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes,
} from 'react';
import { LuCheck, LuChevronLeft, LuChevronRight, LuCircleAlert, LuInbox, LuSearch, LuX } from 'react-icons/lu';
import { useI18n, type Key } from '../i18n';
import type { AccountStatus, AttendanceStatus, ProgressStatus } from '../lib/types';

export const cx = (...a: (string | false | null | undefined)[]) => a.filter(Boolean).join(' ');

export function Button({ variant = 'secondary', size = 'md', loading, icon, children, className, disabled, ...rest }:
  ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'ghost' | 'danger'; size?: 'sm' | 'md' | 'lg'; loading?: boolean; icon?: ReactNode }) {
  return (
    <button type="button" className={cx('btn', `btn-${variant}`, `btn-${size}`, className)} disabled={disabled || loading} aria-busy={loading || undefined} {...rest}>
      {loading ? <span className="spinner spinner-sm" aria-hidden /> : icon}
      {children}
    </button>
  );
}

export function Card({ children, className, as: Tag = 'section' }: { children: ReactNode; className?: string; as?: 'section' | 'div' | 'article' }) {
  return <Tag className={cx('card', className)}>{children}</Tag>;
}
export function CardHeader({ title, action, subtitle }: { title: ReactNode; action?: ReactNode; subtitle?: ReactNode }) {
  return (
    <header className="card-head">
      <div><h2 className="card-title">{title}</h2>{subtitle && <p className="muted small">{subtitle}</p>}</div>
      {action}
    </header>
  );
}
export function PageHeader({ title, subtitle, actions }: { title: ReactNode; subtitle?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="page-head">
      <div><h1>{title}</h1>{subtitle && <p className="muted">{subtitle}</p>}</div>
      {actions && <div className="page-actions">{actions}</div>}
    </div>
  );
}

export function Badge({ tone = 'neutral', children }: { tone?: 'neutral' | 'teal' | 'gold' | 'green' | 'red' | 'amber'; children: ReactNode }) {
  return <span className={cx('badge', `badge-${tone}`)}>{children}</span>;
}

export function StatusBadge({ status }: { status: AccountStatus }) {
  const { t } = useI18n();
  return <Badge tone={status === 'active' ? 'green' : status === 'inactive' ? 'amber' : 'neutral'}>{t(`status.${status}` as Key)}</Badge>;
}
export function ProgressBadge({ status }: { status: ProgressStatus }) {
  const { t } = useI18n();
  const tone = { not_started: 'neutral', in_progress: 'amber', practicing: 'teal', achieved: 'green' } as const;
  return <Badge tone={tone[status]}>{t(`progress.${status}` as Key)}</Badge>;
}
export function AttendanceBadge({ status }: { status: AttendanceStatus }) {
  const { t } = useI18n();
  const tone = { present: 'green', late: 'amber', absent: 'red', excused: 'neutral' } as const;
  return <Badge tone={tone[status]}>{t(`attendance.${status}` as Key)}</Badge>;
}

// ───────── form controls ─────────
export function Field({ label, hint, error, required, children }: { label: string; hint?: string; error?: string; required?: boolean; children: (id: string, describedBy?: string) => ReactNode }) {
  const id = useId(); const msgId = `${id}-m`;
  return (
    <div className={cx('field', error && 'has-error')}>
      <label htmlFor={id}>{label}{required && <span className="req" aria-hidden> *</span>}</label>
      {children(id, error || hint ? msgId : undefined)}
      {(error || hint) && <p id={msgId} className={cx('field-msg', error && 'err')} role={error ? 'alert' : undefined}>{error ?? hint}</p>}
    </div>
  );
}
export const Input = (p: InputHTMLAttributes<HTMLInputElement>) => <input {...p} className={cx('input', p.className)} />;
export const Select = (p: SelectHTMLAttributes<HTMLSelectElement>) => <select {...p} className={cx('input', p.className)} />;
export const Textarea = (p: TextareaHTMLAttributes<HTMLTextAreaElement>) => <textarea {...p} className={cx('input', p.className)} />;

/** Arabic content: its own direction and font; the surrounding Bangla/English layout never flips. */
export function Arabic({ children, className, size }: { children: ReactNode; className?: string; size?: 'lg' | 'xl' }) {
  return <span dir="rtl" lang="ar" className={cx('arabic', size && `arabic-${size}`, className)}>{children}</span>;
}

// ───────── feedback & states ─────────
export function Spinner({ label }: { label?: string }) {
  const { t } = useI18n();
  return <div className="center-pad" role="status"><span className="spinner" aria-hidden /><span className="sr-only">{label ?? t('common.loading')}</span></div>;
}
export function Skeleton({ rows = 3 }: { rows?: number }) {
  return <div className="skeleton-wrap" aria-hidden>{Array.from({ length: rows }, (_, i) => <div key={i} className="skeleton" style={{ width: `${90 - i * 12}%` }} />)}</div>;
}
export function EmptyState({ title, text, action, icon }: { title: string; text?: string; action?: ReactNode; icon?: ReactNode }) {
  return <div className="empty">{icon ?? <LuInbox size={28} aria-hidden />}<h3>{title}</h3>{text && <p className="muted">{text}</p>}{action}</div>;
}
export function ErrorState({ onRetry, message }: { onRetry?: () => void; message?: string }) {
  const { t } = useI18n();
  return (
    <div className="empty" role="alert">
      <LuCircleAlert size={28} aria-hidden /><h3>{t('error.load')}</h3><p className="muted">{message ?? t('error.loadHint')}</p>
      {onRetry && <Button onClick={onRetry}>{t('common.retry')}</Button>}
    </div>
  );
}
export function Loadable({ loading, error, onRetry, children, rows }: { loading: boolean; error: Error | null; onRetry?: () => void; children: ReactNode; rows?: number }) {
  if (loading) return <Skeleton rows={rows} />;
  if (error) return <ErrorState onRetry={onRetry} />;
  return <>{children}</>;
}

// ───────── toasts ─────────
interface Toast { id: number; kind: 'ok' | 'err'; text: string }
const ToastCtx = createContext<(kind: Toast['kind'], text: string) => void>(() => undefined);
export const useToast = () => useContext(ToastCtx);
export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Toast[]>([]);
  const push = useCallback((kind: Toast['kind'], text: string) => {
    const id = Date.now() + Math.random();
    setItems((x) => [...x, { id, kind, text }]);
    setTimeout(() => setItems((x) => x.filter((i) => i.id !== id)), kind === 'err' ? 7000 : 3500);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="toasts" aria-live="polite">
        {items.map((i) => <div key={i.id} className={cx('toast', i.kind)} role={i.kind === 'err' ? 'alert' : 'status'}>{i.kind === 'ok' ? <LuCheck aria-hidden /> : <LuCircleAlert aria-hidden />}{i.text}</div>)}
      </div>
    </ToastCtx.Provider>
  );
}

// ───────── dialogs ─────────
export function Modal({ open, title, onClose, children, footer, wide }: { open: boolean; title: string; onClose: () => void; children: ReactNode; footer?: ReactNode; wide?: boolean }) {
  const { t } = useI18n();
  const ref = useRef<HTMLDivElement>(null);
  const titleId = useId();
  useEffect(() => {
    if (!open) return;
    const prev = document.activeElement as HTMLElement | null;
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'Tab' && ref.current) { // keep focus inside the dialog
        const f = ref.current.querySelectorAll<HTMLElement>('button,[href],input,select,textarea,[tabindex]:not([tabindex="-1"])');
        if (!f.length) return;
        const first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener('keydown', key);
    document.body.style.overflow = 'hidden';
    setTimeout(() => ref.current?.querySelector<HTMLElement>('input,select,textarea')?.focus(), 30);
    return () => { document.removeEventListener('keydown', key); document.body.style.overflow = ''; prev?.focus(); };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="overlay" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div ref={ref} className={cx('modal', wide && 'modal-wide')} role="dialog" aria-modal="true" aria-labelledby={titleId}>
        <header className="modal-head"><h2 id={titleId}>{title}</h2><button className="icon-btn" onClick={onClose} aria-label={t('common.close')}><LuX aria-hidden /></button></header>
        <div className="modal-body">{children}</div>
        {footer && <footer className="modal-foot">{footer}</footer>}
      </div>
    </div>
  );
}

export function ConfirmDialog({ open, title, text, confirmLabel, danger, onConfirm, onClose }:
  { open: boolean; title: string; text: string; confirmLabel: string; danger?: boolean; onConfirm: () => Promise<void> | void; onClose: () => void }) {
  const { t } = useI18n(); const [busy, setBusy] = useState(false);
  return (
    <Modal open={open} title={title} onClose={onClose} footer={<>
      <Button variant="ghost" onClick={onClose}>{t('common.cancel')}</Button>
      <Button variant={danger ? 'danger' : 'primary'} loading={busy} onClick={async () => { setBusy(true); try { await onConfirm(); } finally { setBusy(false); } }}>{confirmLabel}</Button>
    </>}><p>{text}</p></Modal>
  );
}

export function Segmented<V extends string>({ value, onChange, options, label }: { value: V; onChange: (v: V) => void; options: { value: V; label: string }[]; label: string }) {
  return (
    <div className="segmented" role="group" aria-label={label}>
      {options.map((o) => <button key={o.value} type="button" aria-pressed={value === o.value} className={cx(value === o.value && 'on')} onClick={() => onChange(o.value)}>{o.label}</button>)}
    </div>
  );
}

export function Stat({ label, value, hint, icon }: { label: string; value: ReactNode; hint?: string; icon?: ReactNode }) {
  return <div className="stat"><div className="stat-top">{icon}<span>{label}</span></div><strong>{value}</strong>{hint && <small className="muted">{hint}</small>}</div>;
}

export function Avatar({ name }: { name: string }) {
  const initials = name.replace(/[^\p{L}\s]/gu, '').split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase();
  return <span className="avatar" aria-hidden>{initials || '·'}</span>;
}

// ───────── data table with search, sort and pagination ─────────
export interface Column<T> { key: string; header: string; render: (r: T) => ReactNode; sort?: (a: T, b: T) => number; className?: string }
export function DataTable<T extends { id: string }>({ rows, columns, searchText, filters, pageSize = 10, onRowClick, empty, caption }: {
  rows: T[]; columns: Column<T>[]; searchText?: (r: T) => string; filters?: ReactNode; pageSize?: number; onRowClick?: (r: T) => void; empty: ReactNode; caption: string;
}) {
  const { t } = useI18n();
  const [q, setQ] = useState(''); const [page, setPage] = useState(0);
  const [sort, setSort] = useState<{ key: string; dir: 1 | -1 } | null>(null);
  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    let r = needle && searchText ? rows.filter((x) => searchText(x).toLowerCase().includes(needle)) : rows;
    if (sort) { const c = columns.find((x) => x.key === sort.key); if (c?.sort) r = [...r].sort((a, b) => c.sort!(a, b) * sort.dir); }
    return r;
  }, [rows, q, sort, columns, searchText]);
  useEffect(() => setPage(0), [q, rows.length]);
  const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const view = filtered.slice(page * pageSize, page * pageSize + pageSize);
  return (
    <div className="table-wrap">
      <div className="table-tools">
        {searchText && <div className="search"><LuSearch aria-hidden /><input className="input" type="search" placeholder={t('common.search')} aria-label={t('common.search')} value={q} onChange={(e) => setQ(e.target.value)} /></div>}
        {filters}
      </div>
      {filtered.length === 0 ? empty : (
        <>
          <div className="table-scroll">
            <table className="table stack-m">
              <caption className="sr-only">{caption}</caption>
              <thead><tr>{columns.map((c) => (
                <th key={c.key} scope="col" aria-sort={sort?.key === c.key ? (sort.dir === 1 ? 'ascending' : 'descending') : undefined}>
                  {c.sort ? <button className="th-btn" onClick={() => setSort((s) => (s?.key === c.key ? { key: c.key, dir: (s.dir * -1) as 1 | -1 } : { key: c.key, dir: 1 }))}>{c.header}</button> : c.header}
                </th>))}</tr></thead>
              <tbody>{view.map((r) => (
                <tr key={r.id} className={cx(onRowClick && 'clickable')} onClick={() => onRowClick?.(r)}>
                  {columns.map((c, i) => <td key={c.key} data-label={c.header} className={c.className}>{i === 0 && onRowClick ? <button className="row-link" onClick={(e) => { e.stopPropagation(); onRowClick(r); }}>{c.render(r)}</button> : c.render(r)}</td>)}
                </tr>))}</tbody>
            </table>
          </div>
          {pages > 1 && (
            <nav className="pager" aria-label={t('common.pagination')}>
              <Button size="sm" variant="ghost" disabled={page === 0} onClick={() => setPage((p) => p - 1)} icon={<LuChevronLeft aria-hidden />}>{t('common.previous')}</Button>
              <span className="muted small">{t('common.pageOf', { page: page + 1, pages })}</span>
              <Button size="sm" variant="ghost" disabled={page >= pages - 1} onClick={() => setPage((p) => p + 1)}>{t('common.next')}<LuChevronRight aria-hidden /></Button>
            </nav>
          )}
        </>
      )}
    </div>
  );
}
