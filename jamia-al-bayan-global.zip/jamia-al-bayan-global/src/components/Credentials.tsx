import { useState } from 'react';
import { LuCopy, LuTriangleAlert } from 'react-icons/lu';
import { useI18n } from '../i18n';
import { Button, Modal } from './ui';

export interface CredentialInfo { name: string; loginId: string; password: string; email: boolean }

/** The temporary password is shown exactly once and is not stored anywhere by the app. */
export function CredentialsDialog({ info, onClose }: { info: CredentialInfo | null; onClose: () => void }) {
  const { t } = useI18n(); const [copied, setCopied] = useState(false);
  if (!info) return null;
  const text = `${t('cred.loginId')}: ${info.loginId}\n${t('cred.tempPassword')}: ${info.password}`;
  return (
    <Modal open title={t('cred.title', { name: info.name })} onClose={onClose} footer={<Button variant="primary" onClick={onClose}>{t('cred.done')}</Button>}>
      <p className="privacy-note"><LuTriangleAlert aria-hidden size={18} />{t('cred.once')}</p>
      <dl className="stack" style={{ margin: 0 }}>
        <div><dt className="muted small">{t('cred.loginId')}</dt><dd style={{ margin: 0, fontWeight: 700 }}>{info.loginId}</dd></div>
        <div><dt className="muted small">{t('cred.tempPassword')}</dt><dd style={{ margin: 0, fontFamily: 'ui-monospace, Menlo, monospace', fontSize: '1.2rem', letterSpacing: '.04em', userSelect: 'all' }}>{info.password}</dd></div>
      </dl>
      <Button icon={<LuCopy aria-hidden />} onClick={() => { void navigator.clipboard?.writeText(text).then(() => setCopied(true)); }}>{copied ? t('cred.copied') : t('cred.copy')}</Button>
      <p className="muted small">{t('cred.mustChange')}</p>
    </Modal>
  );
}
