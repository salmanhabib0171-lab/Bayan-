import { useEffect, useMemo, useState } from 'react';
import { LuBell } from 'react-icons/lu';
import { useAuth } from '../lib/auth';
import { ownerScope, useStudents } from '../lib/data';
import { addDays, fmtDateTime, todayStr } from '../lib/dates';
import { useCollection } from '../lib/hooks';
import { Link } from '../lib/router';
import { SERVER_TIME, where } from '../lib/services';
import { needingUpdate } from '../lib/stats';
import type { ClassSession, Conversation, Progress } from '../lib/types';
import { useI18n, type Key } from '../i18n';
import { useAnnouncements } from '../pages/shared/Announcements';
import { isUnread } from '../pages/shared/Messages';
import { Button, Modal } from './ui';

interface Item { id: string; text: string; to: string; kind: 'class' | 'announce' | 'progress' | 'message' }

/** Announcement ids this user has already seen (users/{uid}/reads — private to the user). */
export function useReads() {
  const { user } = useAuth();
  const reads = useCollection<{ id: string }>(user.role === 'principal' ? null : `users/${user.id}/reads`, [], [user.id]);
  return { ids: useMemo(() => new Set(reads.data.map((r) => r.id)), [reads.data]), reload: reads.reload };
}

/** In-app reminders only — no paid push/SMS/email service is involved. */
export function NotificationBell() {
  const { t, lang } = useI18n(); const { user, db } = useAuth();
  const [open, setOpen] = useState(false); const [tick, setTick] = useState(0);
  useEffect(() => { const id = setInterval(() => setTick((n) => n + 1), 5 * 60_000); return () => clearInterval(id); }, []);
  const today = todayStr(); const nowIso = new Date(Date.now() - 15 * 60_000).toISOString();
  const staffOrStudent = user.role !== 'principal';
  const classes = useCollection<ClassSession>(staffOrStudent ? 'classes' : null, user.role === 'teacher' ? [where('teacherId', '==', user.id), where('startsAt', '>=', nowIso)] : [where('studentIds', 'array-contains', user.id), where('startsAt', '>=', nowIso)], [user.id, tick]);
  const annQ = useAnnouncements(tick);
  const convs = useCollection<Conversation>(staffOrStudent ? 'conversations' : null, [where('participants', 'array-contains', user.id)], [user.id, tick]);
  const students = useStudents();
  const progress = useCollection<Progress>(user.role === 'student' ? null : 'progress', [...ownerScope(user), where('date', '>=', addDays(today, -7))], [user.id, tick]);
  const { ids, reload } = useReads();

  const items = useMemo<Item[]>(() => {
    const out: Item[] = [];
    const home = `/${user.role}`;
    classes.data.filter((c) => c.status === 'scheduled' && new Date(c.startsAt).getTime() < Date.now() + 24 * 3600_000).sort((a, b) => a.startsAt.localeCompare(b.startsAt)).slice(0, 3)
      .forEach((c) => out.push({ id: `c-${c.id}`, kind: 'class', text: t('notify.class', { title: c.title, when: fmtDateTime(c.startsAt, lang) }), to: user.role === 'teacher' ? '/teacher/classes' : home }));
    annQ.data.filter((a) => !ids.has(a.id)).forEach((a) => out.push({ id: `a-${a.id}`, kind: 'announce', text: t('notify.announcement', { title: a.title }), to: home }));
    const unread = convs.data.filter((c) => isUnread(c, user.id)).length;
    if (unread) out.push({ id: 'm', kind: 'message', text: t('messages.unreadCount', { n: unread }), to: `${home}/messages` });
    if (user.role !== 'student') {
      const act = students.data.filter((s) => s.status === 'active').map((s) => s.id);
      const n = needingUpdate(act, progress.data, today, user.role === 'teacher' ? 3 : 7).length;
      if (n) out.push({ id: 'p', kind: 'progress', text: t('notify.progress', { n }), to: user.role === 'teacher' ? '/teacher' : '/principal/progress' });
    }
    return out;
  }, [classes.data, annQ.data, convs.data, students.data, progress.data, ids, user, today, t, lang]);

  const unreadAnn = annQ.data.filter((a) => !ids.has(a.id));
  async function markRead() { await Promise.all(unreadAnn.map((a) => db.set(`users/${user.id}/reads`, a.id, { createdAt: SERVER_TIME }).catch(() => undefined))); reload(); }

  return (
    <>
      <button className="icon-btn bell" onClick={() => setOpen(true)} aria-label={t('notify.title', {})} aria-haspopup="dialog">
        <LuBell aria-hidden />{items.length > 0 && <span className="bell-count" aria-label={t('notify.count', { n: items.length })}>{items.length}</span>}
      </button>
      <Modal open={open} onClose={() => setOpen(false)} title={t('notify.title')} footer={unreadAnn.length > 0 ? <Button onClick={() => void markRead()}>{t('notify.markRead')}</Button> : undefined}>
        {items.length === 0 ? <p className="muted">{t('notify.none')}</p> : (
          <ul className="list">{items.map((i) => <li key={i.id}><span>{i.text}</span><Link to={i.to} className="small" onClick={() => setOpen(false)}>{t(`notify.open.${i.kind}` as Key)}</Link></li>)}</ul>)}
        <p className="muted small">{t('notify.note')}</p>
      </Modal>
    </>
  );
}
