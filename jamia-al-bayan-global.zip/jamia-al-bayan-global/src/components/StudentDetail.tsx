import { useEffect, useState } from 'react';
import { LuLock } from 'react-icons/lu';
import { useAuth } from '../lib/auth';
import { ownerScope } from '../lib/data';
import { fmtDate } from '../lib/dates';
import { useCollection } from '../lib/hooks';
import { attendanceRate } from '../lib/stats';
import type { Attendance, Goal, Progress, StudentDoc, StudentPrivate } from '../lib/types';
import { useI18n, type Key } from '../i18n';
import { AttendanceBadge, Badge, Button, EmptyState, Loadable, Modal, ProgressBadge, Segmented, StatusBadge } from './ui';
import { GoalList } from './Goals';
import { ProgressForm } from './ProgressForm';

type Tab = 'overview' | 'history' | 'attendance' | 'private';

export function StudentDetail({ student, onClose, onEdit }: { student: StudentDoc; onClose: () => void; onEdit?: () => void }) {
  const { t, lang } = useI18n(); const { user } = useAuth();
  const [tab, setTab] = useState<Tab>('overview'); const [entry, setEntry] = useState<Progress | 'new' | null>(null);
  const scope = ownerScope(user, student.id);
  const goals = useCollection<Goal>('goals', scope, [student.id]);
  const progress = useCollection<Progress>('progress', scope, [student.id]);
  const att = useCollection<Attendance>('attendance', scope, [student.id]);
  const hist = [...progress.data].sort((a, b) => b.date.localeCompare(a.date) || (b.createdAt ?? '').localeCompare(a.createdAt ?? ''));
  const attRows = [...att.data].sort((a, b) => b.date.localeCompare(a.date));
  const rate = attendanceRate(att.data);
  const tabs: { value: Tab; label: string }[] = [{ value: 'overview', label: t('detail.overview') }, { value: 'history', label: t('detail.history') }, { value: 'attendance', label: t('nav.attendance') }];
  if (user.role === 'principal') tabs.push({ value: 'private', label: t('detail.private') });

  return (
    <Modal open wide onClose={onClose} title={student.displayName} footer={<>
      {onEdit && <Button onClick={onEdit}>{t('common.edit')}</Button>}
      {user.role !== 'student' && <Button variant="primary" onClick={() => setEntry('new')}>{t('progress.newEntry')}</Button>}
    </>}>
      <div className="row">
        <Badge tone="teal">{t(`track.${student.track}` as Key)}</Badge><Badge>{student.studentCode}</Badge><StatusBadge status={student.status} />
        <span className="muted small">{student.level} · {t('field.teacher')}: {student.teacherName}</span>
      </div>
      <Segmented<Tab> label={t('detail.sections')} value={tab} onChange={setTab} options={tabs} />
      {tab === 'overview' && <Loadable loading={goals.loading} error={goals.error} onRetry={goals.reload}>
        <GoalList goals={[...goals.data].sort((a, b) => (b.createdAt ?? '').localeCompare(a.createdAt ?? ''))} student={student} canEdit={user.role !== 'student'} onChanged={goals.reload} />
        <p className="muted small">{t('field.enrollmentDate')}: {fmtDate(student.enrollmentDate, lang)} · {student.country} · {student.timeZone}</p>
      </Loadable>}
      {tab === 'history' && <Loadable loading={progress.loading} error={progress.error} onRetry={progress.reload}>
        {hist.length === 0 ? <EmptyState title={t('progress.none')} /> : (
          <ul className="list">{hist.map((p) => (
            <li key={p.id}><div>
              <strong>{p.lesson}</strong> <span className="muted small">· {fmtDate(p.date, lang)}</span>
              {p.feedback && <p className="small">{p.feedback}</p>}
              {p.homework && <p className="muted small">{t('progress.homework')}: {p.homework}</p>}
              <p className="muted small">{t('progress.submittedBy', { name: p.createdByName })}</p>
            </div><div className="row"><ProgressBadge status={p.status} />{user.role !== 'student' && <Button size="sm" variant="ghost" onClick={() => setEntry(p)}>{t('common.edit')}</Button>}</div></li>))}
          </ul>)}
      </Loadable>}
      {tab === 'attendance' && <Loadable loading={att.loading} error={att.error} onRetry={att.reload}>
        <p className="muted small">{rate.value === null ? t('stats.notEnough') : t('stats.attendanceRate', { pct: rate.value, n: rate.n, d: rate.d })} {t('stats.attendanceMethod')}</p>
        {attRows.length === 0 ? <EmptyState title={t('attendance.none')} /> : <ul className="list">{attRows.slice(0, 40).map((a) => <li key={a.id}><span>{fmtDate(a.date, lang)}</span><AttendanceBadge status={a.status} /></li>)}</ul>}
      </Loadable>}
      {tab === 'private' && user.role === 'principal' && <PrivatePanel studentId={student.id} />}
      {entry && <ProgressForm open students={[student]} initialStudentId={student.id} existing={entry === 'new' ? undefined : entry} onClose={() => setEntry(null)} onSaved={progress.reload} />}
    </Modal>
  );
}

/** Principal-only. Fetched on demand so private data is never loaded for any other role or screen. */
function PrivatePanel({ studentId }: { studentId: string }) {
  const { t } = useI18n(); const { db } = useAuth();
  const [d, setD] = useState<StudentPrivate | null | undefined>(undefined); const [err, setErr] = useState(false);
  useEffect(() => { let on = true; db.get<StudentPrivate>('studentPrivate', studentId).then((x) => on && setD(x)).catch(() => on && setErr(true)); return () => { on = false; }; }, [db, studentId]);
  if (err) return <p role="alert">{t('error.load')}</p>;
  if (d === undefined) return <p className="muted">{t('common.loading')}</p>;
  const rows: [Key, string | undefined][] = [['private.legalName', d?.legalName], ['private.guardianName', d?.guardianName], ['private.guardianPhone', d?.guardianPhone], ['private.guardianEmail', d?.guardianEmail], ['private.address', d?.address], ['private.loginContact', d?.loginContact], ['private.notes', d?.notes]];
  return (
    <div className="stack">
      <p className="privacy-note"><LuLock aria-hidden size={18} />{t('private.notice')}</p>
      <dl className="stack" style={{ margin: 0 }}>{rows.map(([k, v]) => <div key={k}><dt className="muted small">{t(k)}</dt><dd style={{ margin: 0 }}>{v || '—'}</dd></div>)}</dl>
    </div>
  );
}
