import { useI18n } from '../i18n';
// The supplied academy artwork is used unmodified (never redrawn or recoloured); only its crop/size changes.
export function LogoFull({ className }: { className?: string }) {
  const { t } = useI18n();
  return <img className={className} src="/logo-full.png" width={1100} height={1320} alt={t('app.name')} decoding="async" />;
}
export function LogoMark({ size = 44 }: { size?: number }) {
  return <img src="/logo-emblem.png" width={size} height={Math.round(size * 0.912)} alt="" decoding="async" />;
}
