import { useMemo, useState } from 'react';
import { useAuth } from '../lib/auth';
import { newId } from '../lib/data';
import { todayStr } from '../lib/dates';
import { useCollection } from '../lib/hooks';
import { SERVER_TIME, where } from '../lib/services';
import { PROGRESS_STATUSES, TRACKS, type Lesson, type Progress, type ProgressStatus, type StudentDoc, type Track } from '../lib/types';
import { useI18n, type Key } from '../i18n';
import { Button, Field, Input, Modal, Select, Segmented, Textarea, useToast } from './ui';

/** Daily progress entry. Visible feedback goes to the student; the internal note never does (separate collection). */
export function ProgressForm({ open, onClose, students, initialStudentId, existing, onSaved }: {
  open: boolean; onClose: () => void; students: StudentDoc[]; initialStudentId?: string; existing?: Progress; onSaved: () => void;
}) {
  const { t } = useI18n(); const { db, user } = useAuth(); const toast = useToast();
  const active = students.filter((s) => s.status === 'active');
  const [sid, setSid] = useState(existing?.studentId ?? initialStudentId ?? active[0]?.id ?? '');
  const student = students.find((s) => s.id === sid);
  const [track, setTrack] = useState<Track>(existing?.track ?? student?.track ?? 'qaida');
  const [date, setDate] = useState(existing?.date ?? todayStr());
  const [lesson, setLesson] = useState(existing?.lesson ?? ''); const [objectives, setObjectives] = useState(existing?.objectives ?? '');
  const [status, setStatus] = useState<ProgressStatus>(existing?.status ?? 'in_progress');
  const [practice, setPractice] = useState(existing?.practice ?? ''); const [homework, setHomework] = useState(existing?.homework ?? '');
  const [feedback, setFeedback] = useState(existing?.feedback ?? ''); const [followUp, setFollowUp] = useState(existing?.followUp ?? '');
  const [note, setNote] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({}); const [busy, setBusy] = useState(false);
  const [docId] = useState(() => existing?.id ?? newId()); // one id per form → a retry after a network error cannot create a duplicate
  const lessons = useCollection<Lesson>('lessons', [where('status', '==', 'published')], []);
  const titles = useMemo(() => lessons.data.map((l) => l.title), [lessons.data]);

  async function save() {
    const e: Record<string, string> = {};
    if (!student) e.student = t('validation.required');
    if (!date || date > todayStr()) e.date = t('validation.dateFuture');
    if (!lesson.trim()) e.lesson = t('validation.required');
    setErrors(e); if (Object.keys(e).length || !student) return;
    setBusy(true);
    try {
      const data = { studentId: student.id, teacherId: student.teacherId, track, date, lesson: lesson.trim(), objectives: objectives.trim(), status, practice: practice.trim(), homework: homework.trim(), feedback: feedback.trim(), followUp: followUp.trim() };
      if (existing) await db.update('progress', docId, data);
      else await db.set('progress', docId, { ...data, createdBy: user.id, createdByName: user.displayName, createdAt: SERVER_TIME });
      if (note.trim()) await db.set('progressNotes', docId, { studentId: student.id, teacherId: student.teacherId, note: note.trim() }, true);
      toast('ok', t('toast.progressSaved')); onSaved(); onClose();
    } catch { toast('err', t('error.save')); } finally { setBusy(false); }
  }
  const area = (label: Key, v: string, set: (s: string) => void, max = 600, hint?: Key) =>
    <Field label={t(label)} hint={hint ? t(hint) : undefined}>{(id, d) => <Textarea id={id} aria-describedby={d} maxLength={max} value={v} onChange={(e) => set(e.target.value)} />}</Field>;

  return (
    <Modal open={open} onClose={onClose} wide title={existing ? t('progress.editEntry') : t('progress.newEntry')}
      footer={<><Button variant="ghost" onClick={onClose}>{t('common.cancel')}</Button><Button variant="primary" loading={busy} onClick={save}>{t('progress.saveEntry')}</Button></>}>
      <div className="form-grid">
        <Field label={t('field.student')} required error={errors.student}>{(id) => (
          <Select id={id} value={sid} disabled={Boolean(existing)} onChange={(e) => { setSid(e.target.value); const s = students.find((x) => x.id === e.target.value); if (s) setTrack(s.track); }}>
            {active.map((s) => <option key={s.id} value={s.id}>{s.displayName} · {s.studentCode}</option>)}
          </Select>)}</Field>
        <Field label={t('field.course')}>{(id) => <Select id={id} value={track} onChange={(e) => setTrack(e.target.value as Track)}>{TRACKS.map((x) => <option key={x} value={x}>{t(`track.${x}` as Key)}</option>)}</Select>}</Field>
        <Field label={t('field.lessonDate')} required error={errors.date}>{(id, d) => <Input id={id} aria-describedby={d} type="date" max={todayStr()} value={date} onChange={(e) => setDate(e.target.value)} />}</Field>
        <Field label={t('progress.lesson')} required error={errors.lesson}>{(id, d) => <><Input id={id} aria-describedby={d} list="lesson-titles" maxLength={200} value={lesson} onChange={(e) => setLesson(e.target.value)} /><datalist id="lesson-titles">{titles.map((x) => <option key={x} value={x} />)}</datalist></>}</Field>
        <div className="full"><Field label={t('field.status')}>{(id) => <div id={id}><Segmented<ProgressStatus> label={t('field.status')} value={status} onChange={setStatus} options={PROGRESS_STATUSES.map((s) => ({ value: s, label: t(`progress.${s}` as Key) }))} /></div>}</Field></div>
        <div className="full">{area('progress.objectives', objectives, setObjectives)}</div>
        {area('progress.practice', practice, setPractice)}
        {area('progress.homework', homework, setHomework)}
        <div className="full">{area('progress.feedback', feedback, setFeedback, 1000, 'progress.feedbackHint')}</div>
        {area('progress.followUp', followUp, setFollowUp)}
        {area('progress.internalNote', note, setNote, 600, 'progress.internalHint')}
      </div>
    </Modal>
  );
}
