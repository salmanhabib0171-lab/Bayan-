import { useSession } from '../lib/auth';
import type { Lang } from '../lib/types';

/** Returns a function that saves the language to the signed-in user's profile, or undefined on the login screen. */
export function useSessionOptional(): ((l: Lang) => Promise<void>) | undefined {
  const s = useSession();
  if (!s.user || !s.services) return undefined;
  const { user, services } = s;
  return async (l: Lang) => { try { await services.db.update('users', user.id, { language: l }); } catch { /* the device preference still applies */ } };
}
