import { useI18n } from '../i18n';
import { useSessionOptional } from './sessionBridge';
import { Segmented } from './ui';
import type { Lang } from '../lib/types';

/** Switches language immediately and, when signed in, saves it to the user's own account. */
export function LanguageSwitch() {
  const { lang, setLang, t } = useI18n();
  const persist = useSessionOptional();
  return (
    <Segmented<Lang> label={t('settings.language')} value={lang} onChange={(l) => { setLang(l); void persist?.(l); }}
      options={[{ value: 'en', label: 'English' }, { value: 'bn', label: 'বাংলা' }]} />
  );
}
