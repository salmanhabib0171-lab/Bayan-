import { useState, type ReactNode } from 'react';
import {
  LuBell, LuBookOpen, LuCalendarCheck, LuCalendarDays, LuChartColumn, LuClipboardList, LuEllipsis, LuGraduationCap, LuHouse, LuLogOut, LuMessageCircle,
  LuScrollText, LuSettings, LuUsers, LuUserRoundCog,
} from 'react-icons/lu';
import { useAuth } from '../lib/auth';
import { useOnline } from '../lib/hooks';
import { Link, usePath } from '../lib/router';
import type { Role } from '../lib/types';
import { useI18n, type Key } from '../i18n';
import { LogoMark } from './Brand';
import { LanguageSwitch } from './LanguageSwitch';
import { NotificationBell } from './Notifications';
import { Avatar, Modal } from './ui';

export interface NavItem { to: string; icon: ReactNode; label: Key }
const I = { w: 20 };
export const NAV: Record<Role, NavItem[]> = {
  principal: [
    { to: '/principal', icon: <LuHouse size={I.w} />, label: 'nav.dashboard' },
    { to: '/principal/students', icon: <LuGraduationCap size={I.w} />, label: 'nav.students' },
    { to: '/principal/teachers', icon: <LuUserRoundCog size={I.w} />, label: 'nav.teachers' },
    { to: '/principal/classes', icon: <LuCalendarDays size={I.w} />, label: 'nav.classes' },
    { to: '/principal/attendance', icon: <LuCalendarCheck size={I.w} />, label: 'nav.attendance' },
    { to: '/principal/progress', icon: <LuClipboardList size={I.w} />, label: 'nav.progress' },
    { to: '/principal/resources', icon: <LuBookOpen size={I.w} />, label: 'nav.resources' },
    { to: '/principal/announcements', icon: <LuBell size={I.w} />, label: 'nav.announcements' },
    { to: '/principal/reports', icon: <LuChartColumn size={I.w} />, label: 'nav.reports' },
    { to: '/principal/audit', icon: <LuScrollText size={I.w} />, label: 'nav.audit' },
    { to: '/settings', icon: <LuSettings size={I.w} />, label: 'nav.settings' },
  ],
  teacher: [
    { to: '/teacher', icon: <LuHouse size={I.w} />, label: 'nav.dashboard' },
    { to: '/teacher/students', icon: <LuUsers size={I.w} />, label: 'nav.myStudents' },
    { to: '/teacher/progress', icon: <LuClipboardList size={I.w} />, label: 'nav.progress' },
    { to: '/teacher/classes', icon: <LuCalendarDays size={I.w} />, label: 'nav.classes' },
    { to: '/teacher/messages', icon: <LuMessageCircle size={I.w} />, label: 'nav.messages' },
    { to: '/teacher/resources', icon: <LuBookOpen size={I.w} />, label: 'nav.resources' },
    { to: '/settings', icon: <LuSettings size={I.w} />, label: 'nav.settings' },
  ],
  student: [
    { to: '/student', icon: <LuHouse size={I.w} />, label: 'nav.home' },
    { to: '/student/resources', icon: <LuBookOpen size={I.w} />, label: 'nav.learn' },
    { to: '/student/messages', icon: <LuMessageCircle size={I.w} />, label: 'nav.messages' },
    { to: '/settings', icon: <LuSettings size={I.w} />, label: 'nav.settings' },
  ],
};
export const homeFor = (r: Role) => NAV[r][0].to;

export function Shell({ children }: { children: ReactNode }) {
  const { user, signOut, mode } = useAuth();
  const { t } = useI18n(); const path = usePath(); const online = useOnline();
  const [more, setMore] = useState(false);
  const items = NAV[user.role];
  const active = (to: string) => (path === to || (to !== homeFor(user.role) && path.startsWith(`${to}/`)) ? 'page' : undefined);
  const tabs = items.length > 5 ? items.slice(0, 4) : items;
  const rest = items.length > 5 ? items.slice(4) : [];

  return (
    <div>
      {mode === 'demo' && <div className="banner banner-demo" role="status">{t('demo.banner')}</div>}
      {!online && <div className="banner banner-off" role="status">{t('offline.banner')}</div>}
      <div className="shell">
        <aside className="sidebar" aria-label={t('nav.main')}>
          <Link to={homeFor(user.role)} className="brand"><LogoMark /><span>Jamia<br />Al-Bayan Global</span></Link>
          <nav className="nav">{items.map((n) => <Link key={n.to} to={n.to} aria-current={active(n.to)}>{n.icon}{t(n.label)}</Link>)}</nav>
          <div className="side-foot">
            <div className="userchip"><Avatar name={user.displayName} /><div><strong>{user.displayName}</strong><small>{t(`role.${user.role}` as Key)}</small></div></div>
            <button className="btn btn-ghost btn-sm" onClick={() => void signOut()}><LuLogOut aria-hidden />{t('auth.signOut')}</button>
          </div>
        </aside>
        <div className="main">
          <header className="topbar">
            <Link to={homeFor(user.role)} className="brand"><LogoMark size={34} /></Link>
            <div className="row"><NotificationBell /><LanguageSwitch /></div>
          </header>
          <main className="content" id="main">{children}</main>
        </div>
      </div>
      <nav className="tabbar" aria-label={t('nav.main')}>
        {tabs.map((n) => <Link key={n.to} to={n.to} aria-current={active(n.to)}>{n.icon}<span>{t(n.label)}</span></Link>)}
        {rest.length > 0 && <button onClick={() => setMore(true)} aria-haspopup="dialog"><LuEllipsis size={22} /><span>{t('nav.more')}</span></button>}
        {rest.length === 0 && <button onClick={() => void signOut()}><LuLogOut size={22} /><span>{t('auth.signOut')}</span></button>}
      </nav>
      <Modal open={more} title={t('nav.more')} onClose={() => setMore(false)}>
        <nav className="nav">{rest.map((n) => <Link key={n.to} to={n.to} aria-current={active(n.to)} onClick={() => setMore(false)}>{n.icon}{t(n.label)}</Link>)}</nav>
        <button className="btn" onClick={() => void signOut()}><LuLogOut aria-hidden />{t('auth.signOut')}</button>
      </Modal>
    </div>
  );
}
