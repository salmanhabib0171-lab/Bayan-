import { createContext, useContext, useEffect, useState, type AnchorHTMLAttributes, type ReactNode } from 'react';

// Minimal History-API router (keeps the dependency list short; Netlify's SPA fallback serves index.html for every path).
const subs = new Set<() => void>();
export function navigate(to: string, replace = false) {
  if (to === window.location.pathname) return;
  (replace ? history.replaceState : history.pushState).call(history, null, '', to);
  subs.forEach((f) => f());
}
const Ctx = createContext<string>('/');
export function RouterProvider({ children }: { children: ReactNode }) {
  const [path, setPath] = useState(window.location.pathname);
  useEffect(() => {
    const on = () => setPath(window.location.pathname);
    subs.add(on); window.addEventListener('popstate', on);
    return () => { subs.delete(on); window.removeEventListener('popstate', on); };
  }, []);
  return <Ctx.Provider value={path.replace(/\/+$/, '') || '/'}>{children}</Ctx.Provider>;
}
export const usePath = () => useContext(Ctx);

export function Link({ to, onClick, ...rest }: AnchorHTMLAttributes<HTMLAnchorElement> & { to: string }) {
  return (
    <a
      href={to}
      onClick={(e) => {
        onClick?.(e);
        if (e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
        e.preventDefault(); navigate(to);
      }}
      {...rest}
    />
  );
}
