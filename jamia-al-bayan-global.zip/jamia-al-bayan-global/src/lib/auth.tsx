import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { getServices, type Services } from './services';
import type { UserDoc } from './types';
import { useI18n } from '../i18n';

type Phase = 'loading' | 'out' | 'in' | 'error';
interface Session {
  phase: Phase; user: UserDoc | null; services: Services | null; notice: 'disabled' | 'no_profile' | null;
  refreshUser: () => Promise<void>; signOut: () => Promise<void>;
}
const Ctx = createContext<Session | null>(null);

/** Everything the app keeps in browser storage other than the language preference is wiped on sign-out. */
async function clearLocalState() {
  try { sessionStorage.clear(); } catch { /* ignore */ }
  try { Object.keys(localStorage).filter((k) => k !== 'albayan.lang').forEach((k) => localStorage.removeItem(k)); } catch { /* ignore */ }
  try { (await navigator.serviceWorker?.getRegistration())?.active?.postMessage('CLEAR_CACHES'); } catch { /* ignore */ }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const { setLang } = useI18n();
  const [phase, setPhase] = useState<Phase>('loading');
  const [user, setUser] = useState<UserDoc | null>(null);
  const [services, setServices] = useState<Services | null>(null);
  const [notice, setNotice] = useState<Session['notice']>(null);
  const svc = useRef<Services | null>(null);

  const load = useCallback(async (uid: string | null) => {
    const s = svc.current!;
    if (!uid) { setUser(null); setPhase('out'); return; }
    try {
      const u = await s.db.get<UserDoc>('users', uid);
      if (!u) { setNotice('no_profile'); await s.auth.signOut(); return; }
      if (u.status !== 'active') { setNotice('disabled'); await s.auth.signOut(); return; }
      setNotice(null); setUser(u); setPhase('in');
      if (u.language) setLang(u.language);
    } catch { setPhase('error'); }
  }, [setLang]);

  useEffect(() => {
    let unsub = () => undefined as void;
    getServices().then((s) => { svc.current = s; setServices(s); unsub = s.auth.onChange((uid) => { void load(uid); }) as never; })
      .catch(() => setPhase('error'));
    return () => unsub();
  }, [load]);

  const signOut = useCallback(async () => {
    await svc.current?.auth.signOut();
    setUser(null); setPhase('out'); await clearLocalState();
  }, []);
  const refreshUser = useCallback(async () => {
    if (user && svc.current) { const u = await svc.current.db.get<UserDoc>('users', user.id); if (u) setUser(u); }
  }, [user]);

  const value = useMemo(() => ({ phase, user, services, notice, refreshUser, signOut }), [phase, user, services, notice, refreshUser, signOut]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
export function useSession(): Session { const v = useContext(Ctx); if (!v) throw new Error('AuthProvider missing'); return v; }
/** For screens rendered only when signed in. */
export function useAuth() {
  const s = useSession();
  if (!s.user || !s.services) throw new Error('Not signed in');
  return { user: s.user, db: s.services.db, admin: s.services.admin, auth: s.services.auth, mode: s.services.mode, refreshUser: s.refreshUser, signOut: s.signOut };
}
