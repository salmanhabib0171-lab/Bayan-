import type { AccountStatus, Lang, Track } from './types';

export type Op = '==' | 'in' | 'array-contains' | '>=' | '<=';
export type Constraint =
  | { t: 'where'; field: string; op: Op; value: unknown }
  | { t: 'orderBy'; field: string; dir: 'asc' | 'desc' }
  | { t: 'limit'; n: number };
export const where = (field: string, op: Op, value: unknown): Constraint => ({ t: 'where', field, op, value });
export const orderBy = (field: string, dir: 'asc' | 'desc' = 'asc'): Constraint => ({ t: 'orderBy', field, dir });
export const limit = (n: number): Constraint => ({ t: 'limit', n });

/** Replaced by the backend's trusted clock on write (Firestore serverTimestamp). */
export const SERVER_TIME = { __serverTime: true } as const;

export type Row<T> = T & { id: string };
export type Unsub = () => void;
export type BatchOp =
  | { op: 'set'; path: string; id: string; data: Record<string, unknown>; merge?: boolean }
  | { op: 'update'; path: string; id: string; data: Record<string, unknown> }
  | { op: 'delete'; path: string; id: string };

export interface DataStore {
  list<T>(path: string, c?: Constraint[]): Promise<Row<T>[]>;
  get<T>(path: string, id: string): Promise<Row<T> | null>;
  set(path: string, id: string, data: Record<string, unknown>, merge?: boolean): Promise<void>;
  add(path: string, data: Record<string, unknown>): Promise<string>;
  update(path: string, id: string, data: Record<string, unknown>): Promise<void>;
  remove(path: string, id: string): Promise<void>;
  batch(ops: BatchOp[]): Promise<void>;
  watch<T>(path: string, c: Constraint[], cb: (rows: Row<T>[]) => void, onError: (e: Error) => void): Unsub;
}

export type AuthErrorCode = 'invalid_credentials' | 'disabled' | 'too_many' | 'network' | 'wrong_password' | 'weak_password' | 'unknown';
export class AuthError extends Error { constructor(public code: AuthErrorCode) { super(code); } }
export class ApiError extends Error { constructor(public code: string, public status = 0, public fields: string[] = []) { super(code); } }

export interface AuthService {
  onChange(cb: (uid: string | null) => void): Unsub;
  signIn(identifier: string, password: string): Promise<void>;
  signOut(): Promise<void>;
  changePassword(current: string, next: string): Promise<void>;
  sendReset(email: string): Promise<void>;
}

export interface CreateUserInput {
  role: 'student' | 'teacher'; code: string; displayName: string; email: string; language: Lang;
  student?: { track: Track; level: string; teacherId: string; enrollmentDate: string; country: string; timeZone: string };
  teacher?: { responsibilities: string[] };
  private?: { legalName: string; guardianName: string; guardianPhone: string; guardianEmail: string; address: string; notes: string };
}
export interface AdminApi {
  createUser(i: CreateUserInput): Promise<{ uid: string; loginId: string; authEmailIsReal: boolean; temporaryPassword: string }>;
  setStatus(uid: string, status: AccountStatus): Promise<void>;
  resetPassword(uid: string): Promise<{ temporaryPassword: string }>;
  reassign(studentId: string, teacherId: string): Promise<{ moved: number }>;
  updateProfile(uid: string, p: { displayName?: string; language?: Lang }): Promise<void>;
}

export interface Services { mode: 'firebase' | 'demo'; auth: AuthService; db: DataStore; admin: AdminApi }

export const DEMO = import.meta.env.VITE_DEMO_MODE === 'true';

let cached: Promise<Services> | null = null;
export function getServices(): Promise<Services> {
  if (!cached) {
    cached = DEMO ? import('./demoServices').then((m) => m.createDemoServices()) : import('./firebaseServices').then((m) => m.createFirebaseServices());
  }
  return cached;
}

export const loginDomain = () => import.meta.env.VITE_LOGIN_EMAIL_DOMAIN || 'login.jamia-albayan.example';
export function toAuthEmail(identifier: string): string {
  const v = identifier.trim();
  return v.includes('@') ? v.toLowerCase() : `${v.replace(/\s+/g, '').toLowerCase()}@${loginDomain()}`;
}
