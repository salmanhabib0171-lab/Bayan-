import { toCsv } from './stats';

/** Client-side CSV download. Only data the signed-in Principal could already read is ever exported. */
export function downloadCsv(filename: string, rows: Record<string, string | number | boolean | undefined>[]) {
  const blob = new Blob([toCsv(rows)], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = filename; a.rel = 'noopener';
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
