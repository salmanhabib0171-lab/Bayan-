export type Role = 'principal' | 'teacher' | 'student';
export type Lang = 'en' | 'bn';
export type Track = 'qaida' | 'ampara' | 'quran';
export type AccountStatus = 'active' | 'inactive' | 'archived';
export type ProgressStatus = 'not_started' | 'in_progress' | 'practicing' | 'achieved';
export type AttendanceStatus = 'present' | 'absent' | 'late' | 'excused';
export type ContentStatus = 'draft' | 'in_review' | 'published';
export type Audience = 'all' | 'teachers' | 'students' | 'student';

export const TRACKS: Track[] = ['qaida', 'ampara', 'quran'];
export const PROGRESS_STATUSES: ProgressStatus[] = ['not_started', 'in_progress', 'practicing', 'achieved'];
export const ATTENDANCE_STATUSES: AttendanceStatus[] = ['present', 'late', 'absent', 'excused'];

type WithId = { id: string };
/** ISO-8601 string (server timestamps are converted on read). */
export type Iso = string;

export interface UserDoc extends WithId {
  role: Role; status: AccountStatus; displayName: string; code: string; language: Lang; mustChangePassword: boolean;
}
export interface StudentDoc extends WithId {
  studentCode: string; displayName: string; track: Track; level: string; teacherId: string; teacherName: string;
  enrollmentDate: string; language: Lang; country: string; timeZone: string; status: AccountStatus; createdAt?: Iso; updatedAt?: Iso;
}
/** PRINCIPAL-ONLY. Never fetched outside principal screens. */
export interface StudentPrivate extends WithId {
  legalName: string; guardianName: string; guardianPhone: string; guardianEmail: string; address: string; notes: string; loginContact?: string;
}
export interface TeacherDoc extends WithId {
  teacherCode: string; displayName: string; language: Lang; status: AccountStatus; responsibilities: string[]; createdAt?: Iso;
}
export interface Goal extends WithId {
  studentId: string; teacherId: string; title: string; description: string; status: ProgressStatus; targetDate: string;
  createdBy: string; createdAt?: Iso;
}
export interface Progress extends WithId {
  studentId: string; teacherId: string; track: Track; date: string; lesson: string; objectives: string; status: ProgressStatus;
  practice: string; homework: string; feedback: string; followUp: string; createdBy: string; createdByName: string; createdAt?: Iso;
}
export interface ProgressNote extends WithId { studentId: string; teacherId: string; note: string }
export interface Attendance extends WithId {
  studentId: string; teacherId: string; classId: string; date: string; status: AttendanceStatus; note: string; recordedBy: string; updatedAt?: Iso;
}
export interface ClassSession extends WithId {
  title: string; teacherId: string; teacherName: string; studentIds: string[]; studentNames: string[]; startsAt: Iso; timeZone: string;
  durationMin: number; zoomUrl: string; notes: string; status: 'scheduled' | 'completed' | 'cancelled'; createdBy: string;
}
export interface Assignment extends WithId {
  studentId: string; teacherId: string; lessonId: string; lessonTitle: string; note: string; completed: boolean; createdBy: string; createdAt?: Iso; completedAt?: Iso;
}
export interface Conversation extends WithId {
  teacherId: string; studentId: string; teacherName: string; studentName: string; participants: string[];
  lastMessageAt?: Iso; lastSenderId?: string; lastPreview?: string; readAt?: Record<string, Iso>;
}
export interface Message extends WithId { senderId: string; text: string; createdAt?: Iso }
export interface Announcement extends WithId {
  title: string; body: string; audience: Audience; targetStudentId?: string; createdBy: string; createdAt?: Iso;
}
export interface Lesson extends WithId {
  title: string; titleBn: string; section: 'letters' | 'harakat' | 'reading' | 'practice'; arabicItems: string[];
  instructions: string; instructionsBn: string; order: number; status: ContentStatus; sourceVerified: boolean;
  reviewedBy: string; reviewerName: string; createdBy: string;
}
export interface Dua extends WithId {
  title: string; category: string; arabic: string; transliteration: string; meaningEn: string; meaningBn: string;
  source: string; status: ContentStatus; sourceVerified: boolean; reviewedBy: string; reviewerName: string; createdBy: string;
}
export interface AuditEntry extends WithId { actorId: string; action: string; targetId: string; meta?: Record<string, string | number | boolean>; createdAt?: Iso }
export interface Settings { defaultLanguage: Lang; academyName: string; defaultDuration?: number; defaultTimeZone?: string }
