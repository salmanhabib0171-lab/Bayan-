// In-memory backend for the EXPLICIT demo mode. Nothing is persisted; reloading resets everything.
import { buildSeed } from './demoSeed';
import { ApiError, AuthError, toAuthEmail, type BatchOp, type Constraint, type Services, SERVER_TIME } from './services';

type Rec = Record<string, any>;

export function createDemoServices(): Services {
  const data = new Map<string, Map<string, Rec>>();
  const seed = buildSeed();
  Object.entries(seed).forEach(([path, rows]) => data.set(path, new Map(Object.entries(rows).map(([id, r]) => [id, structuredClone(r)]))));
  const col = (p: string) => { if (!data.has(p)) data.set(p, new Map()); return data.get(p)!; };
  const resolve = (v: unknown): any => {
    if (v === SERVER_TIME || (v && typeof v === 'object' && (v as any).__serverTime)) return new Date().toISOString();
    if (Array.isArray(v)) return v.map(resolve);
    if (v && typeof v === 'object') return Object.fromEntries(Object.entries(v).filter(([, x]) => x !== undefined).map(([k, x]) => [k, resolve(x)]));
    return v;
  };

  const listeners = new Set<{ path: string; c: Constraint[]; run: () => void }>();
  const notify = (path: string) => listeners.forEach((l) => l.path === path && l.run());
  const query = (path: string, c: Constraint[] = []) => {
    let rows = [...col(path).entries()].map(([id, r]) => ({ ...structuredClone(r), id }));
    for (const x of c) {
      if (x.t !== 'where') continue;
      rows = rows.filter((r: Rec) => {
        const v = r[x.field];
        if (x.op === '==') return v === x.value;
        if (x.op === 'in') return (x.value as unknown[]).includes(v);
        if (x.op === 'array-contains') return Array.isArray(v) && v.includes(x.value);
        if (x.op === '>=') return v >= (x.value as never);
        return v <= (x.value as never);
      });
    }
    for (const x of [...c].reverse()) {
      if (x.t === 'orderBy') rows.sort((a: Rec, b: Rec) => (String(a[x.field] ?? '') < String(b[x.field] ?? '') ? -1 : 1) * (x.dir === 'asc' ? 1 : -1));
    }
    const lim = c.find((x) => x.t === 'limit');
    return lim && lim.t === 'limit' ? rows.slice(0, lim.n) : rows;
  };
  let seq = 100;

  const store = {
    async list<T>(path: string, c?: Constraint[]) { await tick(); return query(path, c) as any as (T & { id: string })[]; },
    async get<T>(path: string, id: string) { await tick(); const r = col(path).get(id); return r ? ({ ...structuredClone(r), id } as any as T & { id: string }) : null; },
    async set(path: string, id: string, d: Rec, merge?: boolean) { col(path).set(id, merge ? { ...(col(path).get(id) ?? {}), ...resolve(d) } : resolve(d)); notify(path); },
    async add(path: string, d: Rec) { const id = `demo${++seq}`; col(path).set(id, resolve(d)); notify(path); return id; },
    async update(path: string, id: string, d: Rec) {
      const cur = col(path).get(id); if (!cur) throw new Error('not_found');
      col(path).set(id, { ...cur, ...resolve(d) }); notify(path);
    },
    async remove(path: string, id: string) { col(path).delete(id); notify(path); },
    async batch(ops: BatchOp[]) {
      for (const o of ops) {
        if (o.op === 'set') await store.set(o.path, o.id, o.data, o.merge);
        else if (o.op === 'update') await store.update(o.path, o.id, o.data);
        else await store.remove(o.path, o.id);
      }
    },
    watch<T>(path: string, c: Constraint[], cb: (r: (T & { id: string })[]) => void) {
      const l = { path, c, run: () => cb(query(path, c) as any) };
      listeners.add(l); setTimeout(l.run, 0);
      return () => { listeners.delete(l); };
    },
  };
  const tick = () => new Promise((r) => setTimeout(r, 60));

  // ── auth: password "demo" for every seeded account ──
  const passwords = new Map<string, string>();
  const authSubs = new Set<(uid: string | null) => void>();
  let current: string | null = null;
  const setCurrent = (u: string | null) => { current = u; authSubs.forEach((f) => f(u)); };
  const findUid = (identifier: string) => {
    const id = identifier.trim().toLowerCase();
    const email = toAuthEmail(id);
    for (const [uid, u] of col('users')) if (String(u.code).toLowerCase() === id || `${String(u.code).toLowerCase()}@${email.split('@')[1]}` === email) return uid;
    return null;
  };
  const tempPw = () => Array.from({ length: 12 }, () => 'abcdefghjkmnpqrstuvwxyz23456789'[Math.floor(Math.random() * 31)]).join('');

  return {
    mode: 'demo',
    db: store,
    auth: {
      onChange(cb) { authSubs.add(cb); setTimeout(() => cb(current), 0); return () => authSubs.delete(cb); },
      async signIn(identifier, password) {
        await tick();
        const uid = findUid(identifier);
        if (!uid || (passwords.get(uid) ?? 'demo') !== password) throw new AuthError('invalid_credentials');
        if (col('users').get(uid)!.status !== 'active') throw new AuthError('disabled');
        setCurrent(uid);
      },
      async signOut() { setCurrent(null); },
      async changePassword(cur, next) {
        if ((passwords.get(current!) ?? 'demo') !== cur) throw new AuthError('wrong_password');
        if (next.length < 8) throw new AuthError('weak_password');
        passwords.set(current!, next);
      },
      async sendReset() { /* demo: no email is sent */ },
    },
    admin: {
      async createUser(i) {
        await tick();
        const code = i.code.trim().toUpperCase();
        if ([...col('users').values()].some((u) => u.code === code)) throw new ApiError('code_taken', 409);
        const uid = `demo-${i.role}-${++seq}`;
        const pw = tempPw(); passwords.set(uid, pw);
        col('users').set(uid, { role: i.role, status: 'active', displayName: i.displayName, code, language: i.language, mustChangePassword: true });
        const now = new Date().toISOString();
        if (i.role === 'student') {
          const t = col('teachers').get(i.student!.teacherId);
          if (!t || t.status !== 'active') throw new ApiError('teacher_not_active', 400);
          col('students').set(uid, { studentCode: code, displayName: i.displayName, ...i.student, teacherName: t.displayName, language: i.language, status: 'active', createdAt: now, updatedAt: now });
          col('studentPrivate').set(uid, { ...i.private, loginContact: i.email });
        } else col('teachers').set(uid, { teacherCode: code, displayName: i.displayName, language: i.language, status: 'active', responsibilities: i.teacher?.responsibilities ?? [], createdAt: now });
        ['users', 'students', 'teachers', 'studentPrivate'].forEach(notify);
        return { uid, loginId: code, authEmailIsReal: Boolean(i.email), temporaryPassword: pw };
      },
      async setStatus(uid, status) {
        await tick();
        const u = col('users').get(uid); if (!u) throw new ApiError('not_found', 404);
        col('users').set(uid, { ...u, status });
        const c = u.role === 'teacher' ? 'teachers' : 'students';
        col(c).set(uid, { ...col(c).get(uid)!, status }); ['users', c].forEach(notify);
      },
      async updateProfile(uid, p) {
        const u = col('users').get(uid); if (!u) throw new ApiError('not_found', 404);
        col('users').set(uid, { ...u, ...(p.displayName ? { displayName: p.displayName } : {}), ...(p.language ? { language: p.language } : {}) }); notify('users');
      },
      async resetPassword(uid) { await tick(); const pw = tempPw(); passwords.set(uid, pw); return { temporaryPassword: pw }; },
      async reassign(studentId, teacherId) {
        await tick();
        let moved = 0;
        for (const c of ['goals', 'progress', 'progressNotes', 'attendance', 'assignments']) {
          for (const [id, r] of col(c)) if (r.studentId === studentId) { col(c).set(id, { ...r, teacherId }); moved++; }
          notify(c);
        }
        const s = col('students').get(studentId)!; const t = col('teachers').get(teacherId)!;
        col('students').set(studentId, { ...s, teacherId, teacherName: t.displayName }); notify('students');
        return { moved };
      },
    },
  };
}
