import { startOfWeek } from './dates';
import type { Attendance, Goal, Progress } from './types';

export interface Rate { value: number | null; n: number; d: number }
export const MIN_SAMPLE = 5;

/** A percentage is only reported when there is enough data behind it; otherwise null ("not enough data"). */
export function rate(numerator: number, denominator: number, minSample = MIN_SAMPLE): Rate {
  return { value: denominator >= minSample ? Math.round((numerator / denominator) * 100) : null, n: numerator, d: denominator };
}

/** Attendance rate = (present + late) ÷ (present + late + absent). Excused sessions are excluded. */
export function attendanceRate(rows: Pick<Attendance, 'status'>[]): Rate {
  const present = rows.filter((r) => r.status === 'present' || r.status === 'late').length;
  const absent = rows.filter((r) => r.status === 'absent').length;
  return rate(present, present + absent);
}

/** Goal completion = achieved goals ÷ all goals set. Needs at least MIN_GOALS goals to be shown as a percentage. */
export function goalCompletion(goals: Pick<Goal, 'status'>[]): Rate {
  return rate(goals.filter((g) => g.status === 'achieved').length, goals.length, 3);
}

export function latestByDate<T extends { date: string }>(rows: T[]): T | undefined {
  return [...rows].sort((a, b) => b.date.localeCompare(a.date))[0];
}

/** Students without a progress entry in the last `days` days. */
export function needingUpdate(studentIds: string[], progress: Pick<Progress, 'studentId' | 'date'>[], today: string, days = 7): string[] {
  const cutoff = new Date(`${today}T12:00:00Z`); cutoff.setUTCDate(cutoff.getUTCDate() - days);
  const cut = cutoff.toISOString().slice(0, 10);
  return studentIds.filter((id) => !progress.some((p) => p.studentId === id && p.date >= cut));
}

export function toCsv(rows: Record<string, string | number | boolean | undefined>[]): string {
  if (!rows.length) return '';
  const cols = Object.keys(rows[0]);
  // Prefix risky leading characters to neutralise spreadsheet formula injection.
  const esc = (v: unknown) => {
    let s = String(v ?? '');
    if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return '\uFEFF' + [cols.join(','), ...rows.map((r) => cols.map((c) => esc(r[c])).join(','))].join('\n');
}

export interface WeekPoint { week: string; rate: Rate; sessions: number }
/** Weekly attendance trend. A week without enough sessions has rate.value === null and is drawn as "no data". */
export function weeklyAttendance(rows: Pick<Attendance, 'status' | 'date'>[], minSample = 3): WeekPoint[] {
  const by = new Map<string, Pick<Attendance, 'status'>[]>();
  for (const r of rows) { const w = startOfWeek(r.date); by.set(w, [...(by.get(w) ?? []), r]); }
  return [...by.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([week, rs]) => {
    const present = rs.filter((r) => r.status === 'present' || r.status === 'late').length;
    const absent = rs.filter((r) => r.status === 'absent').length;
    return { week, sessions: present + absent, rate: rate(present, present + absent, minSample) };
  });
}
