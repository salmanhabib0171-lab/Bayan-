import { initializeApp } from 'firebase/app';
import {
  EmailAuthProvider, getAuth, onAuthStateChanged, reauthenticateWithCredential, sendPasswordResetEmail,
  signInWithEmailAndPassword, signOut, updatePassword,
} from 'firebase/auth';
import {
  addDoc, collection, type DocumentData, deleteDoc, doc, getDoc, getDocs, initializeFirestore, limit as fsLimit, memoryLocalCache,
  onSnapshot, orderBy as fsOrderBy, query, serverTimestamp, setDoc, Timestamp, updateDoc, where as fsWhere, writeBatch,
} from 'firebase/firestore';
import { ApiError, AuthError, toAuthEmail, type AdminApi, type AuthService, type Constraint, type DataStore, type Services } from './services';

const cfg = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY, authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID, storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID, appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

function fromFs(v: unknown): unknown {
  if (v instanceof Timestamp) return v.toDate().toISOString();
  if (Array.isArray(v)) return v.map(fromFs);
  if (v && typeof v === 'object') return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, fromFs(x)]));
  return v;
}
function toFs(v: unknown): unknown {
  if (v && typeof v === 'object' && (v as { __serverTime?: boolean }).__serverTime) return serverTimestamp();
  if (Array.isArray(v)) return v.map(toFs);
  if (v && typeof v === 'object') return Object.fromEntries(Object.entries(v).filter(([, x]) => x !== undefined).map(([k, x]) => [k, toFs(x)]));
  return v;
}

export function createFirebaseServices(): Services {
  if (!cfg.apiKey || !cfg.projectId) throw new Error('firebase_not_configured');
  const app = initializeApp(cfg);
  const fsAuth = getAuth(app);
  // In-memory cache only: private records are never written to the browser's disk.
  const fs = initializeFirestore(app, { localCache: memoryLocalCache() });

  const q = (path: string, c: Constraint[] = []) =>
    query(collection(fs, path), ...c.map((x) => (x.t === 'where' ? fsWhere(x.field, x.op, x.value) : x.t === 'orderBy' ? fsOrderBy(x.field, x.dir) : fsLimit(x.n))));

  const db: DataStore = {
    async list<T>(path: string, c?: Constraint[]) {
      const s = await getDocs(q(path, c));
      return s.docs.map((d) => ({ ...(fromFs(d.data()) as DocumentData), id: d.id }) as never as T & { id: string });
    },
    async get<T>(path: string, id: string) {
      const s = await getDoc(doc(fs, path, id));
      return s.exists() ? ({ ...(fromFs(s.data()) as DocumentData), id: s.id } as never as T & { id: string }) : null;
    },
    set: (path, id, data, merge) => setDoc(doc(fs, path, id), toFs(data) as DocumentData, { merge: Boolean(merge) }),
    async add(path, data) { return (await addDoc(collection(fs, path), toFs(data) as DocumentData)).id; },
    update: (path, id, data) => updateDoc(doc(fs, path, id), toFs(data) as DocumentData),
    remove: (path, id) => deleteDoc(doc(fs, path, id)),
    async batch(ops) {
      const b = writeBatch(fs);
      for (const o of ops) {
        const ref = doc(fs, o.path, o.id);
        if (o.op === 'set') b.set(ref, toFs(o.data) as DocumentData, { merge: Boolean(o.merge) });
        else if (o.op === 'update') b.update(ref, toFs(o.data) as DocumentData);
        else b.delete(ref);
      }
      await b.commit();
    },
    watch<T>(path: string, c: Constraint[], cb: (rows: (T & { id: string })[]) => void, onError: (e: Error) => void) {
      return onSnapshot(q(path, c), (s) => cb(s.docs.map((d) => ({ ...(fromFs(d.data()) as DocumentData), id: d.id }) as never as T & { id: string })), onError);
    },
  };

  const auth: AuthService = {
    onChange: (cb) => onAuthStateChanged(fsAuth, (u) => cb(u ? u.uid : null)),
    async signIn(identifier, password) {
      try { await signInWithEmailAndPassword(fsAuth, toAuthEmail(identifier), password); }
      catch (e) {
        const code = (e as { code?: string }).code ?? '';
        if (code === 'auth/user-disabled') throw new AuthError('disabled');
        if (code === 'auth/too-many-requests') throw new AuthError('too_many');
        if (code === 'auth/network-request-failed') throw new AuthError('network');
        if (code.startsWith('auth/invalid') || code === 'auth/user-not-found' || code === 'auth/wrong-password') throw new AuthError('invalid_credentials');
        throw new AuthError('unknown');
      }
    },
    async signOut() { await signOut(fsAuth); },
    async changePassword(current, next) {
      const u = fsAuth.currentUser;
      if (!u?.email) throw new AuthError('unknown');
      try {
        await reauthenticateWithCredential(u, EmailAuthProvider.credential(u.email, current));
        await updatePassword(u, next);
      } catch (e) {
        const code = (e as { code?: string }).code ?? '';
        if (code === 'auth/weak-password') throw new AuthError('weak_password');
        if (code.startsWith('auth/invalid') || code === 'auth/wrong-password') throw new AuthError('wrong_password');
        throw new AuthError('unknown');
      }
    },
    async sendReset(email) {
      // Always resolves the same way, so the form cannot be used to discover which emails have accounts.
      try { await sendPasswordResetEmail(fsAuth, email.trim()); } catch { /* intentionally silent */ }
    },
  };

  async function call<T>(name: string, body: unknown): Promise<T> {
    const token = await fsAuth.currentUser?.getIdToken();
    if (!token) throw new ApiError('missing_token', 401);
    let res: Response;
    try {
      res = await fetch(`/.netlify/functions/${name}`, { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` }, body: JSON.stringify(body) });
    } catch { throw new ApiError('network'); }
    const data = (await res.json().catch(() => ({}))) as { error?: string; fields?: string[] } & T;
    if (!res.ok) throw new ApiError(data.error ?? 'internal_error', res.status, data.fields);
    return data;
  }
  const admin: AdminApi = {
    createUser: (i) => call('create-user', i),
    setStatus: async (uid, status) => { await call('update-user-status', { uid, status }); },
    resetPassword: (uid) => call('reset-password', { uid }),
    reassign: (studentId, teacherId) => call('reassign-teacher', { studentId, teacherId }),
    updateProfile: async (uid, p) => { await call('update-user-profile', { uid, ...p }); },
  };
  return { mode: 'firebase', auth, db, admin };
}
