// SAMPLE DATA for the explicit demo mode only (VITE_DEMO_MODE=true). Fictional people; no religious text is invented.
import { addDays, todayStr } from './dates';

type Rec = Record<string, unknown>;
export interface Seed { [collection: string]: Record<string, Rec> }

const LETTERS = ['ا','ب','ت','ث','ج','ح','خ','د','ذ','ر','ز','س','ش','ص','ض','ط','ظ','ع','غ','ف','ق','ك','ل','م','ن','ه','و','ي'];

export function buildSeed(now = new Date()): Seed {
  const today = todayStr('UTC', now);
  const iso = (offsetMin: number) => new Date(now.getTime() + offsetMin * 60_000).toISOString();
  const day = (n: number) => addDays(today, n);
  const seed: Seed = {
    users: {}, students: {}, studentPrivate: {}, teachers: {}, goals: {}, progress: {}, progressNotes: {}, attendance: {},
    classes: {}, assignments: {}, conversations: {}, announcements: {}, lessons: {}, duas: {}, audit: {}, config: {},
  };
  const user = (id: string, role: string, name: string, code: string, language = 'en') =>
    (seed.users[id] = { role, status: 'active', displayName: name, code, language, mustChangePassword: false });

  user('p1', 'principal', 'Principal (Demo)', 'PRINCIPAL');
  const teachers = [['t1', 'Ustadha Maryam Hossain', 'T-001', 'en'], ['t2', 'Ustadh Ibrahim Khan', 'T-002', 'bn']];
  teachers.forEach(([id, name, code, lang]) => {
    user(id, 'teacher', name, code, lang);
    seed.teachers[id] = { teacherCode: code, displayName: name, language: lang, status: 'active', responsibilities: ['attendance', 'progress', 'messaging', 'scheduling'], createdAt: iso(-90000) };
  });

  const students: [string, string, string, string, string, string, string, string, string][] = [
    ['s1', 'Aisha R.', 'S-1001', 'qaida', 'Lesson 3 · Letters', 't1', 'Bangladesh', 'Asia/Dhaka', 'bn'],
    ['s2', 'Yusuf A.', 'S-1002', 'qaida', 'Lesson 7 · Harakat', 't1', 'United Kingdom', 'Europe/London', 'en'],
    ['s3', 'Zainab K.', 'S-1003', 'ampara', 'Surah group 2', 't1', 'Canada', 'America/Toronto', 'en'],
    ['s4', 'Omar H.', 'S-1004', 'quran', 'Revision', 't2', 'Bangladesh', 'Asia/Dhaka', 'bn'],
    ['s5', 'Maryam S.', 'S-1005', 'ampara', 'Surah group 1', 't2', 'Saudi Arabia', 'Asia/Riyadh', 'en'],
    ['s6', 'Ibrahim T.', 'S-1006', 'qaida', 'Lesson 1 · Letters', 't2', 'United States', 'America/New_York', 'en'],
    ['s7', 'Hafsa N.', 'S-1007', 'quran', 'Tajweed basics', 't2', 'Bangladesh', 'Asia/Dhaka', 'bn'],
  ];
  const tname = (id: string) => String(teachers.find((t) => t[0] === id)![1]);
  students.forEach(([id, name, code, track, level, teacherId, country, tz, lang], i) => {
    user(id, 'student', name, code, lang);
    seed.students[id] = { studentCode: code, displayName: name, track, level, teacherId, teacherName: tname(teacherId), enrollmentDate: day(-120 + i * 9), language: lang, country, timeZone: tz, status: 'active', createdAt: iso(-80000) };
    // Fictional private data — exists ONLY in the Principal-only collection.
    seed.studentPrivate[id] = { legalName: `Demo Legal Name ${i + 1}`, guardianName: `Demo Guardian ${i + 1}`, guardianPhone: '+000 000 000 000', guardianEmail: `guardian${i + 1}@example.invalid`, address: 'Demo address — fictional', notes: '' };
  });

  const goalTitles = ['Recognise all letters', 'Read letters with fatha, kasra, damma', 'Join letters into short words', 'Steady reading pace'];
  const statuses = ['achieved', 'practicing', 'in_progress', 'not_started'];
  students.forEach(([id, , , track, , teacherId], i) => {
    for (let g = 0; g < 3; g++) seed.goals[`g-${id}-${g}`] = { studentId: id, teacherId, title: goalTitles[(i + g) % 4], description: '', status: statuses[(i + g) % 4], targetDate: day(14 + g * 10), createdBy: 'p1', createdAt: iso(-50000) };
    for (let d = 0; d < 8; d++) {
      if ((i + d) % 3 === 0 && d > 1) continue; // gaps make "needs update" meaningful
      if (i === 5 && d < 9) continue; // one student with no recent entry
      const pid = `pr-${id}-${d}`;
      seed.progress[pid] = {
        studentId: id, teacherId, track, date: day(-d), lesson: track === 'qaida' ? `Qaida · Lesson ${3 + i - d}` : track === 'ampara' ? 'Short passage practice' : 'Revision & tajweed',
        objectives: 'Accurate recognition and pronunciation', status: statuses[(i + d) % 4 === 3 ? 1 : (i + d) % 4], practice: 'Read aloud 10 minutes daily', homework: 'Repeat today’s section', feedback: d % 2 ? 'Good effort. Keep a steady pace.' : 'Clear improvement in pronunciation today.', followUp: '', createdBy: teacherId, createdByName: tname(teacherId), createdAt: iso(-d * 1440),
      };
      seed.attendance[`${id}_${day(-d)}`] = { studentId: id, teacherId, classId: '', date: day(-d), status: d === 3 && i % 2 ? 'absent' : d === 5 && i % 3 === 0 ? 'late' : 'present', note: '', recordedBy: teacherId };
    }
  });

  const cls = (id: string, title: string, teacherId: string, sid: string, offsetMin: number, dur = 30, status = 'scheduled') => {
    const s = students.find((x) => x[0] === sid)!;
    seed.classes[id] = { title, teacherId, teacherName: tname(teacherId), studentIds: [sid], studentNames: [s[1]], startsAt: iso(offsetMin), timeZone: s[7], durationMin: dur, zoomUrl: 'https://zoom.us/j/0000000000', notes: 'Demo class — placeholder Zoom link.', status, createdBy: teacherId };
  };
  cls('c1', 'Qaida · one-to-one', 't1', 's1', 8, 30); cls('c2', 'Qaida · one-to-one', 't1', 's2', 95); cls('c3', 'Ampara · one-to-one', 't1', 's3', 190);
  cls('c4', 'Quran · one-to-one', 't2', 's4', 60, 45); cls('c5', 'Ampara · one-to-one', 't2', 's5', 24 * 60 + 30);
  cls('c6', 'Qaida · one-to-one', 't2', 's6', 24 * 60 * 2); cls('c7', 'Qaida · one-to-one', 't1', 's1', -24 * 60, 30, 'completed');

  seed.assignments['a1'] = { studentId: 's1', teacherId: 't1', lessonId: 'l-letters-1', lessonTitle: 'Arabic letters (1–14)', note: 'Practise saying each letter aloud.', completed: false, createdBy: 't1', createdAt: iso(-1440) };
  seed.lessons['l-letters-1'] = { title: 'Arabic letters (1–14)', titleBn: 'আরবি হরফ (১–১৪)', section: 'letters', arabicItems: LETTERS.slice(0, 14), instructions: 'Say each letter aloud with your teacher, then on your own.', instructionsBn: 'শিক্ষকের সাথে প্রতিটি হরফ উচ্চারণ করুন, তারপর নিজে অনুশীলন করুন।', order: 1, status: 'published', sourceVerified: true, reviewedBy: 'p1', reviewerName: 'Principal (Demo)', createdBy: 'p1' };
  seed.lessons['l-letters-2'] = { title: 'Arabic letters (15–28)', titleBn: 'আরবি হরফ (১৫–২৮)', section: 'letters', arabicItems: LETTERS.slice(14), instructions: 'Continue with the remaining letters.', instructionsBn: 'বাকি হরফগুলো অনুশীলন করুন।', order: 2, status: 'draft', sourceVerified: false, reviewedBy: '', reviewerName: '', createdBy: 'p1' };
  seed.duas['d-placeholder'] = { title: 'PLACEHOLDER — replace with a verified dua', category: 'daily', arabic: '', transliteration: '', meaningEn: '', meaningBn: '', source: '', status: 'draft', sourceVerified: false, reviewedBy: '', reviewerName: '', createdBy: 'p1' };

  seed.announcements['an1'] = { title: 'Welcome to the new term', body: 'Please join your class a few minutes early and keep your lesson book ready.', audience: 'all', createdBy: 'p1', createdAt: iso(-2880) };
  seed.announcements['an2'] = { title: 'Teachers: weekly progress entries', body: 'Please record progress after each class so families receive timely feedback.', audience: 'teachers', createdBy: 'p1', createdAt: iso(-1440) };
  seed.conversations['t1_s1'] = { teacherId: 't1', studentId: 's1', teacherName: tname('t1'), studentName: 'Aisha R.', participants: ['t1', 's1'], lastMessageAt: iso(-120), lastSenderId: 't1', lastPreview: 'Well done today! Please revise page 3.', readAt: { t1: iso(-120) } };
  seed.conversations['t1_s1/messages'] = {
    m1: { senderId: 's1', text: 'Assalamu alaikum, may I have the homework again?', createdAt: iso(-200) },
    m2: { senderId: 't1', text: 'Well done today! Please revise page 3.', createdAt: iso(-120) },
  };
  seed.config['settings'] = { defaultLanguage: 'en', academyName: 'Jamia Al-Bayan Global' };
  return seed;
}
