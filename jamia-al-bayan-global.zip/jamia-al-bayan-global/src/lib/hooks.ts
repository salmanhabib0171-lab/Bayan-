import { useCallback, useEffect, useRef, useState } from 'react';
import { useAuth } from './auth';
import type { Constraint, Row } from './services';

export interface Query<T> { data: Row<T>[]; loading: boolean; error: Error | null; reload: () => void }

/** Loads a collection. `deps` must change whenever the constraints' values change. `live` uses a realtime listener. */
export function useCollection<T>(path: string | null, constraints: Constraint[], deps: unknown[], live = false): Query<T> {
  const { db } = useAuth();
  const [data, setData] = useState<Row<T>[]>([]);
  const [loading, setLoading] = useState(Boolean(path));
  const [error, setError] = useState<Error | null>(null);
  const [tick, setTick] = useState(0);
  const cons = useRef<Constraint[]>(constraints); cons.current = constraints;
  const reload = useCallback(() => setTick((n) => n + 1), []);

  useEffect(() => {
    if (!path) { setData([]); setLoading(false); return; }
    let alive = true;
    setLoading(true); setError(null);
    if (live) {
      const off = db.watch<T>(path, cons.current, (rows) => { if (alive) { setData(rows); setLoading(false); } }, (e) => { if (alive) { setError(e); setLoading(false); } });
      return () => { alive = false; off(); };
    }
    db.list<T>(path, cons.current).then((rows) => { if (alive) { setData(rows); setLoading(false); } })
      .catch((e: Error) => { if (alive) { setError(e); setLoading(false); } });
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [db, path, live, tick, ...deps]);
  return { data, loading, error, reload };
}

export function useDebounced<T>(value: T, ms = 250): T {
  const [v, setV] = useState(value);
  useEffect(() => { const id = setTimeout(() => setV(value), ms); return () => clearTimeout(id); }, [value, ms]);
  return v;
}

export function useNow(intervalMs = 30_000): number {
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const id = setInterval(() => setNow(Date.now()), intervalMs); return () => clearInterval(id); }, [intervalMs]);
  return now;
}

export function useOnline(): boolean {
  const [on, setOn] = useState(navigator.onLine);
  useEffect(() => {
    const a = () => setOn(true), b = () => setOn(false);
    window.addEventListener('online', a); window.addEventListener('offline', b);
    return () => { window.removeEventListener('online', a); window.removeEventListener('offline', b); };
  }, []);
  return on;
}

/** Loads a single document by id (used where a collection query would not be permitted by the security rules). */
export function useDoc<T>(path: string, id: string | null): { data: (T & { id: string }) | null; loading: boolean; error: Error | null } {
  const { db } = useAuth();
  const [state, setState] = useState<{ data: (T & { id: string }) | null; loading: boolean; error: Error | null }>({ data: null, loading: Boolean(id), error: null });
  useEffect(() => {
    if (!id) { setState({ data: null, loading: false, error: null }); return; }
    let alive = true;
    db.get<T>(path, id).then((d) => alive && setState({ data: d, loading: false, error: null })).catch((e: Error) => alive && setState({ data: null, loading: false, error: e }));
    return () => { alive = false; };
  }, [db, path, id]);
  return state;
}
