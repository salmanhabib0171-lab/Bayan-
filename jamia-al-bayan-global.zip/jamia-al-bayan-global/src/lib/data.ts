import { useAuth } from './auth';
import { useCollection } from './hooks';
import { SERVER_TIME, where, type Constraint, type DataStore } from './services';
import type { StudentDoc, TeacherDoc, UserDoc } from './types';

export { ZOOM_RE, isZoomUrl } from './zoom';

export const newId = () => (globalThis.crypto?.randomUUID?.() ?? `${Date.now()}${Math.random().toString(36).slice(2)}`).replace(/-/g, '');

/** Append-only audit record. `meta` must never contain personal details. */
export async function logAudit(db: DataStore, actorId: string, action: string, targetId: string, meta: Record<string, string | number | boolean> = {}) {
  try { await db.add('audit', { actorId, action, targetId, meta, createdAt: SERVER_TIME }); } catch { /* audit failure must not block the user's action */ }
}

/** Students visible to the signed-in staff member: all (Principal) or only those assigned to the teacher. */
export function useStudents() {
  const { user } = useAuth();
  // Students have no directory access: for them this never queries (their own profile is fetched by id elsewhere).
  const q = useCollection<StudentDoc>(user.role === 'student' ? null : 'students', user.role === 'teacher' ? [where('teacherId', '==', user.id)] : [], [user.id, user.role]);
  const data = [...q.data].sort((a, b) => a.displayName.localeCompare(b.displayName));
  return { ...q, data };
}
export function useTeachers() {
  const q = useCollection<TeacherDoc>('teachers', [], []);
  return { ...q, data: [...q.data].sort((a, b) => a.displayName.localeCompare(b.displayName)) };
}

/**
 * Constraints that prove to Firestore Security Rules that a query only touches the caller's own records
 * (teacher → their students' records, student → their own). The rules evaluate the query, not just each document.
 */
export function ownerScope(user: Pick<UserDoc, 'id' | 'role'>, studentId?: string): Constraint[] {
  if (user.role === 'teacher') return [where('teacherId', '==', user.id), ...(studentId ? [where('studentId', '==', studentId)] : [])];
  if (user.role === 'student') return [where('studentId', '==', user.id)];
  return studentId ? [where('studentId', '==', studentId)] : [];
}

export const COMMON_TIMEZONES = ['Asia/Dhaka', 'Asia/Riyadh', 'Asia/Dubai', 'Asia/Kolkata', 'Asia/Karachi', 'Asia/Kuala_Lumpur', 'Europe/London', 'Europe/Paris',
  'Europe/Istanbul', 'Africa/Cairo', 'America/New_York', 'America/Chicago', 'America/Toronto', 'America/Los_Angeles', 'Australia/Sydney', 'UTC'];
export function tzOptions(...extra: (string | undefined)[]): string[] {
  return [...new Set([...extra.filter(Boolean) as string[], ...COMMON_TIMEZONES])];
}
