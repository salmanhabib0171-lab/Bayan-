/** Must match the zoomUrlOk() rule in firestore.rules — only https Zoom hosts are ever rendered as links. */
export const ZOOM_RE = /^https:\/\/([a-zA-Z0-9-]+\.)*(zoom\.us|zoom\.com|zoomgov\.com)\/\S+$/;
export const isZoomUrl = (u: string): boolean => u.length <= 300 && ZOOM_RE.test(u);
