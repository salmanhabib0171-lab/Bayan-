import type { Lang } from './types';

export const localeOf = (lang: Lang) => (lang === 'bn' ? 'bn-BD' : 'en-GB');
export const browserTimeZone = () => Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';

export function todayStr(tz = browserTimeZone(), now = new Date()): string {
  const p = new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(now);
  return p; // YYYY-MM-DD
}

/** Offset (ms) of `tz` from UTC at instant `utcMs`. */
function tzOffsetMs(tz: string, utcMs: number): number {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit',
  }).formatToParts(new Date(utcMs));
  const g = (t: string) => Number(parts.find((x) => x.type === t)!.value);
  const asUtc = Date.UTC(g('year'), g('month') - 1, g('day'), g('hour'), g('minute'), g('second'));
  return asUtc - Math.floor(utcMs / 1000) * 1000;
}

/** Convert a wall-clock date+time in `tz` to a UTC ISO string (DST-safe). */
export function zonedToUtcIso(date: string, time: string, tz: string): string {
  const [y, m, d] = date.split('-').map(Number);
  const [hh, mm] = time.split(':').map(Number);
  const guess = Date.UTC(y, m - 1, d, hh, mm);
  let utc = guess - tzOffsetMs(tz, guess);
  utc = guess - tzOffsetMs(tz, utc); // second pass handles DST boundaries
  return new Date(utc).toISOString();
}

export function fmtDateTime(iso: string | undefined, lang: Lang, tz?: string): string {
  if (!iso) return '—';
  return new Intl.DateTimeFormat(localeOf(lang), { dateStyle: 'medium', timeStyle: 'short', timeZone: tz }).format(new Date(iso));
}
export function fmtTime(iso: string, lang: Lang, tz?: string): string {
  return new Intl.DateTimeFormat(localeOf(lang), { timeStyle: 'short', timeZone: tz }).format(new Date(iso));
}
export function fmtDate(d: string | undefined, lang: Lang): string {
  if (!d) return '—';
  const dt = d.length === 10 ? new Date(`${d}T12:00:00Z`) : new Date(d);
  return new Intl.DateTimeFormat(localeOf(lang), { dateStyle: 'medium', timeZone: d.length === 10 ? 'UTC' : undefined }).format(dt);
}
export function tzLabel(tz: string, lang: Lang, iso?: string): string {
  const parts = new Intl.DateTimeFormat(localeOf(lang), { timeZone: tz, timeZoneName: 'short' }).formatToParts(iso ? new Date(iso) : new Date());
  return parts.find((p) => p.type === 'timeZoneName')?.value ?? tz;
}
export const fmtNum = (n: number, lang: Lang) => new Intl.NumberFormat(localeOf(lang)).format(n);

export function addDays(date: string, n: number): string {
  const d = new Date(`${date}T12:00:00Z`); d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}
export function startOfWeek(date: string): string { // Monday-based
  const d = new Date(`${date}T12:00:00Z`); const dow = (d.getUTCDay() + 6) % 7;
  return addDays(date, -dow);
}

/** Class can be joined from 15 minutes before start until 15 minutes after the scheduled end. */
export function joinWindow(startsAt: string, durationMin: number, now = Date.now()) {
  const start = new Date(startsAt).getTime();
  return { open: now >= start - 15 * 60_000 && now <= start + (durationMin + 15) * 60_000, started: now >= start, ended: now > start + durationMin * 60_000 };
}
