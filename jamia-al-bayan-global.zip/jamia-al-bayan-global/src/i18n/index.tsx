import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { Lang } from '../lib/types';
import { en, type Key } from './en';
import { bn } from './bn';

export type { Key };
const dict: Record<Lang, Record<Key, string>> = { en, bn };
const LS = 'albayan.lang'; // device language preference only — no personal data

interface I18n {
  lang: Lang; dir: 'ltr'; setLang: (l: Lang) => void;
  t: (k: Key, vars?: Record<string, string | number>) => string;
}
const Ctx = createContext<I18n | null>(null);

export function I18nProvider({ children, initial }: { children: ReactNode; initial?: Lang }) {
  const [lang, setLangState] = useState<Lang>(() => {
    const saved = (() => { try { return localStorage.getItem(LS); } catch { return null; } })();
    return saved === 'bn' || saved === 'en' ? saved : initial ?? (navigator.language?.startsWith('bn') ? 'bn' : 'en');
  });
  useEffect(() => {
    document.documentElement.lang = lang; // layout stays LTR for both English and Bangla; Arabic content sets its own dir
    document.title = dict[lang]['app.name'];
  }, [lang]);
  const setLang = useCallback((l: Lang) => { setLangState(l); try { localStorage.setItem(LS, l); } catch { /* storage unavailable */ } }, []);
  const t = useCallback((k: Key, vars?: Record<string, string | number>) => {
    let s = dict[lang][k] ?? dict.en[k] ?? k;
    if (vars) for (const [n, v] of Object.entries(vars)) s = s.replaceAll(`{${n}}`, typeof v === 'number' && lang === 'bn' ? new Intl.NumberFormat('bn-BD').format(v) : String(v));
    return s;
  }, [lang]);
  const value = useMemo(() => ({ lang, dir: 'ltr' as const, setLang, t }), [lang, setLang, t]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
export function useI18n(): I18n {
  const v = useContext(Ctx); if (!v) throw new Error('I18nProvider missing'); return v;
}
