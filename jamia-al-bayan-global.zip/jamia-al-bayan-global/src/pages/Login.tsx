import { useState, type FormEvent } from 'react';
import { LuLock } from 'react-icons/lu';
import { LogoFull } from '../components/Brand';
import { LanguageSwitch } from '../components/LanguageSwitch';
import { Button, Field, Input, Modal } from '../components/ui';
import { useSession } from '../lib/auth';
import { AuthError } from '../lib/services';
import { useI18n } from '../i18n';

export function Login() {
  const { t } = useI18n();
  const { services, notice } = useSession();
  const [id, setId] = useState(''); const [pw, setPw] = useState('');
  const [busy, setBusy] = useState(false); const [err, setErr] = useState<string | null>(null);
  const [forgot, setForgot] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault(); if (!services) return;
    setErr(null);
    if (!id.trim() || !pw) { setErr(t('auth.required')); return; }
    setBusy(true);
    try { await services.auth.signIn(id, pw); }
    catch (x) {
      const c = x instanceof AuthError ? x.code : 'unknown';
      setErr(c === 'invalid_credentials' ? t('auth.invalid') : c === 'disabled' ? t('auth.disabled') : c === 'too_many' ? t('auth.tooMany') : c === 'network' ? t('error.network') : t('error.generic'));
    } finally { setBusy(false); }
  }

  return (
    <div className="login">
      <div className="login-card">
        <LanguageSwitch />
        <LogoFull className="logo" />
        <form className="login-panel" onSubmit={submit} noValidate>
          <h1 style={{ fontSize: '1.25rem' }}>{t('auth.signIn')}</h1>
          {(notice === 'disabled') && <p className="field-msg err" role="alert">{t('auth.disabled')}</p>}
          {(notice === 'no_profile') && <p className="field-msg err" role="alert">{t('auth.noProfile')}</p>}
          <Field label={t('auth.identifier')} hint={t('auth.identifierHint')} required>
            {(fid, d) => <Input id={fid} aria-describedby={d} autoComplete="username" autoCapitalize="none" value={id} onChange={(e) => setId(e.target.value)} />}
          </Field>
          <Field label={t('auth.password')} required error={err ?? undefined}>
            {(fid, d) => <Input id={fid} aria-describedby={d} type="password" autoComplete="current-password" value={pw} onChange={(e) => setPw(e.target.value)} />}
          </Field>
          <Button type="submit" variant="primary" size="lg" loading={busy} disabled={!services} icon={<LuLock aria-hidden />}>{t('auth.signIn')}</Button>
          <button type="button" className="row-link small" onClick={() => setForgot(true)}>{t('auth.forgot')}</button>
          <p className="muted small">{t('auth.noSignup')}</p>
          {services?.mode === 'demo' && <p className="demo-box">{t('demo.login')} <code>PRINCIPAL</code> · <code>T-001</code> · <code>S-1001</code> — {t('demo.password')} <code>demo</code></p>}
        </form>
      </div>
      <ForgotDialog open={forgot} onClose={() => setForgot(false)} />
    </div>
  );
}

function ForgotDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { t } = useI18n(); const { services } = useSession();
  const [email, setEmail] = useState(''); const [sent, setSent] = useState(false); const [busy, setBusy] = useState(false);
  return (
    <Modal open={open} title={t('auth.recoverTitle')} onClose={() => { onClose(); setSent(false); }} footer={
      !sent && <><Button variant="ghost" onClick={onClose}>{t('common.cancel')}</Button><Button variant="primary" loading={busy} disabled={!email.includes('@')} onClick={async () => { setBusy(true); await services?.auth.sendReset(email); setBusy(false); setSent(true); }}>{t('auth.sendLink')}</Button></>}>
      {sent ? <p>{t('auth.linkSent')}</p> : <>
        <p className="muted">{t('auth.recoverIntro')}</p>
        <Field label={t('field.email')}>{(fid) => <Input id={fid} type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />}</Field>
        <p className="muted small">{t('auth.recoverStudents')}</p>
      </>}
    </Modal>
  );
}
