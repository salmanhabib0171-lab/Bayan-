import { lazy, Suspense, useMemo, useState } from 'react';
import { LuCalendarDays, LuMessageCircle, LuPlus, LuUsers } from 'react-icons/lu';
import { ProgressForm } from '../../components/ProgressForm';
import { StudentDetail } from '../../components/StudentDetail';
import { AttendanceBadge, Avatar, Badge, Button, Card, CardHeader, DataTable, EmptyState, Loadable, PageHeader, ProgressBadge, Spinner, Stat, StatusBadge, type Column } from '../../components/ui';
import { ZoomJoin } from '../../components/ZoomJoin';
import { useAuth } from '../../lib/auth';
import { ownerScope, useStudents } from '../../lib/data';
import { addDays, browserTimeZone, fmtDate, fmtTime, todayStr, tzLabel } from '../../lib/dates';
import { useCollection } from '../../lib/hooks';
import { Link } from '../../lib/router';
import { where } from '../../lib/services';
import { needingUpdate } from '../../lib/stats';
import type { Attendance, ClassSession, Conversation, Goal, Progress, StudentDoc } from '../../lib/types';
import { useI18n, type Key } from '../../i18n';
import { AnnouncementFeed } from '../shared/Announcements';
import { isUnread } from '../shared/Messages';

const Classes = lazy(() => import('../shared/Classes'));
const Messages = lazy(() => import('../shared/Messages'));
const Resources = lazy(() => import('../shared/Resources'));

export default function TeacherApp({ path }: { path: string }) {
  const fb = <Spinner />;
  return <Suspense fallback={fb}>{path === '/teacher/students' ? <MyStudents /> : path === '/teacher/progress' ? <ProgressPage /> : path === '/teacher/classes' ? <Classes /> :
    path === '/teacher/messages' ? <Messages /> : path === '/teacher/resources' ? <Resources /> : <Dashboard />}</Suspense>;
}

function Dashboard() {
  const { t, lang } = useI18n(); const { user, db } = useAuth(); const tz = browserTimeZone(); const today = todayStr(tz);
  const students = useStudents(); const [entryFor, setEntryFor] = useState<string | null>(null);
  const since = addDays(today, -14);
  const progress = useCollection<Progress>('progress', [...ownerScope(user), where('date', '>=', since)], [user.id, since]);
  const classes = useCollection<ClassSession>('classes', [where('teacherId', '==', user.id), where('startsAt', '>=', `${addDays(today, -1)}T00:00:00.000Z`)], [user.id, today]);
  const goals = useCollection<Goal>('goals', ownerScope(user), [user.id]);
  const convs = useCollection<Conversation>('conversations', [where('participants', 'array-contains', user.id)], [user.id], true);
  const att = useCollection<Attendance>('attendance', [...ownerScope(user), where('date', '==', today)], [user.id, today]);
  void db;
  const active = students.data.filter((s) => s.status === 'active');
  const todays = useMemo(() => classes.data.filter((c) => todayStr(tz, new Date(c.startsAt)) === today && c.status !== 'cancelled').sort((a, b) => a.startsAt.localeCompare(b.startsAt)), [classes.data, today, tz]);
  const upcoming = useMemo(() => classes.data.filter((c) => c.status === 'scheduled' && new Date(c.startsAt).getTime() > Date.now() - 30 * 60_000).sort((a, b) => a.startsAt.localeCompare(b.startsAt))[0], [classes.data]);
  const pending = needingUpdate(active.map((s) => s.id), progress.data, today, 3);
  const unread = convs.data.filter((c) => isUnread(c, user.id)).length;
  const feedback = [...progress.data].sort((a, b) => (b.createdAt ?? b.date).localeCompare(a.createdAt ?? a.date)).slice(0, 4);
  const nameOf = (id: string) => students.data.find((s) => s.id === id)?.displayName ?? '—';

  return (
    <>
      <PageHeader title={t('teacher.welcome', { name: user.displayName })} subtitle={t('teacher.subtitle')}
        actions={<Button variant="primary" icon={<LuPlus aria-hidden />} onClick={() => setEntryFor('')} disabled={active.length === 0}>{t('progress.newEntry')}</Button>} />
      <div className="grid cols-4">
        <Stat icon={<LuUsers aria-hidden />} label={t('teacher.assigned')} value={active.length} />
        <Stat icon={<LuCalendarDays aria-hidden />} label={t('dash.todayClasses')} value={todays.length} />
        <Stat label={t('teacher.needUpdate')} value={pending.length} hint={t('teacher.needUpdateHint')} />
        <Stat icon={<LuMessageCircle aria-hidden />} label={t('messages.unread')} value={unread} />
      </div>
      <Card><CardHeader title={t('teacher.nextClass')} />
        {upcoming ? <div className="row between"><div><strong>{upcoming.title}</strong><p className="muted">{upcoming.studentNames.join(', ')} · {fmtTime(upcoming.startsAt, lang, tz)} ({tzLabel(tz, lang, upcoming.startsAt)})</p></div><ZoomJoin cls={upcoming} /></div>
          : <EmptyState title={t('class.none.upcoming')} />}</Card>
      <div className="grid cols-2">
        <Card><CardHeader title={t('dash.todayClasses')} action={<Link to="/teacher/classes" className="small">{t('common.viewAll')}</Link>} />
          <Loadable loading={classes.loading} error={classes.error} onRetry={classes.reload} rows={2}>
            {todays.length === 0 ? <EmptyState title={t('class.none.today')} /> : (
              <ul className="list">{todays.map((c) => { const a = att.data.find((x) => x.classId === c.id); return (
                <li key={c.id}><div><strong>{fmtTime(c.startsAt, lang, tz)}</strong> · {c.studentNames.join(', ')}<p className="muted small">{c.title}</p></div>{a ? <AttendanceBadge status={a.status} /> : <Badge>{t('attendance.notMarked')}</Badge>}</li>); })}</ul>)}
          </Loadable>
        </Card>
        <Card><CardHeader title={t('teacher.needUpdate')} subtitle={t('teacher.needUpdateHint')} />
          <Loadable loading={progress.loading || students.loading} error={progress.error} onRetry={progress.reload} rows={2}>
            {pending.length === 0 ? <EmptyState title={t('teacher.allCaughtUp')} /> : (
              <ul className="list">{pending.slice(0, 6).map((id) => <li key={id}><span className="row"><Avatar name={nameOf(id)} />{nameOf(id)}</span><Button size="sm" onClick={() => setEntryFor(id)}>{t('progress.addEntry')}</Button></li>)}</ul>)}
          </Loadable>
        </Card>
        <Card><CardHeader title={t('teacher.recentFeedback')} />
          {feedback.length === 0 ? <EmptyState title={t('progress.none')} /> : <ul className="list">{feedback.map((p) => <li key={p.id}><div><strong>{nameOf(p.studentId)}</strong> · {p.lesson}<p className="muted small">{p.feedback || '—'} · {fmtDate(p.date, lang)}</p></div><ProgressBadge status={p.status} /></li>)}</ul>}</Card>
        <Card><CardHeader title={t('teacher.currentGoals')} />
          {goals.data.filter((g) => g.status !== 'achieved').length === 0 ? <EmptyState title={t('goal.none')} /> : (
            <ul className="list">{goals.data.filter((g) => g.status !== 'achieved').slice(0, 5).map((g) => <li key={g.id}><div><strong>{g.title}</strong><p className="muted small">{nameOf(g.studentId)}</p></div><ProgressBadge status={g.status} /></li>)}</ul>)}</Card>
      </div>
      <AnnouncementFeed />
      {entryFor !== null && <ProgressForm open students={students.data} initialStudentId={entryFor || undefined} onClose={() => setEntryFor(null)} onSaved={progress.reload} />}
    </>
  );
}

function MyStudents() {
  const { t } = useI18n(); const students = useStudents(); const [open, setOpen] = useState<StudentDoc | null>(null);
  const columns: Column<StudentDoc>[] = [
    { key: 'name', header: t('field.student'), sort: (a, b) => a.displayName.localeCompare(b.displayName), render: (s) => <span className="row"><Avatar name={s.displayName} />{s.displayName}</span> },
    { key: 'id', header: t('field.studentId'), render: (s) => s.studentCode },
    { key: 'track', header: t('field.course'), render: (s) => <Badge tone="teal">{t(`track.${s.track}` as Key)}</Badge> },
    { key: 'level', header: t('field.level'), render: (s) => s.level },
    { key: 'status', header: t('field.status'), render: (s) => <StatusBadge status={s.status} /> },
  ];
  return (
    <>
      <PageHeader title={t('nav.myStudents')} subtitle={t('teacher.studentsSubtitle')} />
      <Card><Loadable loading={students.loading} error={students.error} onRetry={students.reload}>
        <DataTable caption={t('nav.myStudents')} rows={students.data} columns={columns} searchText={(s) => `${s.displayName} ${s.studentCode}`} onRowClick={setOpen} empty={<EmptyState icon={<LuUsers size={28} />} title={t('teacher.noStudents')} text={t('teacher.noStudentsHint')} />} />
      </Loadable></Card>
      {open && <StudentDetail student={open} onClose={() => setOpen(null)} />}
    </>
  );
}

function ProgressPage() {
  const { t, lang } = useI18n(); const { user } = useAuth(); const students = useStudents(); const [form, setForm] = useState<Progress | 'new' | null>(null);
  const since = addDays(todayStr(), -60);
  const progress = useCollection<Progress>('progress', [...ownerScope(user), where('date', '>=', since)], [user.id, since]);
  const rows = [...progress.data].sort((a, b) => b.date.localeCompare(a.date));
  const nameOf = (id: string) => students.data.find((s) => s.id === id)?.displayName ?? '—';
  const columns: Column<Progress>[] = [
    { key: 'date', header: t('field.lessonDate'), sort: (a, b) => a.date.localeCompare(b.date), render: (p) => fmtDate(p.date, lang) },
    { key: 'student', header: t('field.student'), render: (p) => nameOf(p.studentId) },
    { key: 'lesson', header: t('progress.lesson'), render: (p) => p.lesson },
    { key: 'status', header: t('field.status'), render: (p) => <ProgressBadge status={p.status} /> },
    { key: 'by', header: t('progress.submittedByShort'), render: (p) => p.createdByName },
  ];
  return (
    <>
      <PageHeader title={t('nav.progress')} subtitle={t('progress.subtitle')} actions={<Button variant="primary" icon={<LuPlus aria-hidden />} onClick={() => setForm('new')} disabled={students.data.length === 0}>{t('progress.newEntry')}</Button>} />
      <Card><Loadable loading={progress.loading} error={progress.error} onRetry={progress.reload}>
        <DataTable caption={t('nav.progress')} rows={rows} columns={columns} searchText={(p) => `${nameOf(p.studentId)} ${p.lesson}`} onRowClick={setForm} empty={<EmptyState title={t('progress.none')} />} />
      </Loadable></Card>
      {form && <ProgressForm open students={students.data} existing={form === 'new' ? undefined : form} onClose={() => setForm(null)} onSaved={progress.reload} />}
    </>
  );
}
