import { useState } from 'react';
import { LuLogOut } from 'react-icons/lu';
import { LanguageSwitch } from '../../components/LanguageSwitch';
import { Badge, Button, Card, CardHeader, Field, PageHeader, Select, useToast } from '../../components/ui';
import { ChangePassword } from '../ChangePassword';
import { useAuth } from '../../lib/auth';
import { logAudit, tzOptions } from '../../lib/data';
import { useCollection } from '../../lib/hooks';
import type { Lang, Settings as AppSettings } from '../../lib/types';
import { useI18n, type Key } from '../../i18n';

export default function Settings() {
  const { t } = useI18n(); const { user, db, signOut } = useAuth(); const toast = useToast();
  const cfg = useCollection<AppSettings>('config', [], []);
  const stored = cfg.data.find((c) => c.id === 'settings');
  const [defLang, setDefLang] = useState<Lang | null>(null);
  const current = defLang ?? stored?.defaultLanguage ?? 'en';
  async function saveCfg(patch: Partial<AppSettings>) {
    try { await db.set('config', 'settings', patch as Record<string, unknown>, true); await logAudit(db, user.id, 'settings.update', 'settings', Object.fromEntries(Object.entries(patch).map(([k, v]) => [k, String(v)]))); toast('ok', t('toast.saved')); cfg.reload(); }
    catch { toast('err', t('error.save')); }
  }
  async function saveDefault(l: Lang) {
    setDefLang(l);
    try { await db.set('config', 'settings', { defaultLanguage: l, academyName: stored?.academyName ?? 'Jamia Al-Bayan Global' }, true); await logAudit(db, user.id, 'settings.update', 'settings', { defaultLanguage: l }); toast('ok', t('toast.saved')); }
    catch { toast('err', t('error.save')); }
  }
  return (
    <>
      <PageHeader title={t('nav.settings')} />
      <div className="grid cols-2">
        <Card><CardHeader title={t('settings.account')} />
          <dl className="stack" style={{ margin: 0 }}>
            <div><dt className="muted small">{t('field.name')}</dt><dd style={{ margin: 0 }}>{user.displayName}</dd></div>
            <div><dt className="muted small">{t('settings.role')}</dt><dd style={{ margin: 0 }}><Badge tone="teal">{t(`role.${user.role}` as Key)}</Badge></dd></div>
            <div><dt className="muted small">{t('settings.loginId')}</dt><dd style={{ margin: 0 }}>{user.code}</dd></div>
          </dl>
          <div style={{ marginTop: 16 }}><Button icon={<LuLogOut aria-hidden />} onClick={() => void signOut()}>{t('auth.signOut')}</Button></div></Card>
        <Card><CardHeader title={t('settings.language')} subtitle={t('settings.languageHint')} /><LanguageSwitch />
          {user.role === 'principal' && <div style={{ marginTop: 16 }}><Field label={t('settings.defaultLanguage')} hint={t('settings.defaultLanguageHint')}>{(id, d) => (
            <Select id={id} aria-describedby={d} value={current} onChange={(e) => void saveDefault(e.target.value as Lang)}><option value="en">English</option><option value="bn">বাংলা</option></Select>)}</Field></div>}</Card>
        {user.role === 'principal' && <Card><CardHeader title={t('settings.classDefaults')} subtitle={t('settings.classDefaultsHint')} />
          <div className="stack">
            <Field label={t('class.duration')}>{(id) => <Select id={id} value={String(stored?.defaultDuration ?? 30)} onChange={(e) => void saveCfg({ defaultDuration: Number(e.target.value) })}>{[20, 30, 45, 60].map((n) => <option key={n} value={n}>{t('class.minutes', { n })}</option>)}</Select>}</Field>
            <Field label={t('field.timeZone')}>{(id) => <Select id={id} value={stored?.defaultTimeZone ?? ''} onChange={(e) => void saveCfg({ defaultTimeZone: e.target.value })}><option value="">—</option>{tzOptions(stored?.defaultTimeZone).map((z) => <option key={z} value={z}>{z}</option>)}</Select>}</Field>
          </div></Card>}
        <Card className="full"><CardHeader title={t('settings.password')} /><div style={{ maxWidth: 420 }}><ChangePassword /></div></Card>
      </div>
    </>
  );
}
