import { useMemo, useState } from 'react';
import { LuBookmark, LuBookmarkCheck, LuBookOpen, LuCheck } from 'react-icons/lu';
import { Arabic, Badge, Button, Card, CardHeader, EmptyState, Field, Input, Loadable, Modal, PageHeader, Segmented, Select, Textarea, useToast } from '../../components/ui';
import { useAuth } from '../../lib/auth';
import { useStudents } from '../../lib/data';
import { useCollection } from '../../lib/hooks';
import { SERVER_TIME, where } from '../../lib/services';
import type { Assignment, Dua, Lesson } from '../../lib/types';
import { useI18n, type Key } from '../../i18n';

type Tab = 'qaida' | 'duas';
export const DUA_CATEGORIES = ['daily', 'eating', 'sleeping', 'travel', 'learning', 'other'] as const;
const SECTIONS = ['letters', 'harakat', 'reading', 'practice'] as const;

/** Published content only (rules also enforce this for non-Principal users). */
export function usePublished<T extends { order?: number; title: string }>(path: 'lessons' | 'duas') {
  const q = useCollection<T>(path, [where('status', '==', 'published')], []);
  return { ...q, data: [...q.data].sort((a, b) => (a.order ?? 0) - (b.order ?? 0) || a.title.localeCompare(b.title)) };
}

export default function ResourcesPage() {
  const { t } = useI18n(); const { user } = useAuth(); const [tab, setTab] = useState<Tab>('qaida');
  return (
    <>
      <PageHeader title={user.role === 'student' ? t('nav.learn') : t('nav.resources')} subtitle={t('resources.subtitle')} />
      <Segmented<Tab> label={t('nav.resources')} value={tab} onChange={setTab} options={[{ value: 'qaida', label: t('resources.qaida') }, { value: 'duas', label: t('resources.duas') }]} />
      {tab === 'qaida' ? <QaidaView /> : <DuaView />}
    </>
  );
}

function QaidaView() {
  const { t, lang } = useI18n(); const { user, db } = useAuth(); const toast = useToast();
  const lessons = usePublished<Lesson>('lessons');
  const mine = useCollection<Assignment>('assignments', user.role === 'student' ? [where('studentId', '==', user.id)] : [where('teacherId', '==', user.id)], [user.id, user.role]);
  const students = useStudents(); const [assign, setAssign] = useState<Lesson | null>(null);
  const [sid, setSid] = useState(''); const [note, setNote] = useState('');

  async function complete(a: Assignment) {
    try { await db.update('assignments', a.id, { completed: true, completedAt: SERVER_TIME }); mine.reload(); toast('ok', t('toast.saved')); } catch { toast('err', t('error.save')); }
  }
  async function doAssign() {
    const s = students.data.find((x) => x.id === sid); if (!s || !assign) return;
    try {
      await db.add('assignments', { studentId: s.id, teacherId: s.teacherId, lessonId: assign.id, lessonTitle: assign.title, note: note.trim(), completed: false, createdBy: user.id, createdAt: SERVER_TIME });
      toast('ok', t('resources.assigned', { name: s.displayName })); setAssign(null); setNote(''); mine.reload();
    } catch { toast('err', t('error.save')); }
  }
  const assignments = mine.data.filter((a) => user.role === 'student' || !a.completed).sort((a, b) => (b.createdAt ?? '').localeCompare(a.createdAt ?? ''));

  return (
    <div className="stack">
      {user.role === 'student' && assignments.length > 0 && (
        <Card><CardHeader title={t('resources.assignedToMe')} />
          <ul className="list">{assignments.map((a) => (
            <li key={a.id}><div><strong>{a.lessonTitle}</strong>{a.note && <p className="muted small">{a.note}</p>}</div>
              {a.completed ? <Badge tone="green">{t('resources.done')}</Badge> : <Button size="sm" icon={<LuCheck aria-hidden />} onClick={() => void complete(a)}>{t('resources.markDone')}</Button>}</li>))}</ul></Card>)}
      <Loadable loading={lessons.loading} error={lessons.error} onRetry={lessons.reload}>
        {lessons.data.length === 0 ? <Card><EmptyState icon={<LuBookOpen size={28} />} title={t('resources.noLessons')} text={t('resources.noLessonsHint')} /></Card> :
          SECTIONS.map((sec) => {
            const items = lessons.data.filter((l) => l.section === sec); if (!items.length) return null;
            return (
              <Card key={sec}><CardHeader title={t(`lesson.section.${sec}` as Key)} />
                <div className="stack">{items.map((l) => (
                  <article key={l.id} className="stack">
                    <div className="row between"><h3>{lang === 'bn' && l.titleBn ? l.titleBn : l.title}</h3>
                      {user.role === 'teacher' && <Button size="sm" onClick={() => { setAssign(l); setSid(students.data[0]?.id ?? ''); }}>{t('resources.assign')}</Button>}</div>
                    {l.arabicItems.length > 0 && <div className="letters">{l.arabicItems.map((x, i) => <Arabic key={i}>{x}</Arabic>)}</div>}
                    <p className="muted">{lang === 'bn' && l.instructionsBn ? l.instructionsBn : l.instructions}</p>
                  </article>))}</div></Card>);
          })}
      </Loadable>
      <Modal open={Boolean(assign)} onClose={() => setAssign(null)} title={t('resources.assign')} footer={<><Button variant="ghost" onClick={() => setAssign(null)}>{t('common.cancel')}</Button><Button variant="primary" disabled={!sid} onClick={() => void doAssign()}>{t('resources.assign')}</Button></>}>
        <p><strong>{assign?.title}</strong></p>
        <Field label={t('field.student')}>{(id) => <Select id={id} value={sid} onChange={(e) => setSid(e.target.value)}>{students.data.filter((s) => s.status === 'active').map((s) => <option key={s.id} value={s.id}>{s.displayName}</option>)}</Select>}</Field>
        <Field label={t('resources.practiceNote')}>{(id) => <Textarea id={id} maxLength={300} value={note} onChange={(e) => setNote(e.target.value)} />}</Field>
      </Modal>
    </div>
  );
}

export function DuaCard({ d, bookmarked, onToggle }: { d: Dua; bookmarked?: boolean; onToggle?: () => void }) {
  const { t, lang } = useI18n();
  const first = lang === 'bn' ? d.meaningBn || d.meaningEn : d.meaningEn || d.meaningBn;
  const second = lang === 'bn' ? d.meaningEn : d.meaningBn;
  return (
    <article className="stack">
      <div className="row between"><h3>{d.title}</h3><div className="row"><Badge tone="gold">{t(`dua.cat.${d.category}` as Key)}</Badge>
        {onToggle && <button className="icon-btn" onClick={onToggle} aria-pressed={bookmarked} aria-label={bookmarked ? t('dua.unbookmark') : t('dua.bookmark')}>{bookmarked ? <LuBookmarkCheck aria-hidden /> : <LuBookmark aria-hidden />}</button>}</div></div>
      <div className="dua-ar">{d.arabic ? <Arabic size="lg">{d.arabic}</Arabic> : <span className="muted">{t('dua.arabicPending')}</span>}</div>
      {d.transliteration && <p><em>{d.transliteration}</em></p>}
      {first && <p>{first}</p>}{second && <p className="muted">{second}</p>}
      {d.source && <p className="muted small">{t('dua.source')}: {d.source}</p>}
    </article>
  );
}

function DuaView() {
  const { t } = useI18n(); const { user, db } = useAuth(); const toast = useToast();
  const duas = usePublished<Dua>('duas');
  const marks = useCollection<{ id: string }>(`users/${user.id}/bookmarks`, [], [user.id]);
  const [q, setQ] = useState(''); const [cat, setCat] = useState('all'); const [onlyMarked, setOnlyMarked] = useState(false);
  const marked = useMemo(() => new Set(marks.data.map((m) => m.id)), [marks.data]);
  const rows = duas.data.filter((d) => (cat === 'all' || d.category === cat) && (!onlyMarked || marked.has(d.id)) &&
    `${d.title} ${d.transliteration} ${d.meaningEn} ${d.meaningBn} ${d.arabic}`.toLowerCase().includes(q.trim().toLowerCase()));
  async function toggle(id: string) {
    try { if (marked.has(id)) await db.remove(`users/${user.id}/bookmarks`, id); else await db.set(`users/${user.id}/bookmarks`, id, { createdAt: SERVER_TIME }); marks.reload(); }
    catch { toast('err', t('error.save')); }
  }
  return (
    <div className="stack">
      <div className="row">
        <Input type="search" style={{ maxWidth: 320 }} aria-label={t('common.search')} placeholder={t('common.search')} value={q} onChange={(e) => setQ(e.target.value)} />
        <Select aria-label={t('dua.category')} style={{ maxWidth: 200 }} value={cat} onChange={(e) => setCat(e.target.value)}><option value="all">{t('dua.allCategories')}</option>{DUA_CATEGORIES.map((c) => <option key={c} value={c}>{t(`dua.cat.${c}` as Key)}</option>)}</Select>
        <Button size="sm" variant={onlyMarked ? 'primary' : 'secondary'} aria-pressed={onlyMarked} onClick={() => setOnlyMarked((v) => !v)}>{t('dua.bookmarks')}</Button>
      </div>
      <Loadable loading={duas.loading} error={duas.error} onRetry={duas.reload}>
        {rows.length === 0 ? <Card><EmptyState icon={<LuBookOpen size={28} />} title={duas.data.length ? t('common.noResults') : t('dua.none')} text={duas.data.length ? undefined : t('dua.noneHint')} /></Card>
          : rows.map((d) => <Card key={d.id}><DuaCard d={d} bookmarked={marked.has(d.id)} onToggle={() => void toggle(d.id)} /></Card>)}
      </Loadable>
    </div>
  );
}
