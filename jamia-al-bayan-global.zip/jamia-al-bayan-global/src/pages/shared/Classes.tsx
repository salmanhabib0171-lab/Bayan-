import { useEffect, useMemo, useState } from 'react';
import { LuCalendarPlus, LuVideo } from 'react-icons/lu';
import { AttendanceBadge, Badge, Button, DataTable, EmptyState, Field, Input, Loadable, Modal, PageHeader, Segmented, Select, Textarea, useToast, Card, type Column } from '../../components/ui';
import { ZoomJoin } from '../../components/ZoomJoin';
import { useAuth } from '../../lib/auth';
import { isZoomUrl, logAudit, ownerScope, tzOptions, useStudents } from '../../lib/data';
import { addDays, browserTimeZone, fmtDateTime, todayStr, tzLabel, zonedToUtcIso } from '../../lib/dates';
import { useCollection, useDoc } from '../../lib/hooks';
import { SERVER_TIME, where } from '../../lib/services';
import { ATTENDANCE_STATUSES, type Attendance, type AttendanceStatus, type ClassSession, type Settings, type StudentDoc } from '../../lib/types';
import { useI18n, type Key } from '../../i18n';

type Tab = 'today' | 'upcoming' | 'past';

export default function ClassesPage() {
  const { t, lang } = useI18n(); const { user, db } = useAuth(); const toast = useToast();
  const staff = user.role !== 'student';
  const [tab, setTab] = useState<Tab>('today'); const [editing, setEditing] = useState<ClassSession | 'new' | null>(null);
  const students = useStudents();
  const since = addDays(todayStr(), -30);
  const sinceIso = `${since}T00:00:00.000Z`;
  const classScope = user.role === 'teacher' ? [where('teacherId', '==', user.id)] : user.role === 'student' ? [where('studentIds', 'array-contains', user.id)] : [];
  const classes = useCollection<ClassSession>('classes', [...classScope, where('startsAt', '>=', sinceIso)], [user.id, user.role, since]);
  const att = useCollection<Attendance>('attendance', [...ownerScope(user), where('date', '>=', since)], [user.id, since]);
  const attByClass = useMemo(() => new Map(att.data.map((a) => [a.classId || a.id, a])), [att.data]);
  const tz = browserTimeZone();
  const today = todayStr(tz);

  const rows = useMemo(() => {
    const start = (c: ClassSession) => new Date(c.startsAt).getTime();
    const day = (c: ClassSession) => todayStr(tz, new Date(c.startsAt));
    const f = classes.data.filter((c) => (tab === 'today' ? day(c) === today : tab === 'upcoming' ? day(c) > today : day(c) < today));
    return f.sort((a, b) => (tab === 'past' ? start(b) - start(a) : start(a) - start(b)));
  }, [classes.data, tab, today, tz]);

  async function markAttendance(c: ClassSession, studentId: string, status: AttendanceStatus) {
    const s = students.data.find((x) => x.id === studentId);
    try {
      await db.set('attendance', `${studentId}_${c.id}`, { studentId, teacherId: c.teacherId, classId: c.id, date: todayStr(c.timeZone, new Date(c.startsAt)), status, note: '', recordedBy: user.id, updatedAt: SERVER_TIME }, true);
      toast('ok', t('toast.attendanceSaved', { name: s?.displayName ?? '' })); att.reload();
    } catch { toast('err', t('error.save')); }
  }

  const columns: Column<ClassSession>[] = [
    { key: 'title', header: t('class.title'), render: (c) => <span><strong>{c.title}</strong><br /><span className="muted small">{staff ? c.studentNames.join(', ') : c.teacherName}</span></span> },
    { key: 'when', header: t('class.when'), sort: (a, b) => a.startsAt.localeCompare(b.startsAt), render: (c) => (
      <span>{fmtDateTime(c.startsAt, lang, tz)} <span className="muted small">({tzLabel(tz, lang, c.startsAt)})</span>
        {c.timeZone !== tz && <><br /><span className="muted small">{t('class.originalTime')}: {fmtDateTime(c.startsAt, lang, c.timeZone)} ({tzLabel(c.timeZone, lang, c.startsAt)})</span></>}</span>) },
    { key: 'dur', header: t('class.duration'), render: (c) => t('class.minutes', { n: c.durationMin }) },
    { key: 'status', header: t('field.status'), render: (c) => <Badge tone={c.status === 'completed' ? 'green' : c.status === 'cancelled' ? 'red' : 'teal'}>{t(`class.status.${c.status}` as Key)}</Badge> },
    { key: 'att', header: t('nav.attendance'), render: (c) => {
      const sid = c.studentIds[0]; const a = attByClass.get(c.id) ?? attByClass.get(`${sid}_${c.id}`);
      if (!staff) return a ? <AttendanceBadge status={a.status} /> : <span className="muted">—</span>;
      return c.studentIds.length === 1 ? (
        <Select aria-label={t('nav.attendance')} value={a?.status ?? ''} onChange={(e) => void markAttendance(c, sid, e.target.value as AttendanceStatus)} style={{ minWidth: 120 }}>
          <option value="" disabled>{t('attendance.mark')}</option>{ATTENDANCE_STATUSES.map((s) => <option key={s} value={s}>{t(`attendance.${s}` as Key)}</option>)}
        </Select>) : <span className="muted small">{t('class.groupAttendance')}</span>;
    } },
    { key: 'act', header: '', render: (c) => <div className="row">{!(tab === 'past') && <ZoomJoin cls={c} size="sm" />}{staff && <Button size="sm" variant="ghost" onClick={() => setEditing(c)}>{t('common.edit')}</Button>}</div> },
  ];

  return (
    <>
      <PageHeader title={t('nav.classes')} subtitle={t('class.subtitle', { tz: `${tz} (${tzLabel(tz, lang)})` })}
        actions={staff && <Button variant="primary" icon={<LuCalendarPlus aria-hidden />} onClick={() => setEditing('new')} disabled={students.data.filter((s) => s.status === 'active').length === 0}>{t('class.schedule')}</Button>} />
      <Card>
        <div className="row between" style={{ marginBottom: 12 }}>
          <Segmented<Tab> label={t('class.filter')} value={tab} onChange={setTab} options={[{ value: 'today', label: t('class.today') }, { value: 'upcoming', label: t('class.upcoming') }, { value: 'past', label: t('class.past') }]} />
        </div>
        <Loadable loading={classes.loading} error={classes.error} onRetry={classes.reload}>
          <DataTable caption={t('nav.classes')} rows={rows} columns={columns} pageSize={8} searchText={(c) => `${c.title} ${c.studentNames.join(' ')} ${c.teacherName}`}
            empty={<EmptyState icon={<LuVideo size={28} />} title={t(`class.none.${tab}` as Key)} />} />
        </Loadable>
      </Card>
      {editing && <ClassForm cls={editing === 'new' ? undefined : editing} students={students.data} onClose={() => setEditing(null)} onSaved={() => { classes.reload(); void logAudit(db, user.id, editing === 'new' ? 'class.create' : 'class.update', typeof editing === 'object' ? editing.id : 'new'); }} />}
    </>
  );
}

export function ClassForm({ cls, students, onClose, onSaved }: { cls?: ClassSession; students: StudentDoc[]; onClose: () => void; onSaved: () => void }) {
  const { t, lang } = useI18n(); const { db, user } = useAuth(); const toast = useToast();
  const active = students.filter((s) => s.status === 'active');
  const [sid, setSid] = useState(cls?.studentIds[0] ?? active[0]?.id ?? '');
  const student = students.find((s) => s.id === sid);
  const initTz = cls?.timeZone ?? student?.timeZone ?? browserTimeZone();
  const [zone, setZone] = useState(initTz);
  const initial = cls ? new Intl.DateTimeFormat('en-CA', { timeZone: cls.timeZone, dateStyle: 'short', hourCycle: 'h23', timeStyle: 'short' }).format(new Date(cls.startsAt)).replace(',', '') : '';
  const [date, setDate] = useState(cls ? initial.slice(0, 10) : todayStr(initTz));
  const [time, setTime] = useState(cls ? initial.slice(-5) : '17:00');
  const [title, setTitle] = useState(cls?.title ?? ''); const [duration, setDuration] = useState(String(cls?.durationMin ?? 30));
  const defaults = useDoc<Settings>('config', 'settings').data;
  useEffect(() => { if (!cls && defaults?.defaultDuration) setDuration(String(defaults.defaultDuration)); }, [cls, defaults]);
  const [zoomUrl, setZoomUrl] = useState(cls?.zoomUrl ?? ''); const [notes, setNotes] = useState(cls?.notes ?? '');
  const [status, setStatus] = useState<ClassSession['status']>(cls?.status ?? 'scheduled');
  const [errors, setErrors] = useState<Record<string, string>>({}); const [busy, setBusy] = useState(false);
  const iso = date && time ? zonedToUtcIso(date, time, zone) : '';

  async function save() {
    const e: Record<string, string> = {}; const dur = Number(duration);
    if (!student && !cls) e.student = t('validation.required');
    if (title.trim().length < 3) e.title = t('validation.titleShort');
    if (!date || !time) e.date = t('validation.required');
    if (!Number.isInteger(dur) || dur < 5 || dur > 240) e.duration = t('validation.duration');
    if (zoomUrl && !isZoomUrl(zoomUrl.trim())) e.zoom = t('validation.zoom');
    setErrors(e); if (Object.keys(e).length) return;
    setBusy(true);
    try {
      const base = { title: title.trim(), startsAt: iso, timeZone: zone, durationMin: dur, zoomUrl: zoomUrl.trim(), notes: notes.trim(), status };
      if (cls) await db.update('classes', cls.id, base);
      else await db.add('classes', { ...base, teacherId: student!.teacherId, teacherName: student!.teacherName, studentIds: [student!.id], studentNames: [student!.displayName], createdBy: user.id, createdAt: SERVER_TIME });
      toast('ok', t('toast.saved')); onSaved(); onClose();
    } catch { toast('err', t('error.save')); } finally { setBusy(false); }
  }
  return (
    <Modal open wide onClose={onClose} title={cls ? t('class.edit') : t('class.schedule')} footer={<><Button variant="ghost" onClick={onClose}>{t('common.cancel')}</Button><Button variant="primary" loading={busy} onClick={save}>{t('common.save')}</Button></>}>
      <div className="form-grid">
        <Field label={t('class.title')} required error={errors.title}>{(id, d) => <Input id={id} aria-describedby={d} maxLength={120} value={title} onChange={(e) => setTitle(e.target.value)} />}</Field>
        <Field label={t('field.student')} required error={errors.student}>{(id) => (
          <Select id={id} value={sid} disabled={Boolean(cls)} onChange={(e) => { setSid(e.target.value); const s = students.find((x) => x.id === e.target.value); if (s) setZone(s.timeZone); }}>
            {(cls ? students : active).map((s) => <option key={s.id} value={s.id}>{s.displayName} · {s.studentCode}</option>)}
          </Select>)}</Field>
        <Field label={t('class.date')} required error={errors.date}>{(id, d) => <Input id={id} aria-describedby={d} type="date" value={date} onChange={(e) => setDate(e.target.value)} />}</Field>
        <Field label={t('class.time')} required>{(id) => <Input id={id} type="time" value={time} onChange={(e) => setTime(e.target.value)} />}</Field>
        <Field label={t('field.timeZone')} hint={iso ? t('class.yourTime', { time: fmtDateTime(iso, lang, browserTimeZone()) }) : undefined}>{(id, d) => <Select id={id} aria-describedby={d} value={zone} onChange={(e) => setZone(e.target.value)}>{tzOptions(zone, student?.timeZone, browserTimeZone()).map((z) => <option key={z} value={z}>{z}</option>)}</Select>}</Field>
        <Field label={t('class.duration')} required error={errors.duration}>{(id, d) => <Input id={id} aria-describedby={d} type="number" min={5} max={240} step={5} value={duration} onChange={(e) => setDuration(e.target.value)} />}</Field>
        <div className="full"><Field label={t('class.zoomUrl')} hint={t('class.zoomHint')} error={errors.zoom}>{(id, d) => <Input id={id} aria-describedby={d} type="url" inputMode="url" placeholder="https://zoom.us/j/…" value={zoomUrl} onChange={(e) => setZoomUrl(e.target.value)} />}</Field></div>
        {cls && <Field label={t('field.status')}>{(id) => <Select id={id} value={status} onChange={(e) => setStatus(e.target.value as ClassSession['status'])}>{(['scheduled', 'completed', 'cancelled'] as const).map((s) => <option key={s} value={s}>{t(`class.status.${s}` as Key)}</option>)}</Select>}</Field>}
        <div className="full"><Field label={t('class.notes')}>{(id) => <Textarea id={id} maxLength={500} value={notes} onChange={(e) => setNotes(e.target.value)} />}</Field></div>
      </div>
    </Modal>
  );
}
