import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { LuMessageCircle, LuSend } from 'react-icons/lu';
import { Avatar, Button, Card, EmptyState, ErrorState, Input, PageHeader, Select, Skeleton, useToast } from '../../components/ui';
import { useAuth } from '../../lib/auth';
import { useStudents } from '../../lib/data';
import { fmtDateTime } from '../../lib/dates';
import { useCollection } from '../../lib/hooks';
import { SERVER_TIME, limit, orderBy, where } from '../../lib/services';
import type { Conversation, Message, StudentDoc } from '../../lib/types';
import { useI18n } from '../../i18n';

const MAX = 1000;
export const isUnread = (c: Conversation, me: string) => Boolean(c.lastMessageAt && c.lastSenderId !== me && (!c.readAt?.[me] || c.readAt[me] < c.lastMessageAt));

export default function MessagesPage() {
  const { t } = useI18n(); const { user, db } = useAuth(); const toast = useToast();
  const convs = useCollection<Conversation>('conversations', [where('participants', 'array-contains', user.id)], [user.id], true);
  const students = useStudents(); // teachers: assigned students only
  const [me, setMe] = useState<StudentDoc | null>(null);
  const [active, setActive] = useState<string | null>(null); const [pick, setPick] = useState('');
  useEffect(() => { if (user.role === 'student') void db.get<StudentDoc>('students', user.id).then(setMe); }, [db, user]);

  const list = useMemo(() => [...convs.data].sort((a, b) => (b.lastMessageAt ?? '').localeCompare(a.lastMessageAt ?? '')), [convs.data]);
  // The conversation partner for a student is always their currently assigned teacher.
  const studentCid = me ? `${me.teacherId}_${user.id}` : null;
  useEffect(() => { if (user.role === 'student' && studentCid && !active) setActive(studentCid); }, [user.role, studentCid, active]);

  const startable = students.data.filter((s) => s.status === 'active' && !list.some((c) => c.id === `${user.id}_${s.id}`));
  const current = list.find((c) => c.id === active);
  const nameOf = (c: Conversation) => (user.role === 'teacher' ? c.studentName : c.teacherName);

  return (
    <>
      <PageHeader title={t('nav.messages')} subtitle={t('messages.subtitle')} />
      <Card className="chat">
        <div className="stack" style={{ alignContent: 'start' }}>
          {user.role === 'teacher' && startable.length > 0 && (
            <div className="row"><Select aria-label={t('messages.new')} value={pick} onChange={(e) => { setPick(e.target.value); if (e.target.value) { setActive(`${user.id}_${e.target.value}`); } }}>
              <option value="">{t('messages.new')}</option>{startable.map((s) => <option key={s.id} value={s.id}>{s.displayName}</option>)}</Select></div>)}
          {convs.loading ? <Skeleton /> : convs.error ? <ErrorState onRetry={convs.reload} /> : (
            <div className="chat-list" role="list">
              {list.map((c) => (
                <button key={c.id} role="listitem" aria-current={active === c.id} onClick={() => { setActive(c.id); setPick(''); }}>
                  <span className="row"><Avatar name={nameOf(c)} /><strong>{nameOf(c)}</strong>{isUnread(c, user.id) && <span className="dot" aria-label={t('messages.unread')} />}</span>
                  <span className="prev">{c.lastPreview ?? ''}</span>
                </button>))}
              {list.length === 0 && user.role === 'teacher' && <p className="muted small">{t('messages.empty')}</p>}
            </div>)}
        </div>
        {active ? <Thread key={active} cid={active} conv={current} student={user.role === 'student' ? me : students.data.find((s) => `${user.id}_${s.id}` === active) ?? null} onError={() => toast('err', t('error.send'))} />
          : <EmptyState icon={<LuMessageCircle size={28} />} title={t('messages.pick')} text={user.role === 'student' ? t('messages.studentHint') : undefined} />}
      </Card>
    </>
  );
}

function Thread({ cid, conv, student, onError }: { cid: string; conv?: Conversation; student: StudentDoc | null; onError: () => void }) {
  const { t, lang } = useI18n(); const { user, db } = useAuth();
  const msgs = useCollection<Message>(`conversations/${cid}/messages`, [orderBy('createdAt', 'desc'), limit(100)], [cid], true);
  const [text, setText] = useState(''); const [busy, setBusy] = useState(false); const end = useRef<HTMLDivElement>(null);
  const ordered = useMemo(() => [...msgs.data].reverse(), [msgs.data]);
  useEffect(() => { end.current?.scrollIntoView({ block: 'end' }); }, [ordered.length]);

  // Mark as read when new incoming messages are visible.
  useEffect(() => {
    if (conv && isUnread(conv, user.id)) void db.update('conversations', cid, { readAt: { ...(conv.readAt ?? {}), [user.id]: SERVER_TIME } }).catch(() => undefined);
  }, [conv, cid, db, user.id]);

  async function send(e: FormEvent) {
    e.preventDefault(); const body = text.trim();
    if (!body || body.length > MAX || !student) return;
    setBusy(true);
    try {
      if (!conv) { // first message: create the conversation, then post (rules check the parent in a separate step)
        await db.set('conversations', cid, { teacherId: student.teacherId, studentId: student.id, teacherName: student.teacherName, studentName: student.displayName, participants: [student.teacherId, student.id], lastMessageAt: SERVER_TIME, lastSenderId: user.id, lastPreview: '', readAt: {} });
      }
      await db.batch([
        { op: 'set', path: `conversations/${cid}/messages`, id: crypto.randomUUID().replace(/-/g, ''), data: { senderId: user.id, text: body, createdAt: SERVER_TIME } },
        { op: 'update', path: 'conversations', id: cid, data: { lastMessageAt: SERVER_TIME, lastSenderId: user.id, lastPreview: body.slice(0, 80), readAt: { ...(conv?.readAt ?? {}), [user.id]: SERVER_TIME } } },
      ]);
      setText('');
    } catch { onError(); } finally { setBusy(false); }
  }

  return (
    <div className="thread">
      <div className="msgs" aria-live="polite">
        {msgs.loading ? <Skeleton /> : msgs.error ? <ErrorState onRetry={msgs.reload} /> : ordered.length === 0 ? <p className="muted center-pad">{t('messages.noneYet')}</p> :
          ordered.map((m) => <div key={m.id} className={`bubble${m.senderId === user.id ? ' mine' : ''}`}>{m.text}<time dateTime={m.createdAt}>{fmtDateTime(m.createdAt, lang)}</time></div>)}
        <div ref={end} />
      </div>
      <form className="row" onSubmit={send} style={{ flexWrap: 'nowrap' }}>
        <Input aria-label={t('messages.write')} placeholder={t('messages.write')} maxLength={MAX} value={text} onChange={(e) => setText(e.target.value)} disabled={!student} />
        <Button type="submit" variant="primary" loading={busy} disabled={!text.trim() || !student} aria-label={t('messages.send')} icon={<LuSend aria-hidden />} />
      </form>
      <p className="muted small" style={{ textAlign: 'end' }}>{text.length}/{MAX}</p>
    </div>
  );
}
