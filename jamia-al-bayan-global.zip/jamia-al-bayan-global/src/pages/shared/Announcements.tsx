import { LuBell } from 'react-icons/lu';
import { useReads } from '../../components/Notifications';
import { Badge, Card, CardHeader, EmptyState, Loadable } from '../../components/ui';
import { useAuth } from '../../lib/auth';
import { fmtDate } from '../../lib/dates';
import { useCollection } from '../../lib/hooks';
import { limit, orderBy, where } from '../../lib/services';
import type { Announcement } from '../../lib/types';
import { useI18n } from '../../i18n';

/**
 * Announcements the signed-in teacher/student may read. Uses one plain equality query per audience so each query is
 * provably within the Firestore rules (no `in` filters). The Principal manages announcements on their own page.
 */
export function useAnnouncements(refresh = 0) {
  const { user } = useAuth();
  const staff = user.role === 'teacher';
  const mk = (aud: string | null) => (aud ? [where('audience', '==', aud), orderBy('createdAt', 'desc'), limit(10)] : []);
  const all = useCollection<Announcement>(user.role === 'principal' ? null : 'announcements', mk('all'), [user.role, refresh]);
  const group = useCollection<Announcement>(user.role === 'principal' ? null : 'announcements', mk(staff ? 'teachers' : 'students'), [user.role, refresh]);
  const one = useCollection<Announcement>(user.role === 'student' ? 'announcements' : null, [where('targetStudentId', '==', user.id), orderBy('createdAt', 'desc'), limit(10)], [user.id, refresh]);
  const data = [...all.data, ...group.data, ...one.data].sort((a, b) => (b.createdAt ?? '').localeCompare(a.createdAt ?? ''));
  return { data, loading: all.loading || group.loading || one.loading, error: all.error ?? group.error ?? one.error, reload: () => { all.reload(); group.reload(); one.reload(); } };
}

export function AnnouncementFeed() {
  const { t, lang } = useI18n(); const { ids } = useReads(); const a = useAnnouncements();
  const rows = a.data.slice(0, 5);
  return (
    <Card><CardHeader title={t('nav.announcements')} />
      <Loadable loading={a.loading} error={a.error} onRetry={a.reload} rows={2}>
        {rows.length === 0 ? <EmptyState icon={<LuBell size={26} />} title={t('announce.none')} /> : (
          <ul className="list">{rows.map((x) => <li key={x.id}><div><strong>{x.title}</strong> {!ids.has(x.id) && <Badge tone="gold">{t('announce.new_badge')}</Badge>}<p className="muted" style={{ whiteSpace: 'pre-wrap' }}>{x.body}</p></div><span className="muted small">{fmtDate(x.createdAt?.slice(0, 10), lang)}</span></li>)}</ul>)}
      </Loadable>
    </Card>
  );
}
