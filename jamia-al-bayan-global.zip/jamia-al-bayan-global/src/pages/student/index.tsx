import { lazy, Suspense, useMemo } from 'react';
import { LuMessageCircle, LuTarget } from 'react-icons/lu';
import { Badge, Card, CardHeader, EmptyState, Loadable, ProgressBadge, Spinner } from '../../components/ui';
import { ZoomJoin } from '../../components/ZoomJoin';
import { useAuth } from '../../lib/auth';
import { fmtDate, fmtDateTime, tzLabel, browserTimeZone } from '../../lib/dates';
import { useCollection, useDoc } from '../../lib/hooks';
import { Link } from '../../lib/router';
import { where } from '../../lib/services';
import type { Assignment, ClassSession, Conversation, Goal, Progress, StudentDoc } from '../../lib/types';
import { useI18n, type Key } from '../../i18n';
import { AnnouncementFeed } from '../shared/Announcements';
import { isUnread } from '../shared/Messages';

const Resources = lazy(() => import('../shared/Resources'));
const Messages = lazy(() => import('../shared/Messages'));

export default function StudentApp({ path }: { path: string }) {
  return <Suspense fallback={<Spinner />}>{path === '/student/resources' ? <Resources /> : path === '/student/messages' ? <Messages /> : <Home />}</Suspense>;
}

function Home() {
  const { t, lang } = useI18n(); const { user } = useAuth(); const tz = browserTimeZone();
  const me = useDoc<StudentDoc>('students', user.id).data; // own profile only (rules allow just this document)
  const nowIso = new Date(Date.now() - 2 * 3600_000).toISOString();
  const classes = useCollection<ClassSession>('classes', [where('studentIds', 'array-contains', user.id), where('startsAt', '>=', nowIso)], [user.id]);
  const goals = useCollection<Goal>('goals', [where('studentId', '==', user.id)], [user.id]);
  const progress = useCollection<Progress>('progress', [where('studentId', '==', user.id)], [user.id]);
  const assigns = useCollection<Assignment>('assignments', [where('studentId', '==', user.id)], [user.id]);
  const convs = useCollection<Conversation>('conversations', [where('participants', 'array-contains', user.id)], [user.id], true);

  const next = useMemo(() => classes.data.filter((c) => c.status === 'scheduled').sort((a, b) => a.startsAt.localeCompare(b.startsAt))[0], [classes.data]);
  const latest = useMemo(() => [...progress.data].sort((a, b) => b.date.localeCompare(a.date))[0], [progress.data]);
  const openGoals = goals.data.filter((g) => g.status !== 'achieved');
  const todo = assigns.data.filter((a) => !a.completed);
  const unread = convs.data.filter((c) => isUnread(c, user.id)).length;

  return (
    <>
      <section className="hero" aria-labelledby="hi">
        <div><h1 id="hi">{t('student.welcome', { name: user.displayName })}</h1>
          <p className="muted">{me ? <>{t(`track.${me.track}` as Key)} · {me.level}</> : '\u00A0'}</p></div>
        <Loadable loading={classes.loading} error={classes.error} onRetry={classes.reload} rows={1}>
          {next ? (
            <div className="stack"><h2>{t('student.nextClass')}</h2>
              <p>{next.title} — {fmtDateTime(next.startsAt, lang, tz)} <span className="muted">({tzLabel(tz, lang, next.startsAt)})</span></p>
              <ZoomJoin cls={next} size="lg" /></div>
          ) : <p className="muted">{t('student.noClass')}</p>}
        </Loadable>
      </section>

      <div className="grid cols-2">
        <Card><CardHeader title={t('student.currentGoal')} />
          <Loadable loading={goals.loading} error={goals.error} onRetry={goals.reload} rows={2}>
            {openGoals.length === 0 ? <EmptyState icon={<LuTarget size={26} />} title={t('student.noGoal')} /> : (
              <ul className="list">{openGoals.slice(0, 3).map((g) => <li key={g.id}><strong>{g.title}</strong><ProgressBadge status={g.status} /></li>)}</ul>)}
          </Loadable></Card>
        <Card><CardHeader title={t('student.latestFeedback')} />
          <Loadable loading={progress.loading} error={progress.error} onRetry={progress.reload} rows={2}>
            {latest ? <div className="stack"><div className="row between"><strong>{latest.lesson}</strong><ProgressBadge status={latest.status} /></div>
              <p>{latest.feedback || t('student.noFeedbackText')}</p>{latest.homework && <p className="muted"><Badge tone="gold">{t('progress.homework')}</Badge> {latest.homework}</p>}
              <p className="muted small">{fmtDate(latest.date, lang)} · {latest.createdByName}</p></div> : <EmptyState title={t('student.noFeedback')} />}
          </Loadable></Card>
        <Card><CardHeader title={t('student.myLessons')} action={<Link to="/student/resources" className="small">{t('common.viewAll')}</Link>} />
          {todo.length === 0 ? <p className="muted">{t('student.noLessons')}</p> : <ul className="list">{todo.slice(0, 3).map((a) => <li key={a.id}><div><strong>{a.lessonTitle}</strong>{a.note && <p className="muted small">{a.note}</p>}</div></li>)}</ul>}</Card>
        <Card><CardHeader title={t('nav.messages')} action={<Link to="/student/messages" className="small">{t('common.open')}</Link>} />
          <p className="row"><LuMessageCircle aria-hidden />{unread > 0 ? <><span className="dot" aria-hidden /> {t('messages.unreadCount', { n: unread })}</> : <span className="muted">{t('messages.noUnread')}</span>}</p></Card>
      </div>
      <AnnouncementFeed />
    </>
  );
}
