import { lazy, Suspense } from 'react';
import { Spinner } from '../../components/ui';
import Dashboard from './Dashboard';

const Students = lazy(() => import('./Students'));
const Teachers = lazy(() => import('./Teachers'));
const Classes = lazy(() => import('../shared/Classes'));
const Attendance = lazy(() => import('./Attendance'));
const Progress = lazy(() => import('./Progress'));
const Resources = lazy(() => import('./ResourceManager'));
const Announcements = lazy(() => import('./AnnouncementsAdmin'));
const Reports = lazy(() => import('./Reports'));
const Audit = lazy(() => import('./Audit'));

const routes: Record<string, React.LazyExoticComponent<() => React.JSX.Element>> = {
  '/principal/students': Students as never, '/principal/teachers': Teachers as never, '/principal/classes': Classes as never, '/principal/attendance': Attendance as never,
  '/principal/progress': Progress as never, '/principal/resources': Resources as never, '/principal/announcements': Announcements as never, '/principal/reports': Reports as never, '/principal/audit': Audit as never,
};
export default function PrincipalApp({ path }: { path: string }) {
  const Page = routes[path];
  return Page ? <Suspense fallback={<Spinner />}><Page /></Suspense> : <Dashboard />;
}
