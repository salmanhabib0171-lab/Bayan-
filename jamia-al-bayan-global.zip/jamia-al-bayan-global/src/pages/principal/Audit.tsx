import { LuScrollText } from 'react-icons/lu';
import { Badge, Card, DataTable, EmptyState, Loadable, PageHeader, type Column } from '../../components/ui';
import { fmtDateTime } from '../../lib/dates';
import { useCollection } from '../../lib/hooks';
import { limit, orderBy } from '../../lib/services';
import type { AuditEntry, UserDoc } from '../../lib/types';
import { useI18n } from '../../i18n';

export default function Audit() {
  const { t, lang } = useI18n();
  const log = useCollection<AuditEntry>('audit', [orderBy('createdAt', 'desc'), limit(200)], []);
  const users = useCollection<UserDoc>('users', [], []);
  const who = (id: string) => users.data.find((u) => u.id === id)?.displayName ?? id.slice(0, 6);
  const cols: Column<AuditEntry>[] = [
    { key: 'when', header: t('audit.when'), sort: (a, b) => (a.createdAt ?? '').localeCompare(b.createdAt ?? ''), render: (a) => fmtDateTime(a.createdAt, lang) },
    { key: 'actor', header: t('audit.actor'), render: (a) => who(a.actorId) },
    { key: 'action', header: t('audit.action'), render: (a) => <Badge tone="teal">{a.action}</Badge> },
    { key: 'target', header: t('audit.target'), render: (a) => <span className="muted small">{users.data.find((u) => u.id === a.targetId)?.displayName ?? a.targetId.slice(0, 8)}</span> },
  ];
  return (
    <>
      <PageHeader title={t('nav.audit')} subtitle={t('audit.subtitle')} />
      <Card><Loadable loading={log.loading} error={log.error} onRetry={log.reload}>
        <DataTable caption={t('nav.audit')} rows={log.data} columns={cols} searchText={(a) => `${a.action} ${who(a.actorId)}`} empty={<EmptyState icon={<LuScrollText size={28} />} title={t('audit.none')} />} />
        <p className="muted small" style={{ marginTop: 10 }}>{t('audit.note')}</p></Loadable></Card>
    </>
  );
}
