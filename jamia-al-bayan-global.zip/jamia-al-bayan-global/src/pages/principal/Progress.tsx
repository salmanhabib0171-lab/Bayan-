import { useMemo, useState } from 'react';
import { LuDownload, LuPlus } from 'react-icons/lu';
import { ProgressForm } from '../../components/ProgressForm';
import { Button, Card, DataTable, EmptyState, Field, Input, Loadable, PageHeader, ProgressBadge, Select, Stat, type Column } from '../../components/ui';
import { useAuth } from '../../lib/auth';
import { logAudit } from '../../lib/data';
import { addDays, fmtDate, todayStr } from '../../lib/dates';
import { downloadCsv } from '../../lib/download';
import { PROGRESS_STATUSES, type Progress } from '../../lib/types';
import { useI18n, type Key } from '../../i18n';
import { useRangeData } from './useRangeData';

export default function ProgressReview() {
  const { t, lang } = useI18n(); const { db, user } = useAuth();
  const [from, setFrom] = useState(addDays(todayStr(), -30)); const [to, setTo] = useState(todayStr());
  const [teacher, setTeacher] = useState('all'); const [student, setStudent] = useState('all'); const [form, setForm] = useState<Progress | 'new' | null>(null);
  const d = useRangeData(from, to);
  const name = (id: string) => d.students.find((s) => s.id === id)?.displayName ?? '—';
  const rows = useMemo(() => d.progress.filter((p) => (teacher === 'all' || p.teacherId === teacher) && (student === 'all' || p.studentId === student)).sort((a, b) => b.date.localeCompare(a.date)), [d.progress, teacher, student]);
  const columns: Column<Progress>[] = [
    { key: 'date', header: t('field.lessonDate'), sort: (a, b) => a.date.localeCompare(b.date), render: (p) => fmtDate(p.date, lang) },
    { key: 'student', header: t('field.student'), sort: (a, b) => name(a.studentId).localeCompare(name(b.studentId)), render: (p) => name(p.studentId) },
    { key: 'lesson', header: t('progress.lesson'), render: (p) => p.lesson },
    { key: 'status', header: t('field.status'), render: (p) => <ProgressBadge status={p.status} /> },
    { key: 'by', header: t('progress.submittedByShort'), render: (p) => p.createdByName },
  ];
  const counts = PROGRESS_STATUSES.map((s) => ({ s, n: rows.filter((r) => r.status === s).length }));
  const filters = <>
    <Select aria-label={t('field.teacher')} style={{ maxWidth: 200 }} value={teacher} onChange={(e) => setTeacher(e.target.value)}><option value="all">{t('filter.allTeachers')}</option>{d.teachers.map((x) => <option key={x.id} value={x.id}>{x.displayName}</option>)}</Select>
    <Select aria-label={t('field.student')} style={{ maxWidth: 200 }} value={student} onChange={(e) => setStudent(e.target.value)}><option value="all">{t('filter.allStudents')}</option>{d.students.map((x) => <option key={x.id} value={x.id}>{x.displayName}</option>)}</Select></>;
  return (
    <>
      <PageHeader title={t('nav.progress')} subtitle={t('progress.reviewSubtitle')} actions={<>
        <Button icon={<LuDownload aria-hidden />} disabled={!rows.length} onClick={() => { downloadCsv(`progress_${from}_${to}.csv`, rows.map((p) => ({ date: p.date, student_id: d.students.find((s) => s.id === p.studentId)?.studentCode, student: name(p.studentId), course: p.track, lesson: p.lesson, status: p.status, homework: p.homework, feedback: p.feedback, submitted_by: p.createdByName }))); void logAudit(db, user.id, 'export.progress', 'progress', { rows: rows.length }); }}>{t('reports.export')}</Button>
        <Button variant="primary" icon={<LuPlus aria-hidden />} onClick={() => setForm('new')} disabled={d.students.length === 0}>{t('progress.newEntry')}</Button></>} />
      <Card><div className="form-grid" style={{ marginBottom: 12 }}>
        <Field label={t('reports.from')}>{(id) => <Input id={id} type="date" max={to} value={from} onChange={(e) => setFrom(e.target.value)} />}</Field>
        <Field label={t('reports.to')}>{(id) => <Input id={id} type="date" min={from} max={todayStr()} value={to} onChange={(e) => setTo(e.target.value)} />}</Field></div>
        <div className="grid cols-4" style={{ marginBottom: 16 }}>{counts.map(({ s, n }) => <Stat key={s} label={t(`progress.${s}` as Key)} value={n} />)}</div>
        <Loadable loading={d.loading} error={d.error} onRetry={d.reload}>
          <DataTable caption={t('nav.progress')} rows={rows} columns={columns} filters={filters} searchText={(p) => `${name(p.studentId)} ${p.lesson} ${p.createdByName}`} onRowClick={setForm} empty={<EmptyState title={t('progress.none')} />} />
        </Loadable></Card>
      {form && <ProgressForm open students={d.students} existing={form === 'new' ? undefined : form} onClose={() => setForm(null)} onSaved={d.reload} />}
    </>
  );
}
