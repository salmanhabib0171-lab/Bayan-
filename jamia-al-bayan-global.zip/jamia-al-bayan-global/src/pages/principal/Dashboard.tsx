import { useMemo, useState } from 'react';
import { LuCalendarPlus, LuClipboardPlus, LuGraduationCap, LuUserPlus, LuUsers, LuVideo } from 'react-icons/lu';
import { ProgressForm } from '../../components/ProgressForm';
import { Badge, Button, Card, CardHeader, EmptyState, Loadable, PageHeader, ProgressBadge, Stat } from '../../components/ui';
import { ZoomJoin } from '../../components/ZoomJoin';
import { useAuth } from '../../lib/auth';
import { addDays, browserTimeZone, fmtDate, fmtNum, fmtTime, todayStr, tzLabel } from '../../lib/dates';
import { useCollection } from '../../lib/hooks';
import { Link } from '../../lib/router';
import { limit, orderBy, where } from '../../lib/services';
import { attendanceRate, goalCompletion, needingUpdate } from '../../lib/stats';
import { TRACKS, type Announcement, type ClassSession } from '../../lib/types';
import { useI18n, type Key } from '../../i18n';
import { ClassForm } from '../shared/Classes';
import { StudentForm } from './Students';
import { TeacherForm } from './Teachers';
import { useRangeData } from './useRangeData';

export default function Dashboard() {
  const { t, lang } = useI18n(); const { user } = useAuth(); const tz = browserTimeZone(); const today = todayStr(tz);
  const d = useRangeData(addDays(today, -14), today);
  const classes = useCollection<ClassSession>('classes', [where('startsAt', '>=', `${addDays(today, -1)}T00:00:00.000Z`), where('startsAt', '<=', `${addDays(today, 2)}T00:00:00.000Z`)], [today]);
  const ann = useCollection<Announcement>('announcements', [orderBy('createdAt', 'desc'), limit(3)], []);
  const [modal, setModal] = useState<'student' | 'teacher' | 'class' | 'progress' | null>(null);

  const active = d.students.filter((s) => s.status === 'active');
  const activeTeachers = d.teachers.filter((x) => x.status === 'active');
  const todays = useMemo(() => classes.data.filter((c) => todayStr(tz, new Date(c.startsAt)) === today && c.status !== 'cancelled').sort((a, b) => a.startsAt.localeCompare(b.startsAt)), [classes.data, today, tz]);
  const last7 = d.attendance.filter((a) => a.date >= addDays(today, -7));
  const rate = attendanceRate(last7);
  const pending = needingUpdate(active.map((s) => s.id), d.progress, today, 7);
  const goalRate = goalCompletion(d.goals);
  const byTrack = TRACKS.map((tr) => ({ tr, n: active.filter((s) => s.track === tr).length }));
  const max = Math.max(1, ...byTrack.map((b) => b.n));
  const recent = [...d.progress].sort((a, b) => (b.createdAt ?? b.date).localeCompare(a.createdAt ?? a.date)).slice(0, 6);
  const nameOf = (id: string) => d.students.find((s) => s.id === id)?.displayName ?? '—';
  const idle = activeTeachers.filter((x) => !active.some((s) => s.teacherId === x.id));
  const noLink = todays.filter((c) => !c.zoomUrl);

  return (
    <>
      <PageHeader title={t('principal.welcome', { name: user.displayName })} subtitle={t('principal.subtitle')} />
      <div className="row" role="group" aria-label={t('dash.quick')}>
        <Button variant="primary" icon={<LuUserPlus aria-hidden />} onClick={() => setModal('student')} disabled={activeTeachers.length === 0}>{t('students.add')}</Button>
        <Button icon={<LuUsers aria-hidden />} onClick={() => setModal('teacher')}>{t('teachers.invite')}</Button>
        <Button icon={<LuCalendarPlus aria-hidden />} onClick={() => setModal('class')} disabled={active.length === 0}>{t('class.schedule')}</Button>
        <Button icon={<LuClipboardPlus aria-hidden />} onClick={() => setModal('progress')} disabled={active.length === 0}>{t('progress.newEntry')}</Button>
      </div>
      <Loadable loading={d.loading} error={d.error} onRetry={d.reload} rows={4}>
        <div className="grid cols-4">
          <Stat icon={<LuGraduationCap aria-hidden />} label={t('dash.activeStudents')} value={fmtNum(active.length, lang)} />
          <Stat icon={<LuUsers aria-hidden />} label={t('dash.activeTeachers')} value={fmtNum(activeTeachers.length, lang)} />
          <Stat icon={<LuVideo aria-hidden />} label={t('dash.todayClasses')} value={fmtNum(todays.length, lang)} />
          <Stat label={t('dash.attendance7')} value={rate.value === null ? '—' : `${rate.value}%`} hint={rate.value === null ? t('stats.notEnough') : t('stats.ofSessions', { n: rate.n, d: rate.d })} />
        </div>
        <div className="grid cols-2">
          <Card><CardHeader title={t('dash.pending')} subtitle={t('dash.pendingHint')} />
            <ul className="list">
              <li><span>{t('dash.pendingProgress', { n: pending.length })}</span>{pending.length > 0 && <Link to="/principal/progress" className="small">{t('common.review')}</Link>}</li>
              <li><span>{t('dash.idleTeachers', { n: idle.length })}</span>{idle.length > 0 && <Link to="/principal/teachers" className="small">{t('common.review')}</Link>}</li>
              <li><span>{t('dash.noLink', { n: noLink.length })}</span>{noLink.length > 0 && <Link to="/principal/classes" className="small">{t('common.review')}</Link>}</li>
            </ul>
            {pending.length > 0 && <p className="muted small" style={{ marginTop: 8 }}>{pending.slice(0, 4).map(nameOf).join(' · ')}{pending.length > 4 ? ' …' : ''}</p>}
          </Card>
          <Card><CardHeader title={t('dash.todayClasses')} action={<Link to="/principal/classes" className="small">{t('common.viewAll')}</Link>} />
            <Loadable loading={classes.loading} error={classes.error} onRetry={classes.reload} rows={2}>
              {todays.length === 0 ? <EmptyState title={t('class.none.today')} /> : (
                <ul className="list">{todays.slice(0, 5).map((c) => <li key={c.id}><div><strong>{fmtTime(c.startsAt, lang, tz)}</strong> <span className="muted small">({tzLabel(tz, lang, c.startsAt)})</span> · {c.studentNames.join(', ')}<p className="muted small">{c.teacherName}</p></div><ZoomJoin cls={c} size="sm" /></li>)}</ul>)}
            </Loadable></Card>
          <Card><CardHeader title={t('dash.byTrack')} />
            <div className="bars">{byTrack.map(({ tr, n }) => <div key={tr} className="bar-row"><span>{t(`track.${tr}` as Key)}</span><div className="bar" role="img" aria-label={`${t(`track.${tr}` as Key)}: ${n}`}><i style={{ width: `${(n / max) * 100}%` }} /></div><strong>{fmtNum(n, lang)}</strong></div>)}</div>
            <p className="muted small" style={{ marginTop: 12 }}>{goalRate.value === null ? t('stats.notEnough') : t('stats.goalCompletion', { n: goalRate.n, d: goalRate.d, pct: goalRate.value })}</p></Card>
          <Card><CardHeader title={t('dash.recent')} action={<Link to="/principal/progress" className="small">{t('common.viewAll')}</Link>} />
            {recent.length === 0 ? <EmptyState title={t('progress.none')} /> : (
              <ul className="list">{recent.map((p) => <li key={p.id}><div><strong>{nameOf(p.studentId)}</strong> · {p.lesson}<p className="muted small">{p.createdByName} · {fmtDate(p.date, lang)}</p></div><ProgressBadge status={p.status} /></li>)}</ul>)}</Card>
        </div>
        <Card><CardHeader title={t('nav.announcements')} action={<Link to="/principal/announcements" className="small">{t('common.manage')}</Link>} />
          {ann.data.length === 0 ? <EmptyState title={t('announce.none')} /> : <ul className="list">{ann.data.map((a) => <li key={a.id}><div><strong>{a.title}</strong> <Badge tone="gold">{t(`audience.${a.audience}` as Key)}</Badge></div><span className="muted small">{fmtDate(a.createdAt?.slice(0, 10), lang)}</span></li>)}</ul>}</Card>
      </Loadable>
      {modal === 'student' && <StudentForm existing={d.students} onClose={() => setModal(null)} onSaved={d.reload} />}
      {modal === 'teacher' && <TeacherForm existing={d.teachers} onClose={() => setModal(null)} onSaved={d.reload} />}
      {modal === 'class' && <ClassForm students={d.students} onClose={() => setModal(null)} onSaved={classes.reload} />}
      {modal === 'progress' && <ProgressForm open students={d.students} onClose={() => setModal(null)} onSaved={d.reload} />}
    </>
  );
}
