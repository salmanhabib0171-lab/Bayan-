import { useEffect, useMemo, useState } from 'react';
import { LuGraduationCap, LuLock, LuUserPlus } from 'react-icons/lu';
import { CredentialsDialog, type CredentialInfo } from '../../components/Credentials';
import { StudentDetail } from '../../components/StudentDetail';
import { Avatar, Badge, Button, Card, ConfirmDialog, DataTable, EmptyState, Field, Input, Loadable, Modal, PageHeader, Select, StatusBadge, Textarea, useToast, type Column } from '../../components/ui';
import { useAuth } from '../../lib/auth';
import { logAudit, tzOptions, useStudents, useTeachers } from '../../lib/data';
import { browserTimeZone, fmtDate, todayStr } from '../../lib/dates';
import { ApiError, SERVER_TIME } from '../../lib/services';
import { TRACKS, type AccountStatus, type Lang, type StudentDoc, type StudentPrivate, type Track } from '../../lib/types';
import { useI18n, type Key } from '../../i18n';

export default function StudentsPage({ openNew }: { openNew?: boolean }) {
  const { t, lang } = useI18n(); const students = useStudents(); const teachers = useTeachers();
  const [detail, setDetail] = useState<StudentDoc | null>(null); const [form, setForm] = useState<StudentDoc | 'new' | null>(openNew ? 'new' : null);
  const [track, setTrack] = useState('all'); const [status, setStatus] = useState('active'); const [teacher, setTeacher] = useState('all');
  const rows = useMemo(() => students.data.filter((s) => (track === 'all' || s.track === track) && (status === 'all' || s.status === status) && (teacher === 'all' || s.teacherId === teacher)), [students.data, track, status, teacher]);
  const columns: Column<StudentDoc>[] = [
    { key: 'name', header: t('field.student'), sort: (a, b) => a.displayName.localeCompare(b.displayName), render: (s) => <span className="row"><Avatar name={s.displayName} />{s.displayName}</span> },
    { key: 'id', header: t('field.studentId'), sort: (a, b) => a.studentCode.localeCompare(b.studentCode), render: (s) => s.studentCode },
    { key: 'track', header: t('field.course'), render: (s) => <Badge tone="teal">{t(`track.${s.track}` as Key)}</Badge> },
    { key: 'level', header: t('field.level'), render: (s) => s.level },
    { key: 'teacher', header: t('field.teacher'), sort: (a, b) => a.teacherName.localeCompare(b.teacherName), render: (s) => s.teacherName },
    { key: 'enrolled', header: t('field.enrollmentDate'), sort: (a, b) => a.enrollmentDate.localeCompare(b.enrollmentDate), render: (s) => fmtDate(s.enrollmentDate, lang) },
    { key: 'status', header: t('field.status'), render: (s) => <StatusBadge status={s.status} /> },
  ];
  const filters = <>
    <Select aria-label={t('field.course')} style={{ maxWidth: 160 }} value={track} onChange={(e) => setTrack(e.target.value)}><option value="all">{t('filter.allCourses')}</option>{TRACKS.map((x) => <option key={x} value={x}>{t(`track.${x}` as Key)}</option>)}</Select>
    <Select aria-label={t('field.teacher')} style={{ maxWidth: 200 }} value={teacher} onChange={(e) => setTeacher(e.target.value)}><option value="all">{t('filter.allTeachers')}</option>{teachers.data.map((x) => <option key={x.id} value={x.id}>{x.displayName}</option>)}</Select>
    <Select aria-label={t('field.status')} style={{ maxWidth: 160 }} value={status} onChange={(e) => setStatus(e.target.value)}><option value="all">{t('filter.allStatuses')}</option>{(['active', 'inactive', 'archived'] as const).map((x) => <option key={x} value={x}>{t(`status.${x}` as Key)}</option>)}</Select>
  </>;
  return (
    <>
      <PageHeader title={t('nav.students')} subtitle={t('students.subtitle')} actions={<Button variant="primary" icon={<LuUserPlus aria-hidden />} onClick={() => setForm('new')} disabled={teachers.data.filter((x) => x.status === 'active').length === 0}>{t('students.add')}</Button>} />
      {teachers.data.filter((x) => x.status === 'active').length === 0 && !teachers.loading && <p className="privacy-note">{t('students.needTeacher')}</p>}
      <Card><Loadable loading={students.loading} error={students.error} onRetry={students.reload}>
        <DataTable caption={t('nav.students')} rows={rows} columns={columns} filters={filters} searchText={(s) => `${s.displayName} ${s.studentCode} ${s.teacherName}`} onRowClick={setDetail}
          empty={<EmptyState icon={<LuGraduationCap size={28} />} title={t('students.none')} text={t('students.noneHint')} action={<Button variant="primary" onClick={() => setForm('new')}>{t('students.add')}</Button>} />} />
      </Loadable></Card>
      {detail && <StudentDetail student={detail} onClose={() => setDetail(null)} onEdit={() => { setForm(detail); setDetail(null); }} />}
      {form && <StudentForm student={form === 'new' ? undefined : form} existing={students.data} onClose={() => setForm(null)} onSaved={students.reload} />}
    </>
  );
}

function nextCode(rows: StudentDoc[]): string {
  const n = rows.map((r) => Number(r.studentCode.replace(/\D/g, ''))).filter(Boolean);
  return `S-${(n.length ? Math.max(...n) : 1000) + 1}`;
}

export function StudentForm({ student, existing, onClose, onSaved }: { student?: StudentDoc; existing: StudentDoc[]; onClose: () => void; onSaved: () => void }) {
  const { t } = useI18n(); const { db, admin, user } = useAuth(); const toast = useToast(); const teachers = useTeachers();
  const editing = Boolean(student);
  const [f, setF] = useState({
    code: student?.studentCode ?? nextCode(existing), displayName: student?.displayName ?? '', track: (student?.track ?? 'qaida') as Track, level: student?.level ?? '',
    teacherId: student?.teacherId ?? '', enrollmentDate: student?.enrollmentDate ?? todayStr(), language: (student?.language ?? 'en') as Lang, country: student?.country ?? '',
    timeZone: student?.timeZone ?? browserTimeZone(), goal: '', email: '',
  });
  const [p, setP] = useState({ legalName: '', guardianName: '', guardianPhone: '', guardianEmail: '', address: '', notes: '' });
  const [loadedPrivate, setLoadedPrivate] = useState(!editing);
  const [errors, setErrors] = useState<Record<string, string>>({}); const [busy, setBusy] = useState(false);
  const [creds, setCreds] = useState<CredentialInfo | null>(null); const [confirm, setConfirm] = useState<AccountStatus | 'reset' | null>(null);
  const set = <K extends keyof typeof f>(k: K, v: (typeof f)[K]) => setF((x) => ({ ...x, [k]: v }));
  const activeTeachers = teachers.data.filter((x) => x.status === 'active');
  useEffect(() => { if (!f.teacherId && activeTeachers[0]) set('teacherId', activeTeachers[0].id); }, [activeTeachers.length]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { // Principal-only record, loaded only for the Principal's edit form
    if (!student) return; let on = true;
    db.get<StudentPrivate>('studentPrivate', student.id).then((d) => { if (on && d) setP({ legalName: d.legalName ?? '', guardianName: d.guardianName ?? '', guardianPhone: d.guardianPhone ?? '', guardianEmail: d.guardianEmail ?? '', address: d.address ?? '', notes: d.notes ?? '' }); if (on) setLoadedPrivate(true); }).catch(() => on && setLoadedPrivate(true));
    return () => { on = false; };
  }, [db, student]);

  function validate() {
    const e: Record<string, string> = {};
    if (!/^[A-Za-z0-9][A-Za-z0-9-]{2,19}$/.test(f.code.trim())) e.code = t('validation.code');
    else if (!editing && existing.some((s) => s.studentCode.toLowerCase() === f.code.trim().toLowerCase())) e.code = t('validation.codeTaken');
    if (f.displayName.trim().length < 2) e.displayName = t('validation.required');
    if (!f.teacherId) e.teacherId = t('validation.required');
    if (f.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email)) e.email = t('validation.email');
    if (p.guardianEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(p.guardianEmail)) e.guardianEmail = t('validation.email');
    setErrors(e); return Object.keys(e).length === 0;
  }
  const dupName = !editing && existing.some((s) => s.displayName.trim().toLowerCase() === f.displayName.trim().toLowerCase() && f.displayName.trim());

  async function save() {
    if (!validate()) return; setBusy(true);
    try {
      if (!student) {
        const res = await admin.createUser({ role: 'student', code: f.code.trim(), displayName: f.displayName.trim(), email: f.email.trim(), language: f.language,
          student: { track: f.track, level: f.level.trim(), teacherId: f.teacherId, enrollmentDate: f.enrollmentDate, country: f.country.trim(), timeZone: f.timeZone }, private: p });
        if (f.goal.trim()) await db.add('goals', { studentId: res.uid, teacherId: f.teacherId, title: f.goal.trim(), description: '', status: 'not_started', targetDate: '', createdBy: user.id, createdAt: SERVER_TIME }).catch(() => undefined);
        setCreds({ name: f.displayName.trim(), loginId: res.loginId, password: res.temporaryPassword, email: res.authEmailIsReal });
        toast('ok', t('toast.studentCreated')); onSaved();
      } else {
        const teacherChanged = f.teacherId !== student.teacherId;
        await db.update('students', student.id, { displayName: f.displayName.trim(), track: f.track, level: f.level.trim(), enrollmentDate: f.enrollmentDate, language: f.language, country: f.country.trim(), timeZone: f.timeZone, updatedAt: SERVER_TIME });
        if (f.displayName.trim() !== student.displayName || f.language !== student.language) await admin.updateProfile(student.id, { displayName: f.displayName.trim(), language: f.language });
        if (loadedPrivate) await db.set('studentPrivate', student.id, { ...p, updatedAt: SERVER_TIME }, true);
        if (teacherChanged) await admin.reassign(student.id, f.teacherId);
        await logAudit(db, user.id, 'student.update', student.id, { teacherChanged, trackChanged: f.track !== student.track });
        toast('ok', t('toast.saved')); onSaved(); onClose();
      }
    } catch (x) {
      const code = x instanceof ApiError ? x.code : '';
      if (code === 'code_taken') setErrors({ code: t('validation.codeTaken') });
      else if (code === 'email_taken') setErrors({ email: t('validation.emailTaken') });
      else toast('err', code === 'account_limit_reached' ? t('error.accountLimit') : code === 'network' ? t('error.network') : t('error.save'));
    } finally { setBusy(false); }
  }
  async function changeStatus(s: AccountStatus) {
    if (!student) return;
    try { await admin.setStatus(student.id, s); toast('ok', t('toast.statusChanged')); onSaved(); setConfirm(null); onClose(); } catch { toast('err', t('error.save')); }
  }
  async function reset() {
    if (!student) return;
    try { const r = await admin.resetPassword(student.id); setConfirm(null); setCreds({ name: student.displayName, loginId: student.studentCode, password: r.temporaryPassword, email: false }); }
    catch { toast('err', t('error.save')); }
  }
  const txt = (k: Key, v: string, on: (s: string) => void, o: { max?: number; err?: string; type?: string; hint?: Key } = {}) =>
    <Field label={t(k)} error={o.err} hint={o.hint ? t(o.hint) : undefined}>{(id, d) => <Input id={id} aria-describedby={d} type={o.type ?? 'text'} maxLength={o.max ?? 100} value={v} onChange={(e) => on(e.target.value)} />}</Field>;

  if (creds) return <CredentialsDialog info={creds} onClose={() => { setCreds(null); if (!editing) onClose(); }} />;
  return (
    <Modal open wide onClose={onClose} title={editing ? t('students.edit') : t('students.add')} footer={<>
      {editing && student && <div className="row" style={{ marginInlineEnd: 'auto' }}>
        {student.status === 'active' ? <Button variant="danger" size="sm" onClick={() => setConfirm('inactive')}>{t('students.deactivate')}</Button> : <Button size="sm" onClick={() => setConfirm('active')}>{t('students.reactivate')}</Button>}
        {student.status !== 'archived' && <Button variant="danger" size="sm" onClick={() => setConfirm('archived')}>{t('students.archive')}</Button>}
        <Button size="sm" variant="ghost" onClick={() => setConfirm('reset')}>{t('students.resetPassword')}</Button></div>}
      <Button variant="ghost" onClick={onClose}>{t('common.cancel')}</Button><Button variant="primary" loading={busy} onClick={() => void save()}>{editing ? t('common.save') : t('students.create')}</Button></>}>
      <fieldset className="group"><legend>{t('students.educational')}</legend><div className="form-grid">
        {txt('field.studentId', f.code, (v) => set('code', v.toUpperCase()), { max: 20, err: errors.code, hint: 'students.idHint' })}
        {txt('field.displayName', f.displayName, (v) => set('displayName', v), { max: 80, err: errors.displayName })}
        <Field label={t('field.course')} hint={t('students.courseHint')}>{(id, d) => <Select id={id} aria-describedby={d} value={f.track} onChange={(e) => set('track', e.target.value as Track)}>{TRACKS.map((x) => <option key={x} value={x}>{t(`track.${x}` as Key)}</option>)}</Select>}</Field>
        {txt('field.level', f.level, (v) => set('level', v), { max: 80 })}
        <Field label={t('field.teacher')} error={errors.teacherId}>{(id, d) => <Select id={id} aria-describedby={d} value={f.teacherId} onChange={(e) => set('teacherId', e.target.value)}>{(editing ? teachers.data : activeTeachers).map((x) => <option key={x.id} value={x.id}>{x.displayName} · {x.teacherCode}</option>)}</Select>}</Field>
        <Field label={t('field.enrollmentDate')}>{(id) => <Input id={id} type="date" value={f.enrollmentDate} onChange={(e) => set('enrollmentDate', e.target.value)} />}</Field>
        <Field label={t('field.language')}>{(id) => <Select id={id} value={f.language} onChange={(e) => set('language', e.target.value as Lang)}><option value="en">English</option><option value="bn">বাংলা</option></Select>}</Field>
        {txt('field.country', f.country, (v) => set('country', v), { max: 60 })}
        <Field label={t('field.timeZone')}>{(id) => <Select id={id} value={f.timeZone} onChange={(e) => set('timeZone', e.target.value)}>{tzOptions(f.timeZone, browserTimeZone()).map((z) => <option key={z} value={z}>{z}</option>)}</Select>}</Field>
        {!editing && <div className="full">{txt('students.firstGoal', f.goal, (v) => set('goal', v), { max: 140 })}</div>}
      </div>{dupName && <p className="field-msg">{t('students.dupName')}</p>}</fieldset>
      <fieldset className="group"><legend><LuLock aria-hidden size={14} /> {t('students.privateSection')}</legend>
        <p className="privacy-note" style={{ marginBottom: 12 }}>{t('students.privateNote')}</p>
        <div className="form-grid">
          {txt('private.legalName', p.legalName, (v) => setP({ ...p, legalName: v }))}
          {txt('private.guardianName', p.guardianName, (v) => setP({ ...p, guardianName: v }))}
          {txt('private.guardianPhone', p.guardianPhone, (v) => setP({ ...p, guardianPhone: v }), { max: 30, type: 'tel' })}
          {txt('private.guardianEmail', p.guardianEmail, (v) => setP({ ...p, guardianEmail: v }), { max: 120, type: 'email', err: errors.guardianEmail })}
          <div className="full">{txt('private.address', p.address, (v) => setP({ ...p, address: v }), { max: 200 })}</div>
          {!editing && <div className="full">{txt('students.loginEmail', f.email, (v) => set('email', v), { max: 120, type: 'email', err: errors.email, hint: 'students.loginEmailHint' })}</div>}
          <div className="full"><Field label={t('private.notes')}>{(id) => <Textarea id={id} maxLength={500} value={p.notes} onChange={(e) => setP({ ...p, notes: e.target.value })} />}</Field></div>
        </div></fieldset>
      <ConfirmDialog open={confirm !== null && confirm !== 'reset'} danger={confirm !== 'active'} title={t(`students.confirm.${confirm === 'reset' ? 'inactive' : confirm ?? 'inactive'}.title` as Key)} text={t(`students.confirm.${confirm === 'reset' ? 'inactive' : confirm ?? 'inactive'}.text` as Key)}
        confirmLabel={t('common.confirm')} onClose={() => setConfirm(null)} onConfirm={() => changeStatus(confirm as AccountStatus)} />
      <ConfirmDialog open={confirm === 'reset'} title={t('students.resetPassword')} text={t('students.confirm.reset')} confirmLabel={t('common.confirm')} onClose={() => setConfirm(null)} onConfirm={reset} />
    </Modal>
  );
}
