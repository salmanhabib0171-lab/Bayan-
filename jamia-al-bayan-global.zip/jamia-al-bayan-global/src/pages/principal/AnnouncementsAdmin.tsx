import { useState } from 'react';
import { LuBell, LuPlus } from 'react-icons/lu';
import { Badge, Button, Card, ConfirmDialog, EmptyState, Field, Input, Loadable, Modal, PageHeader, Select, Textarea, useToast } from '../../components/ui';
import { useAuth } from '../../lib/auth';
import { logAudit, useStudents } from '../../lib/data';
import { fmtDateTime } from '../../lib/dates';
import { useCollection } from '../../lib/hooks';
import { SERVER_TIME, limit, orderBy } from '../../lib/services';
import type { Announcement, Audience } from '../../lib/types';
import { useI18n, type Key } from '../../i18n';

export default function AnnouncementsAdmin() {
  const { t, lang } = useI18n(); const { db, user } = useAuth(); const toast = useToast(); const students = useStudents();
  const list = useCollection<Announcement>('announcements', [orderBy('createdAt', 'desc'), limit(100)], []);
  const [open, setOpen] = useState(false); const [del, setDel] = useState<Announcement | null>(null);
  const [f, setF] = useState({ title: '', body: '', audience: 'all' as Audience, target: '' }); const [err, setErr] = useState<Record<string, string>>({}); const [busy, setBusy] = useState(false);
  async function publish() {
    const e: Record<string, string> = {};
    if (f.title.trim().length < 3) e.title = t('validation.titleShort'); if (f.body.trim().length < 3) e.body = t('validation.required');
    if (f.audience === 'student' && !f.target) e.target = t('validation.required');
    setErr(e); if (Object.keys(e).length) return; setBusy(true);
    try {
      const id = await db.add('announcements', { title: f.title.trim(), body: f.body.trim(), audience: f.audience, ...(f.audience === 'student' ? { targetStudentId: f.target } : {}), createdBy: user.id, createdAt: SERVER_TIME });
      await logAudit(db, user.id, 'announcement.create', id, { audience: f.audience }); toast('ok', t('toast.published')); setOpen(false); setF({ title: '', body: '', audience: 'all', target: '' }); list.reload();
    } catch { toast('err', t('error.save')); } finally { setBusy(false); }
  }
  async function remove(a: Announcement) { try { await db.remove('announcements', a.id); await logAudit(db, user.id, 'announcement.delete', a.id); toast('ok', t('toast.deleted')); setDel(null); list.reload(); } catch { toast('err', t('error.save')); } }
  return (
    <>
      <PageHeader title={t('nav.announcements')} subtitle={t('announce.subtitle')} actions={<Button variant="primary" icon={<LuPlus aria-hidden />} onClick={() => setOpen(true)}>{t('announce.new')}</Button>} />
      <Card><Loadable loading={list.loading} error={list.error} onRetry={list.reload}>
        {list.data.length === 0 ? <EmptyState icon={<LuBell size={28} />} title={t('announce.none')} action={<Button variant="primary" onClick={() => setOpen(true)}>{t('announce.new')}</Button>} /> : (
          <ul className="list">{list.data.map((a) => (
            <li key={a.id}><div><strong>{a.title}</strong> <Badge tone="gold">{t(`audience.${a.audience}` as Key)}</Badge>{a.targetStudentId && <Badge>{students.data.find((s) => s.id === a.targetStudentId)?.displayName ?? '—'}</Badge>}
              <p className="muted" style={{ whiteSpace: 'pre-wrap' }}>{a.body}</p><p className="muted small">{fmtDateTime(a.createdAt, lang)}</p></div>
              <Button size="sm" variant="danger" onClick={() => setDel(a)}>{t('common.delete')}</Button></li>))}</ul>)}
      </Loadable></Card>
      <Modal open={open} onClose={() => setOpen(false)} title={t('announce.new')} footer={<><Button variant="ghost" onClick={() => setOpen(false)}>{t('common.cancel')}</Button><Button variant="primary" loading={busy} onClick={() => void publish()}>{t('announce.publish')}</Button></>}>
        <Field label={t('announce.title')} error={err.title} required>{(id, d) => <Input id={id} aria-describedby={d} maxLength={140} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />}</Field>
        <Field label={t('announce.body')} error={err.body} required>{(id, d) => <Textarea id={id} aria-describedby={d} maxLength={2000} value={f.body} onChange={(e) => setF({ ...f, body: e.target.value })} />}</Field>
        <Field label={t('announce.audience')}>{(id) => <Select id={id} value={f.audience} onChange={(e) => setF({ ...f, audience: e.target.value as Audience })}>{(['all', 'teachers', 'students', 'student'] as const).map((a) => <option key={a} value={a}>{t(`audience.${a}` as Key)}</option>)}</Select>}</Field>
        {f.audience === 'student' && <Field label={t('field.student')} error={err.target} required>{(id, d) => <Select id={id} aria-describedby={d} value={f.target} onChange={(e) => setF({ ...f, target: e.target.value })}><option value="">—</option>{students.data.filter((s) => s.status === 'active').map((s) => <option key={s.id} value={s.id}>{s.displayName}</option>)}</Select>}</Field>}
      </Modal>
      <ConfirmDialog open={Boolean(del)} danger title={t('announce.deleteTitle')} text={t('announce.deleteText')} confirmLabel={t('common.delete')} onClose={() => setDel(null)} onConfirm={() => remove(del!)} />
    </>
  );
}
