import { useMemo, useState } from 'react';
import { LuDownload } from 'react-icons/lu';
import { Button, Card, CardHeader, Field, Input, Loadable, PageHeader, Stat } from '../../components/ui';
import { useAuth } from '../../lib/auth';
import { logAudit } from '../../lib/data';
import { addDays, fmtNum, todayStr } from '../../lib/dates';
import { downloadCsv } from '../../lib/download';
import { attendanceRate, goalCompletion, needingUpdate, weeklyAttendance } from '../../lib/stats';
import { PROGRESS_STATUSES, TRACKS } from '../../lib/types';
import { useI18n, type Key } from '../../i18n';
import { useRangeData } from './useRangeData';

export default function Reports() {
  const { t, lang } = useI18n(); const { db, user } = useAuth();
  const [from, setFrom] = useState(addDays(todayStr(), -30)); const [to, setTo] = useState(todayStr());
  const d = useRangeData(from, to);
  const active = d.students.filter((s) => s.status === 'active');
  const att = attendanceRate(d.attendance); const goals = goalCompletion(d.goals); const weeks = weeklyAttendance(d.attendance);
  const pending = needingUpdate(active.map((s) => s.id), d.progress, to, 7);
  const byTrack = TRACKS.map((tr) => ({ tr, n: active.filter((s) => s.track === tr).length }));
  const maxT = Math.max(1, ...byTrack.map((x) => x.n));
  const dist = PROGRESS_STATUSES.map((s) => ({ s, n: d.progress.filter((p) => p.status === s).length }));
  const maxD = Math.max(1, ...dist.map((x) => x.n));
  const byMonth = useMemo(() => { const m = new Map<string, number>(); d.students.forEach((s) => m.set(s.enrollmentDate.slice(0, 7), (m.get(s.enrollmentDate.slice(0, 7)) ?? 0) + 1)); return [...m.entries()].sort(([a], [b]) => a.localeCompare(b)).slice(-12); }, [d.students]);
  const maxM = Math.max(1, ...byMonth.map(([, n]) => n));
  const teacherRows = d.teachers.map((x) => ({ teacher_id: x.teacherCode, teacher: x.displayName, status: x.status, active_students: active.filter((s) => s.teacherId === x.id).length, progress_entries: d.progress.filter((p) => p.teacherId === x.id).length, attendance_records: d.attendance.filter((a) => a.teacherId === x.id).length }));
  const log = (what: string, n: number) => void logAudit(db, user.id, `export.${what}`, what, { rows: n });

  return (
    <>
      <PageHeader title={t('nav.reports')} subtitle={t('reports.subtitle')} />
      <Card><div className="form-grid">
        <Field label={t('reports.from')}>{(id) => <Input id={id} type="date" max={to} value={from} onChange={(e) => setFrom(e.target.value)} />}</Field>
        <Field label={t('reports.to')}>{(id) => <Input id={id} type="date" min={from} max={todayStr()} value={to} onChange={(e) => setTo(e.target.value)} />}</Field></div></Card>
      <Loadable loading={d.loading} error={d.error} onRetry={d.reload} rows={5}>
        <div className="grid cols-4">
          <Stat label={t('dash.activeStudents')} value={fmtNum(active.length, lang)} />
          <Stat label={t('attendance.rate')} value={att.value === null ? '—' : `${att.value}%`} hint={att.value === null ? t('stats.notEnough') : t('stats.ofSessions', { n: att.n, d: att.d })} />
          <Stat label={t('reports.entries')} value={fmtNum(d.progress.length, lang)} />
          <Stat label={t('reports.goalCompletion')} value={goals.value === null ? '—' : `${goals.value}%`} hint={goals.value === null ? t('stats.notEnough') : t('stats.ofGoals', { n: goals.n, d: goals.d })} />
        </div>
        <div className="grid cols-2">
          <Card><CardHeader title={t('dash.byTrack')} /><div className="bars">{byTrack.map(({ tr, n }) => <div key={tr} className="bar-row"><span>{t(`track.${tr}` as Key)}</span><div className="bar"><i style={{ width: `${(n / maxT) * 100}%` }} /></div><strong>{n}</strong></div>)}</div></Card>
          <Card><CardHeader title={t('reports.statusDist')} /><div className="bars">{dist.map(({ s, n }) => <div key={s} className="bar-row"><span>{t(`progress.${s}` as Key)}</span><div className="bar"><i style={{ width: `${(n / maxD) * 100}%` }} /></div><strong>{n}</strong></div>)}</div></Card>
          <Card><CardHeader title={t('reports.enrollTrend')} subtitle={t('reports.enrollTrendHint')} />
            {byMonth.length === 0 ? <p className="muted">{t('common.noResults')}</p> : <div className="spark" role="img" aria-label={t('reports.enrollTrend')}>{byMonth.map(([m, n]) => <i key={m} style={{ height: `${(n / maxM) * 100}%` }} title={`${m}: ${n}`} />)}</div>}</Card>
          <Card><CardHeader title={t('attendance.trend')} subtitle={t('stats.attendanceMethod')} />
            {weeks.length === 0 ? <p className="muted">{t('attendance.none')}</p> : <div className="spark" role="img" aria-label={t('attendance.trend')}>{weeks.map((w) => <i key={w.week} className={w.rate.value === null ? 'empty' : ''} style={{ height: `${w.rate.value ?? 8}%` }} title={`${w.week}: ${w.rate.value === null ? t('stats.notEnoughShort') : `${w.rate.value}%`}`} />)}</div>}</Card>
        </div>
        <Card><CardHeader title={t('reports.methodology')} />
          <ul className="muted small" style={{ margin: 0, paddingInlineStart: 18 }}><li>{t('stats.attendanceMethod')}</li><li>{t('stats.goalMethod')}</li><li>{t('reports.pendingMethod', { n: pending.length })}</li><li>{t('reports.minSample')}</li></ul></Card>
        <Card><CardHeader title={t('reports.exports')} subtitle={t('reports.exportNote')} />
          <div className="row">
            <Button icon={<LuDownload aria-hidden />} onClick={() => { downloadCsv('students.csv', d.students.map((s) => ({ student_id: s.studentCode, name: s.displayName, course: s.track, level: s.level, teacher: s.teacherName, enrolled: s.enrollmentDate, status: s.status }))); log('students', d.students.length); }}>{t('reports.exportStudents')}</Button>
            <Button icon={<LuDownload aria-hidden />} onClick={() => { downloadCsv(`teacher_activity_${from}_${to}.csv`, teacherRows); log('teachers', teacherRows.length); }}>{t('reports.exportTeachers')}</Button>
            <Button icon={<LuDownload aria-hidden />} disabled={!d.attendance.length} onClick={() => { downloadCsv(`attendance_${from}_${to}.csv`, d.attendance.map((a) => ({ date: a.date, student_id: d.students.find((s) => s.id === a.studentId)?.studentCode, status: a.status }))); log('attendance', d.attendance.length); }}>{t('reports.exportAttendance')}</Button>
          </div></Card>
      </Loadable>
    </>
  );
}
