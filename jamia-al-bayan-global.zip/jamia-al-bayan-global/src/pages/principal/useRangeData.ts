import { useCollection } from '../../lib/hooks';
import { where } from '../../lib/services';
import { useStudents, useTeachers } from '../../lib/data';
import type { Attendance, Goal, Progress } from '../../lib/types';

/** Principal-wide, date-filtered educational data (no private/guardian records). */
export function useRangeData(from: string, to: string) {
  const students = useStudents(); const teachers = useTeachers();
  const progress = useCollection<Progress>('progress', [where('date', '>=', from), where('date', '<=', to)], [from, to]);
  const attendance = useCollection<Attendance>('attendance', [where('date', '>=', from), where('date', '<=', to)], [from, to]);
  const goals = useCollection<Goal>('goals', [], []);
  const loading = students.loading || teachers.loading || progress.loading || attendance.loading || goals.loading;
  const error = students.error ?? teachers.error ?? progress.error ?? attendance.error ?? goals.error;
  const reload = () => { students.reload(); teachers.reload(); progress.reload(); attendance.reload(); goals.reload(); };
  return { students: students.data, teachers: teachers.data, progress: progress.data, attendance: attendance.data, goals: goals.data, loading, error, reload };
}
