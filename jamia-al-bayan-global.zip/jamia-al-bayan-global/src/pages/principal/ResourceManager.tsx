import { useState } from 'react';
import { LuBookOpen, LuPlus, LuTriangleAlert } from 'react-icons/lu';
import { Arabic, Badge, Button, Card, DataTable, EmptyState, Field, Input, Loadable, Modal, PageHeader, Segmented, Select, Textarea, useToast, type Column } from '../../components/ui';
import { useAuth } from '../../lib/auth';
import { logAudit, newId } from '../../lib/data';
import { useCollection } from '../../lib/hooks';
import type { ContentStatus, Dua, Lesson } from '../../lib/types';
import { useI18n, type Key } from '../../i18n';
import { DUA_CATEGORIES, DuaCard } from '../shared/Resources';

type Tab = 'lessons' | 'duas';
const STATUS: ContentStatus[] = ['draft', 'in_review', 'published'];
const tone = { draft: 'neutral', in_review: 'amber', published: 'green' } as const;
const LETTERS = ['ا', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز', 'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ي'];

export default function ResourceManager() {
  const { t } = useI18n(); const { db, user } = useAuth(); const toast = useToast();
  const [tab, setTab] = useState<Tab>('lessons'); const [lesson, setLesson] = useState<Lesson | 'new' | null>(null); const [dua, setDua] = useState<Dua | 'new' | null>(null);
  const lessons = useCollection<Lesson>('lessons', [], []); const duas = useCollection<Dua>('duas', [], []);

  async function starter() {
    const base = { titleBn: '', instructionsBn: '', arabicItems: [] as string[], status: 'draft', sourceVerified: false, reviewedBy: '', reviewerName: '', createdBy: user.id };
    const drafts: Record<string, Partial<Lesson> & { title: string; section: Lesson['section']; order: number; instructions: string }> = {
      'starter-letters-1': { title: 'Arabic letters (1–14)', section: 'letters', order: 1, arabicItems: LETTERS.slice(0, 14), instructions: 'Recognise and name each letter.' },
      'starter-letters-2': { title: 'Arabic letters (15–28)', section: 'letters', order: 2, arabicItems: LETTERS.slice(14), instructions: 'Recognise and name each letter.' },
      'starter-harakat-1': { title: 'Short vowels on ب', section: 'harakat', order: 3, arabicItems: ['بَ', 'بِ', 'بُ'], instructions: 'Read each form aloud with your teacher.' },
    };
    try {
      for (const [id, d] of Object.entries(drafts)) await db.set('lessons', id, { ...base, ...d }, true);
      toast('ok', t('resources.starterAdded')); lessons.reload();
    } catch { toast('err', t('error.save')); }
  }
  const lcols: Column<Lesson>[] = [
    { key: 't', header: t('lesson.title'), sort: (a, b) => a.order - b.order, render: (l) => l.title },
    { key: 's', header: t('lesson.section'), render: (l) => t(`lesson.section.${l.section}` as Key) },
    { key: 'st', header: t('field.status'), render: (l) => <Badge tone={tone[l.status]}>{t(`content.${l.status}` as Key)}</Badge> },
  ];
  const dcols: Column<Dua>[] = [
    { key: 't', header: t('dua.title'), sort: (a, b) => a.title.localeCompare(b.title), render: (d) => d.title },
    { key: 'c', header: t('dua.category'), render: (d) => t(`dua.cat.${d.category}` as Key) },
    { key: 'st', header: t('field.status'), render: (d) => <Badge tone={tone[d.status]}>{t(`content.${d.status}` as Key)}</Badge> },
  ];
  return (
    <>
      <PageHeader title={t('nav.resources')} subtitle={t('resources.manageSubtitle')} actions={<Button variant="primary" icon={<LuPlus aria-hidden />} onClick={() => (tab === 'lessons' ? setLesson('new') : setDua('new'))}>{tab === 'lessons' ? t('lesson.add') : t('dua.add')}</Button>} />
      <p className="privacy-note"><LuTriangleAlert aria-hidden size={18} />{t('resources.reviewNotice')}</p>
      <Segmented<Tab> label={t('nav.resources')} value={tab} onChange={setTab} options={[{ value: 'lessons', label: t('resources.qaida') }, { value: 'duas', label: t('resources.duas') }]} />
      <Card>{tab === 'lessons' ? (
        <Loadable loading={lessons.loading} error={lessons.error} onRetry={lessons.reload}>
          <DataTable caption={t('resources.qaida')} rows={lessons.data} columns={lcols} searchText={(l) => l.title} onRowClick={setLesson}
            empty={<EmptyState icon={<LuBookOpen size={28} />} title={t('resources.noLessons')} text={t('resources.starterHint')} action={<Button onClick={() => void starter()}>{t('resources.starter')}</Button>} />} />
        </Loadable>) : (
        <Loadable loading={duas.loading} error={duas.error} onRetry={duas.reload}>
          <DataTable caption={t('resources.duas')} rows={duas.data} columns={dcols} searchText={(d) => d.title} onRowClick={setDua} empty={<EmptyState icon={<LuBookOpen size={28} />} title={t('dua.none')} text={t('dua.manageHint')} />} />
        </Loadable>)}</Card>
      {lesson && <LessonForm lesson={lesson === 'new' ? undefined : lesson} onClose={() => setLesson(null)} onSaved={() => { lessons.reload(); void logAudit(db, user.id, 'lesson.save', typeof lesson === 'object' ? lesson.id : 'new'); }} />}
      {dua && <DuaForm dua={dua === 'new' ? undefined : dua} onClose={() => setDua(null)} onSaved={() => { duas.reload(); void logAudit(db, user.id, 'dua.save', typeof dua === 'object' ? dua.id : 'new'); }} />}
    </>
  );
}

/** Shared review/publish controls: nothing can be published without a named reviewer confirming verification. */
function PublishFields({ status, setStatus, verified, setVerified, reviewer, setReviewer, errors }: { status: ContentStatus; setStatus: (s: ContentStatus) => void; verified: boolean; setVerified: (b: boolean) => void; reviewer: string; setReviewer: (s: string) => void; errors: Record<string, string> }) {
  const { t } = useI18n();
  return (
    <fieldset className="group"><legend>{t('content.reviewTitle')}</legend><div className="stack">
      <Field label={t('field.status')}>{(id) => <Select id={id} value={status} onChange={(e) => setStatus(e.target.value as ContentStatus)}>{STATUS.map((s) => <option key={s} value={s}>{t(`content.${s}` as Key)}</option>)}</Select>}</Field>
      {status === 'published' && <>
        <label className="row"><input type="checkbox" checked={verified} onChange={(e) => setVerified(e.target.checked)} />{t('content.verifiedCheck')}</label>
        <Field label={t('content.reviewer')} error={errors.reviewer || errors.verified} required>{(id, d) => <Input id={id} aria-describedby={d} maxLength={80} value={reviewer} onChange={(e) => setReviewer(e.target.value)} />}</Field></>}
    </div></fieldset>
  );
}

function LessonForm({ lesson, onClose, onSaved }: { lesson?: Lesson; onClose: () => void; onSaved: () => void }) {
  const { t } = useI18n(); const { db, user } = useAuth(); const toast = useToast();
  const [f, setF] = useState({ title: lesson?.title ?? '', titleBn: lesson?.titleBn ?? '', section: lesson?.section ?? 'letters', items: (lesson?.arabicItems ?? []).join(' '), instructions: lesson?.instructions ?? '', instructionsBn: lesson?.instructionsBn ?? '', order: String(lesson?.order ?? 1) });
  const [status, setStatus] = useState<ContentStatus>(lesson?.status ?? 'draft'); const [verified, setVerified] = useState(lesson?.sourceVerified ?? false); const [reviewer, setReviewer] = useState(lesson?.reviewerName ?? '');
  const [errors, setErrors] = useState<Record<string, string>>({}); const [busy, setBusy] = useState(false);
  async function save() {
    const e: Record<string, string> = {};
    if (f.title.trim().length < 3) e.title = t('validation.titleShort');
    if (status === 'published' && (!verified || reviewer.trim().length < 2)) e.reviewer = t('content.needReviewer');
    setErrors(e); if (Object.keys(e).length) return; setBusy(true);
    const data = { title: f.title.trim(), titleBn: f.titleBn.trim(), section: f.section, arabicItems: f.items.split(/\s+/).filter(Boolean), instructions: f.instructions.trim(), instructionsBn: f.instructionsBn.trim(), order: Number(f.order) || 0, status, sourceVerified: status === 'published' && verified, reviewedBy: status === 'published' ? user.id : '', reviewerName: status === 'published' ? reviewer.trim() : '' };
    try { if (lesson) await db.update('lessons', lesson.id, data); else await db.set('lessons', newId(), { ...data, createdBy: user.id }); toast('ok', t('toast.saved')); onSaved(); onClose(); } catch { toast('err', t('error.save')); } finally { setBusy(false); }
  }
  return (
    <Modal open wide onClose={onClose} title={lesson ? t('lesson.edit') : t('lesson.add')} footer={<><Button variant="ghost" onClick={onClose}>{t('common.cancel')}</Button><Button variant="primary" loading={busy} onClick={() => void save()}>{t('common.save')}</Button></>}>
      <div className="form-grid">
        <Field label={t('lesson.title')} error={errors.title} required>{(id, d) => <Input id={id} aria-describedby={d} maxLength={140} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />}</Field>
        <Field label={t('lesson.titleBn')}>{(id) => <Input id={id} maxLength={140} value={f.titleBn} onChange={(e) => setF({ ...f, titleBn: e.target.value })} />}</Field>
        <Field label={t('lesson.section')}>{(id) => <Select id={id} value={f.section} onChange={(e) => setF({ ...f, section: e.target.value as Lesson['section'] })}>{(['letters', 'harakat', 'reading', 'practice'] as const).map((s) => <option key={s} value={s}>{t(`lesson.section.${s}` as Key)}</option>)}</Select>}</Field>
        <Field label={t('lesson.order')}>{(id) => <Input id={id} type="number" min={0} value={f.order} onChange={(e) => setF({ ...f, order: e.target.value })} />}</Field>
        <div className="full"><Field label={t('lesson.items')} hint={t('lesson.itemsHint')}>{(id, d) => <Textarea id={id} aria-describedby={d} dir="rtl" lang="ar" className="arabic" value={f.items} onChange={(e) => setF({ ...f, items: e.target.value })} />}</Field></div>
        <Field label={t('lesson.instructions')}>{(id) => <Textarea id={id} maxLength={600} value={f.instructions} onChange={(e) => setF({ ...f, instructions: e.target.value })} />}</Field>
        <Field label={t('lesson.instructionsBn')}>{(id) => <Textarea id={id} maxLength={600} value={f.instructionsBn} onChange={(e) => setF({ ...f, instructionsBn: e.target.value })} />}</Field>
      </div>
      <PublishFields {...{ status, setStatus, verified, setVerified, reviewer, setReviewer, errors }} />
    </Modal>
  );
}

function DuaForm({ dua, onClose, onSaved }: { dua?: Dua; onClose: () => void; onSaved: () => void }) {
  const { t } = useI18n(); const { db, user } = useAuth(); const toast = useToast();
  const [f, setF] = useState({ title: dua?.title ?? '', category: dua?.category ?? 'daily', arabic: dua?.arabic ?? '', transliteration: dua?.transliteration ?? '', meaningEn: dua?.meaningEn ?? '', meaningBn: dua?.meaningBn ?? '', source: dua?.source ?? '' });
  const [status, setStatus] = useState<ContentStatus>(dua?.status ?? 'draft'); const [verified, setVerified] = useState(dua?.sourceVerified ?? false); const [reviewer, setReviewer] = useState(dua?.reviewerName ?? '');
  const [errors, setErrors] = useState<Record<string, string>>({}); const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  async function save() {
    const e: Record<string, string> = {};
    if (f.title.trim().length < 3) e.title = t('validation.titleShort');
    if (status === 'published') {
      if (!f.arabic.trim() || !f.meaningEn.trim() || !f.meaningBn.trim() || !f.source.trim()) e.reviewer = t('content.needComplete');
      else if (!verified || reviewer.trim().length < 2) e.reviewer = t('content.needReviewer');
    }
    setErrors(e); if (Object.keys(e).length) return; setBusy(true);
    const data = { ...Object.fromEntries(Object.entries(f).map(([k, v]) => [k, v.trim()])), status, sourceVerified: status === 'published' && verified, reviewedBy: status === 'published' ? user.id : '', reviewerName: status === 'published' ? reviewer.trim() : '' };
    try { if (dua) await db.update('duas', dua.id, data); else await db.set('duas', newId(), { ...data, createdBy: user.id }); toast('ok', t('toast.saved')); onSaved(); onClose(); } catch { toast('err', t('error.save')); } finally { setBusy(false); }
  }
  return (
    <Modal open wide onClose={onClose} title={dua ? t('dua.edit') : t('dua.add')} footer={<><Button variant="ghost" onClick={onClose}>{t('common.cancel')}</Button><Button variant="primary" loading={busy} onClick={() => void save()}>{t('common.save')}</Button></>}>
      <div className="form-grid">
        <Field label={t('dua.title')} error={errors.title} required>{(id, d) => <Input id={id} aria-describedby={d} maxLength={140} value={f.title} onChange={set('title')} />}</Field>
        <Field label={t('dua.category')}>{(id) => <Select id={id} value={f.category} onChange={set('category')}>{DUA_CATEGORIES.map((c) => <option key={c} value={c}>{t(`dua.cat.${c}` as Key)}</option>)}</Select>}</Field>
        <div className="full"><Field label={t('dua.arabic')} hint={t('dua.arabicHint')}>{(id, d) => <Textarea id={id} aria-describedby={d} dir="rtl" lang="ar" className="arabic" maxLength={1500} value={f.arabic} onChange={set('arabic')} />}</Field></div>
        <div className="full"><Field label={t('dua.transliteration')}>{(id) => <Textarea id={id} maxLength={1500} value={f.transliteration} onChange={set('transliteration')} />}</Field></div>
        <Field label={t('dua.meaningEn')}>{(id) => <Textarea id={id} maxLength={1000} value={f.meaningEn} onChange={set('meaningEn')} />}</Field>
        <Field label={t('dua.meaningBn')}>{(id) => <Textarea id={id} maxLength={1000} value={f.meaningBn} onChange={set('meaningBn')} />}</Field>
        <div className="full"><Field label={t('dua.source')} hint={t('dua.sourceHint')}>{(id, d) => <Input id={id} aria-describedby={d} maxLength={200} value={f.source} onChange={set('source')} />}</Field></div>
      </div>
      <PublishFields {...{ status, setStatus, verified, setVerified, reviewer, setReviewer, errors }} />
      {(f.arabic || f.meaningEn) && <div><p className="muted small">{t('dua.preview')}</p><DuaCard d={{ ...(dua ?? ({} as Dua)), id: 'preview', ...f, status, sourceVerified: verified, reviewedBy: '', reviewerName: reviewer, createdBy: '' }} /></div>}
      <Arabic className="sr-only">{''}</Arabic>
    </Modal>
  );
}
