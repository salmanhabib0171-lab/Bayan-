import { useMemo, useState } from 'react';
import { LuDownload } from 'react-icons/lu';
import { AttendanceBadge, Card, CardHeader, DataTable, EmptyState, Field, Input, Loadable, PageHeader, Select, Stat, Button, type Column } from '../../components/ui';
import { useAuth } from '../../lib/auth';
import { logAudit } from '../../lib/data';
import { addDays, fmtDate, todayStr } from '../../lib/dates';
import { downloadCsv } from '../../lib/download';
import { attendanceRate, weeklyAttendance } from '../../lib/stats';
import { ATTENDANCE_STATUSES, type Attendance } from '../../lib/types';
import { useI18n, type Key } from '../../i18n';
import { useRangeData } from './useRangeData';

export default function AttendancePage() {
  const { t, lang } = useI18n(); const { db, user } = useAuth();
  const [from, setFrom] = useState(addDays(todayStr(), -30)); const [to, setTo] = useState(todayStr()); const [teacher, setTeacher] = useState('all');
  const d = useRangeData(from, to);
  const rows = useMemo(() => d.attendance.filter((a) => teacher === 'all' || a.teacherId === teacher).sort((a, b) => b.date.localeCompare(a.date)), [d.attendance, teacher]);
  const name = (id: string) => d.students.find((s) => s.id === id)?.displayName ?? '—';
  const overall = attendanceRate(rows); const weeks = weeklyAttendance(rows);
  const perStudent = useMemo(() => d.students.filter((s) => rows.some((r) => r.studentId === s.id)).map((s) => {
    const mine = rows.filter((r) => r.studentId === s.id); const r = attendanceRate(mine);
    return { id: s.id, name: s.displayName, present: mine.filter((x) => x.status === 'present').length, late: mine.filter((x) => x.status === 'late').length, absent: mine.filter((x) => x.status === 'absent').length, excused: mine.filter((x) => x.status === 'excused').length, rate: r };
  }), [d.students, rows]);
  type Row = (typeof perStudent)[number];
  const cols: Column<Row>[] = [
    { key: 'n', header: t('field.student'), sort: (a, b) => a.name.localeCompare(b.name), render: (r) => r.name },
    ...ATTENDANCE_STATUSES.map((s): Column<Row> => ({ key: s, header: t(`attendance.${s}` as Key), sort: (a, b) => a[s] - b[s], render: (r) => r[s] })),
    { key: 'rate', header: t('attendance.rate'), sort: (a, b) => (a.rate.value ?? -1) - (b.rate.value ?? -1), render: (r) => (r.rate.value === null ? <span className="muted">{t('stats.notEnoughShort')}</span> : `${r.rate.value}%`) },
  ];
  const recent: Column<Attendance>[] = [
    { key: 'date', header: t('field.lessonDate'), render: (a) => fmtDate(a.date, lang) }, { key: 's', header: t('field.student'), render: (a) => name(a.studentId) }, { key: 'st', header: t('field.status'), render: (a) => <AttendanceBadge status={a.status} /> },
  ];
  const maxS = Math.max(1, ...weeks.map((w) => w.sessions));
  return (
    <>
      <PageHeader title={t('nav.attendance')} subtitle={t('attendance.subtitle')} actions={<Button icon={<LuDownload aria-hidden />} disabled={!rows.length} onClick={() => { downloadCsv(`attendance_${from}_${to}.csv`, rows.map((a) => ({ date: a.date, student_id: d.students.find((s) => s.id === a.studentId)?.studentCode, student: name(a.studentId), status: a.status }))); void logAudit(db, user.id, 'export.attendance', 'attendance', { rows: rows.length }); }}>{t('reports.export')}</Button>} />
      <Card><div className="form-grid">
        <Field label={t('reports.from')}>{(id) => <Input id={id} type="date" max={to} value={from} onChange={(e) => setFrom(e.target.value)} />}</Field>
        <Field label={t('reports.to')}>{(id) => <Input id={id} type="date" min={from} max={todayStr()} value={to} onChange={(e) => setTo(e.target.value)} />}</Field>
        <Field label={t('field.teacher')}>{(id) => <Select id={id} value={teacher} onChange={(e) => setTeacher(e.target.value)}><option value="all">{t('filter.allTeachers')}</option>{d.teachers.map((x) => <option key={x.id} value={x.id}>{x.displayName}</option>)}</Select>}</Field></div></Card>
      <Loadable loading={d.loading} error={d.error} onRetry={d.reload} rows={4}>
        <div className="grid cols-4">
          <Stat label={t('attendance.rate')} value={overall.value === null ? '—' : `${overall.value}%`} hint={overall.value === null ? t('stats.notEnough') : t('stats.ofSessions', { n: overall.n, d: overall.d })} />
          {(['present', 'late', 'absent'] as const).map((s) => <Stat key={s} label={t(`attendance.${s}` as Key)} value={rows.filter((r) => r.status === s).length} />)}
        </div>
        <Card><CardHeader title={t('attendance.trend')} subtitle={t('stats.attendanceMethod')} />
          {weeks.length === 0 ? <EmptyState title={t('attendance.none')} /> : <>
            <div className="spark" role="img" aria-label={t('attendance.trend')}>{weeks.map((w) => <i key={w.week} className={w.rate.value === null ? 'empty' : ''} style={{ height: `${w.rate.value ?? (w.sessions / maxS) * 20 + 4}%` }} title={`${w.week}: ${w.rate.value === null ? t('stats.notEnoughShort') : `${w.rate.value}%`}`} />)}</div>
            <p className="muted small">{weeks[0].week} → {weeks.at(-1)!.week}</p></>}</Card>
        <Card><CardHeader title={t('attendance.byStudent')} />
          <DataTable caption={t('attendance.byStudent')} rows={perStudent} columns={cols} searchText={(r) => r.name} pageSize={8} empty={<EmptyState title={t('attendance.none')} />} /></Card>
        <Card><CardHeader title={t('attendance.history')} />
          <DataTable caption={t('attendance.history')} rows={rows} columns={recent} searchText={(a) => name(a.studentId)} pageSize={8} empty={<EmptyState title={t('attendance.none')} />} /></Card>
      </Loadable>
    </>
  );
}
