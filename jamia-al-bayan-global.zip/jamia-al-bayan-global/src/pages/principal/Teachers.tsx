import { useMemo, useState } from 'react';
import { LuUserRoundPlus, LuUsers } from 'react-icons/lu';
import { CredentialsDialog, type CredentialInfo } from '../../components/Credentials';
import { Avatar, Badge, Button, Card, ConfirmDialog, DataTable, EmptyState, Field, Input, Loadable, Modal, PageHeader, Select, StatusBadge, useToast, type Column } from '../../components/ui';
import { useAuth } from '../../lib/auth';
import { useStudents, useTeachers } from '../../lib/data';
import { addDays, fmtDate, todayStr } from '../../lib/dates';
import { useCollection } from '../../lib/hooks';
import { ApiError, where } from '../../lib/services';
import type { AccountStatus, Attendance, ClassSession, Lang, Progress, TeacherDoc } from '../../lib/types';
import { useI18n, type Key } from '../../i18n';

const RESP = ['attendance', 'progress', 'messaging', 'scheduling'] as const;

export default function TeachersPage() {
  const { t, lang } = useI18n(); const teachers = useTeachers(); const students = useStudents();
  const since = addDays(todayStr(), -30);
  const progress = useCollection<Progress>('progress', [where('date', '>=', since)], [since]);
  const attendance = useCollection<Attendance>('attendance', [where('date', '>=', since)], [since]);
  const classes = useCollection<ClassSession>('classes', [where('startsAt', '>=', `${since}T00:00:00.000Z`)], [since]);
  const [form, setForm] = useState(false); const [open, setOpen] = useState<TeacherDoc | null>(null);

  const stats = useMemo(() => new Map(teachers.data.map((x) => {
    const mine = students.data.filter((s) => s.teacherId === x.id && s.status === 'active');
    const entries = progress.data.filter((p) => p.teacherId === x.id);
    return [x.id, { students: mine.length, entries: entries.length, att: attendance.data.filter((a) => a.teacherId === x.id).length, classes: classes.data.filter((c) => c.teacherId === x.id && c.status === 'completed').length, last: entries.map((p) => p.date).sort().at(-1) }];
  })), [teachers.data, students.data, progress.data, attendance.data, classes.data]);

  const columns: Column<TeacherDoc>[] = [
    { key: 'name', header: t('field.teacher'), sort: (a, b) => a.displayName.localeCompare(b.displayName), render: (x) => <span className="row"><Avatar name={x.displayName} />{x.displayName}</span> },
    { key: 'id', header: t('field.teacherId'), render: (x) => x.teacherCode },
    { key: 'students', header: t('teachers.students'), sort: (a, b) => (stats.get(a.id)?.students ?? 0) - (stats.get(b.id)?.students ?? 0), render: (x) => stats.get(x.id)?.students ?? 0 },
    { key: 'entries', header: t('teachers.entries30'), sort: (a, b) => (stats.get(a.id)?.entries ?? 0) - (stats.get(b.id)?.entries ?? 0), render: (x) => stats.get(x.id)?.entries ?? 0 },
    { key: 'last', header: t('teachers.lastEntry'), render: (x) => stats.get(x.id)?.last ? fmtDate(stats.get(x.id)!.last, lang) : '—' },
    { key: 'status', header: t('field.status'), render: (x) => <StatusBadge status={x.status} /> },
  ];
  return (
    <>
      <PageHeader title={t('nav.teachers')} subtitle={t('teachers.subtitle')} actions={<Button variant="primary" icon={<LuUserRoundPlus aria-hidden />} onClick={() => setForm(true)}>{t('teachers.invite')}</Button>} />
      <Card><Loadable loading={teachers.loading} error={teachers.error} onRetry={teachers.reload}>
        <DataTable caption={t('nav.teachers')} rows={teachers.data} columns={columns} searchText={(x) => `${x.displayName} ${x.teacherCode}`} onRowClick={setOpen}
          empty={<EmptyState icon={<LuUsers size={28} />} title={t('teachers.none')} text={t('teachers.noneHint')} action={<Button variant="primary" onClick={() => setForm(true)}>{t('teachers.invite')}</Button>} />} />
        <p className="muted small" style={{ marginTop: 10 }}>{t('teachers.workloadNote')}</p>
      </Loadable></Card>
      {form && <TeacherForm existing={teachers.data} onClose={() => setForm(false)} onSaved={teachers.reload} />}
      {open && <TeacherDetail teacher={open} stats={stats.get(open.id)} onClose={() => setOpen(null)} onChanged={() => { teachers.reload(); students.reload(); }} />}
    </>
  );
}

export function TeacherForm({ existing, onClose, onSaved }: { existing: TeacherDoc[]; onClose: () => void; onSaved: () => void }) {
  const { t } = useI18n(); const { admin } = useAuth(); const toast = useToast();
  const next = `T-${String(Math.max(0, ...existing.map((x) => Number(x.teacherCode.replace(/\D/g, '')) || 0)) + 1).padStart(3, '0')}`;
  const [f, setF] = useState({ code: next, name: '', email: '', language: 'en' as Lang }); const [resp, setResp] = useState<string[]>([...RESP]);
  const [errors, setErrors] = useState<Record<string, string>>({}); const [busy, setBusy] = useState(false); const [creds, setCreds] = useState<CredentialInfo | null>(null);
  async function save() {
    const e: Record<string, string> = {};
    if (!/^[A-Za-z0-9][A-Za-z0-9-]{2,19}$/.test(f.code.trim())) e.code = t('validation.code');
    else if (existing.some((x) => x.teacherCode.toLowerCase() === f.code.trim().toLowerCase())) e.code = t('validation.codeTaken');
    if (f.name.trim().length < 2) e.name = t('validation.required');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email)) e.email = t('validation.email');
    setErrors(e); if (Object.keys(e).length) return;
    setBusy(true);
    try {
      const r = await admin.createUser({ role: 'teacher', code: f.code.trim(), displayName: f.name.trim(), email: f.email.trim(), language: f.language, teacher: { responsibilities: resp } });
      setCreds({ name: f.name.trim(), loginId: r.loginId, password: r.temporaryPassword, email: true }); toast('ok', t('toast.teacherCreated')); onSaved();
    } catch (x) {
      const c = x instanceof ApiError ? x.code : '';
      if (c === 'code_taken') setErrors({ code: t('validation.codeTaken') }); else if (c === 'email_taken') setErrors({ email: t('validation.emailTaken') });
      else toast('err', c === 'network' ? t('error.network') : t('error.save'));
    } finally { setBusy(false); }
  }
  if (creds) return <CredentialsDialog info={creds} onClose={onClose} />;
  return (
    <Modal open onClose={onClose} title={t('teachers.invite')} footer={<><Button variant="ghost" onClick={onClose}>{t('common.cancel')}</Button><Button variant="primary" loading={busy} onClick={() => void save()}>{t('teachers.create')}</Button></>}>
      <Field label={t('field.teacherId')} error={errors.code} required>{(id, d) => <Input id={id} aria-describedby={d} maxLength={20} value={f.code} onChange={(e) => setF({ ...f, code: e.target.value.toUpperCase() })} />}</Field>
      <Field label={t('field.displayName')} error={errors.name} required>{(id, d) => <Input id={id} aria-describedby={d} maxLength={80} value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />}</Field>
      <Field label={t('field.email')} error={errors.email} hint={t('teachers.emailHint')} required>{(id, d) => <Input id={id} aria-describedby={d} type="email" autoComplete="off" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />}</Field>
      <Field label={t('field.language')}>{(id) => <Select id={id} value={f.language} onChange={(e) => setF({ ...f, language: e.target.value as Lang })}><option value="en">English</option><option value="bn">বাংলা</option></Select>}</Field>
      <fieldset className="group"><legend>{t('teachers.responsibilities')}</legend><div className="stack">
        {RESP.map((r) => <label key={r} className="row"><input type="checkbox" checked={resp.includes(r)} onChange={(e) => setResp(e.target.checked ? [...resp, r] : resp.filter((x) => x !== r))} />{t(`resp.${r}` as Key)}</label>)}</div></fieldset>
    </Modal>
  );
}

function TeacherDetail({ teacher, stats, onClose, onChanged }: { teacher: TeacherDoc; stats?: { students: number; entries: number; att: number; classes: number }; onClose: () => void; onChanged: () => void }) {
  const { t } = useI18n(); const { db, admin } = useAuth(); const toast = useToast(); const students = useStudents();
  const mine = students.data.filter((s) => s.teacherId === teacher.id && s.status === 'active');
  const others = students.data.filter((s) => s.teacherId !== teacher.id && s.status === 'active');
  const [pick, setPick] = useState(''); const [confirm, setConfirm] = useState<AccountStatus | null>(null); const [resp, setResp] = useState(teacher.responsibilities); const [creds, setCreds] = useState<CredentialInfo | null>(null);
  async function setStatus(s: AccountStatus) { try { await admin.setStatus(teacher.id, s); toast('ok', t('toast.statusChanged')); onChanged(); onClose(); } catch { toast('err', t('error.save')); } }
  async function assign() {
    try { await admin.reassign(pick, teacher.id); toast('ok', t('toast.assigned')); setPick(''); students.reload(); onChanged(); } catch { toast('err', t('error.save')); }
  }
  async function saveResp(next: string[]) { setResp(next); try { await db.update('teachers', teacher.id, { responsibilities: next }); toast('ok', t('toast.saved')); } catch { toast('err', t('error.save')); } }
  if (creds) return <CredentialsDialog info={creds} onClose={() => setCreds(null)} />;
  return (
    <Modal open wide onClose={onClose} title={teacher.displayName} footer={<>
      <div className="row" style={{ marginInlineEnd: 'auto' }}>
        {teacher.status === 'active' ? <Button variant="danger" size="sm" onClick={() => setConfirm('inactive')}>{t('teachers.deactivate')}</Button> : <Button size="sm" onClick={() => setConfirm('active')}>{t('students.reactivate')}</Button>}
        <Button size="sm" variant="ghost" onClick={async () => { try { const r = await admin.resetPassword(teacher.id); setCreds({ name: teacher.displayName, loginId: teacher.teacherCode, password: r.temporaryPassword, email: true }); } catch { toast('err', t('error.save')); } }}>{t('students.resetPassword')}</Button></div>
      <Button onClick={onClose}>{t('common.close')}</Button></>}>
      <div className="row"><Badge>{teacher.teacherCode}</Badge><StatusBadge status={teacher.status} /></div>
      <div className="grid cols-3">
        <div className="stat"><small className="muted">{t('teachers.students')}</small><strong>{stats?.students ?? 0}</strong></div>
        <div className="stat"><small className="muted">{t('teachers.entries30')}</small><strong>{stats?.entries ?? 0}</strong></div>
        <div className="stat"><small className="muted">{t('teachers.classes30')}</small><strong>{stats?.classes ?? 0}</strong></div>
      </div>
      <fieldset className="group"><legend>{t('teachers.responsibilities')}</legend><div className="row">
        {RESP.map((r) => <label key={r} className="row"><input type="checkbox" checked={resp.includes(r)} onChange={(e) => void saveResp(e.target.checked ? [...resp, r] : resp.filter((x) => x !== r))} />{t(`resp.${r}` as Key)}</label>)}</div></fieldset>
      <h3>{t('teachers.assignedStudents')}</h3>
      {mine.length === 0 ? <p className="muted">{t('teacher.noStudents')}</p> : <ul className="list">{mine.map((s) => <li key={s.id}><span>{s.displayName}</span><Badge tone="teal">{t(`track.${s.track}` as Key)}</Badge></li>)}</ul>}
      {teacher.status === 'active' && others.length > 0 && <div className="row" style={{ flexWrap: 'nowrap' }}>
        <Select aria-label={t('teachers.assignStudent')} value={pick} onChange={(e) => setPick(e.target.value)}><option value="">{t('teachers.assignStudent')}</option>{others.map((s) => <option key={s.id} value={s.id}>{s.displayName} ({s.teacherName})</option>)}</Select>
        <Button disabled={!pick} onClick={() => void assign()}>{t('teachers.assign')}</Button></div>}
      <ConfirmDialog open={confirm !== null} danger={confirm !== 'active'} title={t(`teachers.confirm.${confirm ?? 'inactive'}.title` as Key)} text={t('teachers.confirm.text', { n: mine.length })} confirmLabel={t('common.confirm')} onClose={() => setConfirm(null)} onConfirm={() => setStatus(confirm!)} />
    </Modal>
  );
}
