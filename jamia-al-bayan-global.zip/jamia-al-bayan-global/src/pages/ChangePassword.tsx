import { useState, type FormEvent } from 'react';
import { LogoMark } from '../components/Brand';
import { Button, Card, Field, Input, useToast } from '../components/ui';
import { useAuth } from '../lib/auth';
import { AuthError } from '../lib/services';
import { useI18n } from '../i18n';

/** Shown instead of the app until a temporary password has been replaced. */
export function ChangePassword({ forced = false, onDone }: { forced?: boolean; onDone?: () => void }) {
  const { t } = useI18n(); const { auth, db, user, refreshUser, signOut } = useAuth(); const toast = useToast();
  const [cur, setCur] = useState(''); const [next, setNext] = useState(''); const [again, setAgain] = useState('');
  const [err, setErr] = useState<string | null>(null); const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault(); setErr(null);
    if (next.length < 10) return setErr(t('password.short'));
    if (next !== again) return setErr(t('password.mismatch'));
    if (next === cur) return setErr(t('password.same'));
    setBusy(true);
    try {
      await auth.changePassword(cur, next);
      if (user.mustChangePassword) await db.update('users', user.id, { mustChangePassword: false });
      await refreshUser(); toast('ok', t('password.changed')); setCur(''); setNext(''); setAgain(''); onDone?.();
    } catch (x) { setErr(x instanceof AuthError && x.code === 'wrong_password' ? t('password.wrong') : x instanceof AuthError && x.code === 'weak_password' ? t('password.short') : t('error.generic')); }
    finally { setBusy(false); }
  }
  const form = (
    <form className="stack" onSubmit={submit} noValidate>
      <Field label={t('password.current')} required>{(id) => <Input id={id} type="password" autoComplete="current-password" value={cur} onChange={(e) => setCur(e.target.value)} />}</Field>
      <Field label={t('password.new')} hint={t('password.rule')} required>{(id, d) => <Input id={id} aria-describedby={d} type="password" autoComplete="new-password" value={next} onChange={(e) => setNext(e.target.value)} />}</Field>
      <Field label={t('password.confirm')} required error={err ?? undefined}>{(id, d) => <Input id={id} aria-describedby={d} type="password" autoComplete="new-password" value={again} onChange={(e) => setAgain(e.target.value)} />}</Field>
      <Button type="submit" variant="primary" loading={busy}>{t('password.save')}</Button>
    </form>
  );
  if (!forced) return form;
  return (
    <div className="login"><div className="login-card"><LogoMark size={96} />
      <Card className="login-panel"><h1 style={{ fontSize: '1.25rem' }}>{t('password.forcedTitle')}</h1><p className="muted">{t('password.forcedText')}</p>{form}
        <button className="row-link small" onClick={() => void signOut()}>{t('auth.signOut')}</button></Card></div></div>
  );
}
