import { lazy, Suspense } from 'react';
import { LogoMark } from './components/Brand';
import { Shell, homeFor } from './components/Shell';
import { Button, Spinner, ToastProvider } from './components/ui';
import { AuthProvider, useSession } from './lib/auth';
import { navigate, RouterProvider, usePath } from './lib/router';
import { I18nProvider, useI18n } from './i18n';
import { ChangePassword } from './pages/ChangePassword';
import { Login } from './pages/Login';
import type { Role } from './lib/types';

const PrincipalApp = lazy(() => import('./pages/principal'));
const TeacherApp = lazy(() => import('./pages/teacher'));
const StudentApp = lazy(() => import('./pages/student'));
const Settings = lazy(() => import('./pages/shared/Settings'));

function Gate() {
  const { phase, user } = useSession(); const { t } = useI18n(); const path = usePath();
  if (phase === 'loading') return <div className="login"><div className="login-card"><LogoMark size={96} /><Spinner /></div></div>;
  if (phase === 'error') return (
    <div className="login"><div className="login-card"><LogoMark size={96} /><h1>{t('error.setupTitle')}</h1><p className="muted">{t('error.setupText')}</p>
      <Button onClick={() => location.reload()}>{t('common.retry')}</Button></div></div>);
  if (phase === 'out' || !user) { if (path !== '/') navigate('/', true); return <Login />; }
  if (user.mustChangePassword) return <ChangePassword forced />;

  const role: Role = user.role;
  const home = homeFor(role);
  // UI-level routing guard. The real enforcement is Firestore Security Rules + server-side checks.
  const allowed = path === '/settings' || path === `/${role}` || path.startsWith(`/${role}/`);
  if (!allowed) { navigate(home, true); return null; }
  return (
    <Shell>
      <Suspense fallback={<Spinner />}>
        {path === '/settings' ? <Settings /> : role === 'principal' ? <PrincipalApp path={path} /> : role === 'teacher' ? <TeacherApp path={path} /> : <StudentApp path={path} />}
      </Suspense>
    </Shell>
  );
}

export default function App() {
  return (
    <I18nProvider><ToastProvider><RouterProvider><AuthProvider><Gate /></AuthProvider></RouterProvider></ToastProvider></I18nProvider>
  );
}
