#!/usr/bin/env node
/**
 * One-time, offline creation of the FIRST Principal.
 * Run on a trusted computer — this is deliberately NOT a web endpoint, so nobody on the internet can call it.
 *
 *   FIREBASE_PROJECT_ID=... FIREBASE_CLIENT_EMAIL=... FIREBASE_PRIVATE_KEY="..." \
 *   PRINCIPAL_EMAIL=principal@yourdomain.org PRINCIPAL_NAME="Principal Name" \
 *   npm run bootstrap:principal
 *
 * It refuses to run if a Principal already exists. A strong random password is printed once;
 * change it at first sign-in.
 */
import { randomInt } from 'node:crypto';
import { cert, initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { FieldValue, getFirestore } from 'firebase-admin/firestore';

const { FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, PRINCIPAL_EMAIL, PRINCIPAL_NAME } = process.env;
const key = process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n');
if (!FIREBASE_PROJECT_ID || !FIREBASE_CLIENT_EMAIL || !key || !PRINCIPAL_EMAIL || !PRINCIPAL_NAME) {
  console.error('Missing FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY, PRINCIPAL_EMAIL or PRINCIPAL_NAME.');
  process.exit(1);
}
initializeApp({ credential: cert({ projectId: FIREBASE_PROJECT_ID, clientEmail: FIREBASE_CLIENT_EMAIL, privateKey: key }) });
const db = getFirestore();

const existing = await db.collection('users').where('role', '==', 'principal').limit(1).get();
if (!existing.empty || (await db.doc('config/bootstrap').get()).exists) {
  console.error('A Principal already exists. Refusing to create another from the command line.');
  process.exit(2);
}
const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
const password = Array.from({ length: 16 }, () => chars[randomInt(chars.length)]).join('');

const user = await getAuth().createUser({ email: PRINCIPAL_EMAIL, password, displayName: PRINCIPAL_NAME });
await getAuth().setCustomUserClaims(user.uid, { role: 'principal' });
const now = FieldValue.serverTimestamp();
await db.doc(`users/${user.uid}`).set({ role: 'principal', status: 'active', displayName: PRINCIPAL_NAME, code: 'PRINCIPAL', language: 'en', mustChangePassword: true, createdAt: now });
await db.doc('config/bootstrap').set({ completedAt: now, uid: user.uid });
await db.doc('config/settings').set({ defaultLanguage: 'en', academyName: 'Jamia Al-Bayan Global', updatedAt: now }, { merge: true });
console.log('\nPrincipal created.\n  Email   :', PRINCIPAL_EMAIL, '\n  Password:', password, '\n\nSign in, then change the password immediately. This password is not stored anywhere.\n');
