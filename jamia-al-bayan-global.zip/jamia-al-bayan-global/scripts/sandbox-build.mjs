#!/usr/bin/env node
/**
 * Offline verification build (NOT used for production — Netlify runs `npm run build` with Vite).
 * Bundles the app with esbuild in explicit DEMO mode so the UI can be exercised without Firebase or network access.
 *   ESBUILD_PATH=/path/to/esbuild-module NODE_PATH=/path/to/node_modules node scripts/sandbox-build.mjs
 */
import { cpSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const esbuild = require(process.env.ESBUILD_PATH ?? 'esbuild');
const out = 'dist-sandbox';
rmSync(out, { recursive: true, force: true }); mkdirSync(out, { recursive: true });
cpSync('public', out, { recursive: true });
const env = { VITE_DEMO_MODE: 'true', VITE_LOGIN_EMAIL_DOMAIN: 'login.jamia-albayan.example' };
await esbuild.build({
  entryPoints: ['src/main.tsx'], outdir: `${out}/assets`, bundle: true, splitting: true, format: 'esm', jsx: 'automatic', minify: true, target: 'es2020',
  entryNames: 'app-[hash]', chunkNames: 'chunk-[hash]', nodePaths: (process.env.NODE_PATH ?? '').split(':').filter(Boolean),
  external: ['firebase/*'], loader: { '.png': 'file' },
  define: { 'import.meta.env.VITE_DEMO_MODE': JSON.stringify(process.env.SANDBOX_DEMO ?? 'true'), 'import.meta.env.VITE_LOGIN_EMAIL_DOMAIN': `"${env.VITE_LOGIN_EMAIL_DOMAIN}"`, 'import.meta.env.PROD': 'true',
    'import.meta.env.VITE_FIREBASE_API_KEY': 'undefined', 'import.meta.env.VITE_FIREBASE_AUTH_DOMAIN': 'undefined', 'import.meta.env.VITE_FIREBASE_PROJECT_ID': 'undefined',
    'import.meta.env.VITE_FIREBASE_STORAGE_BUCKET': 'undefined', 'import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID': 'undefined', 'import.meta.env.VITE_FIREBASE_APP_ID': 'undefined' },
});
const { readdirSync } = await import('node:fs');
const files = readdirSync(`${out}/assets`);
const js = files.find((f) => f.startsWith('app-') && f.endsWith('.js')); const css = files.find((f) => f.startsWith('app-') && f.endsWith('.css'));
let html = readFileSync('index.html', 'utf8').replace('<script type="module" src="/src/main.tsx"></script>', `<link rel="stylesheet" href="/assets/${css}"><script type="module" src="/assets/${js}"></script>`);
writeFileSync(`${out}/index.html`, html);
console.log('sandbox build ok →', out, files.length, 'files');
