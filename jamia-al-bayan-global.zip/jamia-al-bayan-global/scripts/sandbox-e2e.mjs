#!/usr/bin/env node
// Browser checks against the offline DEMO build (dist-sandbox). They exercise UI routing/isolation, not Firebase rules.
import { createServer } from 'node:http';
import { createReadStream, existsSync, statSync } from 'node:fs';
import { createRequire } from 'node:module';
import { extname, join } from 'node:path';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLAYWRIGHT_PATH ?? 'playwright');
const root = 'dist-sandbox'; const SHOTS = process.env.SHOTS ?? '/tmp/shots';
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webmanifest': 'application/manifest+json', '.json': 'application/json' };
const server = createServer((req, res) => { // mimics Netlify: real files first, else SPA fallback to index.html
  const p = join(root, decodeURIComponent(new URL(req.url, 'http://x').pathname));
  const file = existsSync(p) && statSync(p).isFile() ? p : join(root, 'index.html');
  res.setHeader('content-type', mime[extname(file)] ?? 'application/octet-stream'); createReadStream(file).pipe(res);
}).listen(0);
const base = `http://localhost:${server.address().port}`;
const results = []; const check = (name, ok, info = '') => { results.push({ name, ok }); console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${info ? ' — ' + info : ''}`); };

const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH, args: ['--no-sandbox'] });
async function session(viewport = { width: 1280, height: 860 }) {
  const ctx = await browser.newContext({ viewport, serviceWorkers: 'block' }); const page = await ctx.newPage();
  const errors = []; page.on('pageerror', (e) => errors.push(String(e))); page.on('console', (m) => { if (m.type() === 'error' && !/ERR_NAME_NOT_RESOLVED|ERR_INTERNET_DISCONNECTED/.test(m.text())) errors.push(m.text()); }); // Google Fonts are unreachable offline
  return { ctx, page, errors };
}
const settle = (page) => page.waitForFunction(() => !document.querySelector('.skeleton, .spinner'), null, { timeout: 8000 }).catch(() => {});
const go = (page, path) => page.evaluate((p) => { history.pushState(null, '', p); dispatchEvent(new PopStateEvent('popstate')); }, path); // client-side navigation keeps the in-memory demo session
async function login(page, id) {
  await page.goto(base + '/'); await page.getByLabel(/Email or academy ID|ইমেইল বা একাডেমি আইডি/).fill(id);
  await page.getByLabel(/^Password|^পাসওয়ার্ড/).fill('demo'); await page.getByRole('button', { name: /Sign in|সাইন ইন/ }).last().click();
  await page.waitForSelector('main#main, .hero', { timeout: 8000 });
}

// 1. login page + wrong password
{ const { page, errors } = await session(); await page.goto(base + '/'); await page.waitForSelector('.login-panel');
  check('login screen renders with official logo', await page.locator('img.logo').first().evaluate((i) => i.complete && i.naturalWidth > 0));
  await page.screenshot({ path: `${SHOTS}/01-login.png` });
  await page.getByLabel(/Email or academy ID/).fill('PRINCIPAL'); await page.getByLabel(/^Password/).fill('wrong'); await page.getByRole('button', { name: 'Sign in' }).last().click();
  await page.waitForSelector('[role=alert]'); check('wrong password shows an error and stays signed out', (await page.locator('[role=alert]').first().innerText()).includes('not correct'));
  check('no public registration option on login', (await page.getByText(/sign up|register|create account/i).count()) === 0);
  check('login: no console errors', errors.length === 0, errors.join(' | ')); }

// 2. principal: every route renders, no console errors, private data only inside private tab
{ const { page, errors } = await session(); await login(page, 'PRINCIPAL'); await page.waitForSelector('.stat'); await page.screenshot({ path: `${SHOTS}/02-principal-dashboard.png`, fullPage: true });
  check('principal lands on dashboard', page.url().endsWith('/principal'));
  for (const r of ['students', 'teachers', 'classes', 'attendance', 'progress', 'resources', 'announcements', 'reports', 'audit']) {
    await page.evaluate((p) => { history.pushState(null, '', p); dispatchEvent(new PopStateEvent('popstate')); }, `/principal/${r}`);
    await page.waitForSelector('h1', { timeout: 5000 }); await page.waitForTimeout(250);
    const bad = await page.locator('text=We could not load this').count(); check(`principal /${r} renders without load errors`, bad === 0);
    if (['students', 'reports', 'attendance'].includes(r)) await page.screenshot({ path: `${SHOTS}/03-principal-${r}.png`, fullPage: true }); }
  await page.evaluate(() => { history.pushState(null, '', '/principal/students'); dispatchEvent(new PopStateEvent('popstate')); }); await page.waitForSelector('table');
  check('student list does not leak guardian names', (await page.content()).includes('Demo Guardian') === false);
  await page.getByRole('button', { name: 'Aisha R.' }).first().click(); await page.getByRole('button', { name: 'Private details' }).click();
  await page.waitForSelector('text=Visible to the Principal only.'); check('principal can open the private details tab', (await page.content()).includes('Demo Guardian 1'));
  await page.screenshot({ path: `${SHOTS}/04-principal-private.png` });
  check('principal: no console errors', errors.length === 0, errors.slice(0, 3).join(' | ')); }

// 3. teacher: sees only assigned students, never private data, cannot reach principal routes
{ const { page, errors } = await session(); await login(page, 'T-001'); await page.waitForSelector('.stat'); await settle(page); await page.screenshot({ path: `${SHOTS}/05-teacher-dashboard.png`, fullPage: true });
  await go(page, '/teacher/students'); await page.waitForSelector('table'); const html = await page.content();
  check('teacher sees assigned students', html.includes('Aisha R.') && html.includes('Yusuf A.') && html.includes('Zainab K.'));
  check('teacher does NOT see another teacher\'s students', !html.includes('Omar H.') && !html.includes('Ibrahim T.'));
  check('teacher page contains no guardian/private data', !/Demo Guardian|Demo Legal|guardian\d@/.test(html));
  await go(page, '/principal/teachers'); await page.waitForTimeout(500); check('teacher is redirected away from principal routes', page.url().endsWith('/teacher'));
  check('teacher nav has no admin links', (await page.locator('.sidebar a[href^="/principal"]').count()) === 0);
  await go(page, '/teacher'); await page.getByRole('button', { name: 'New progress entry' }).first().click(); await page.waitForSelector('[role=dialog]');
  await page.screenshot({ path: `${SHOTS}/06-teacher-progress-form.png` });
  check('teacher: no console errors', errors.length === 0, errors.slice(0, 3).join(' | ')); }

// 4. student: simple dashboard, no admin, no other students, refresh on nested route works
{ const { page, errors } = await session(); await login(page, 'S-1001'); await page.waitForSelector('.hero'); await settle(page); await page.screenshot({ path: `${SHOTS}/07-student-home.png`, fullPage: true });
  const html = await page.content(); check('student home shows own name and course', html.includes('Aisha R.') && html.includes('Qaida'));
  check('student sees no other student names', !/Yusuf A\.|Zainab K\.|Omar H\./.test(html));
  check('student join button present (Zoom)', (await page.locator('a[href^="https://zoom.us"], button:has-text("Join")').count()) > 0);
  for (const p of ['/principal', '/teacher/students', '/principal/students']) { await go(page, p); await page.waitForTimeout(400); check(`student blocked from ${p}`, page.url().endsWith('/student')); }
  await go(page, '/student/resources'); await page.waitForSelector('h1'); check('nested route renders after client navigation', (await page.locator('h1').innerText()).length > 0);
  await go(page, '/student/messages'); await page.waitForSelector('.thread', { timeout: 5000 }); check('student sees their conversation with the assigned teacher', (await page.content()).includes('Well done today'));
  check('student: no console errors', errors.length === 0, errors.slice(0, 3).join(' | ')); }

// 5. bilingual
{ const { page } = await session(); await page.goto(base + '/'); await page.getByRole('button', { name: 'বাংলা' }).click();
  check('Bangla login labels', (await page.content()).includes('ইমেইল বা একাডেমি আইডি')); check('html lang switches to bn', (await page.locator('html').getAttribute('lang')) === 'bn');
  await login(page, 'S-1001'); await page.waitForSelector('.hero h1'); check('Bangla student dashboard', (await page.content()).includes('আসসালামু আলাইকুম'));
  await go(page, '/student/resources'); await page.waitForSelector('.letters', { timeout: 4000 }).catch(() => {});
  const ar = page.locator('.arabic').first(); if (await ar.count()) check('Arabic content is RTL inside LTR layout', (await ar.getAttribute('dir')) === 'rtl' && (await page.locator('body').evaluate((b) => getComputedStyle(b).direction)) === 'ltr');
  await page.screenshot({ path: `${SHOTS}/08-student-resources-bn.png`, fullPage: true }); }

// 6. mobile
{ const { page, errors } = await session({ width: 390, height: 844 }); await login(page, 'S-1001'); await page.waitForSelector('.tabbar');
  check('mobile bottom navigation visible', await page.locator('.tabbar').isVisible()); check('mobile sidebar hidden', !(await page.locator('.sidebar').isVisible()));
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth > innerWidth + 1); check('no horizontal page overflow on 390px', !overflow);
  await settle(page); await page.screenshot({ path: `${SHOTS}/09-mobile-student.png` });
  const p2 = (await session({ width: 390, height: 844 })); await login(p2.page, 'PRINCIPAL'); await go(p2.page, '/principal/students'); await p2.page.waitForSelector('table');
  check('mobile principal list: no horizontal overflow', !(await p2.page.evaluate(() => document.documentElement.scrollWidth > innerWidth + 1))); await settle(p2.page); await p2.page.screenshot({ path: `${SHOTS}/10-mobile-principal-students.png` }); }

// 6b. refresh/direct load of a nested URL must serve the app (Netlify SPA fallback), not a 404
{ const { page } = await session(); const r = await page.goto(base + '/teacher/classes'); await page.waitForSelector('.login-panel');
  check('direct load of nested route returns the app (HTTP 200, login shown)', r.status() === 200); }

// 7. PWA assets reachable
{ const { page } = await session(); const m = await page.goto(base + '/manifest.webmanifest'); const j = await m.json();
  check('manifest has name, icons, standalone display', j.name === 'Jamia Al-Bayan Global' && j.display === 'standalone' && j.icons.length >= 4);
  for (const i of j.icons) { const r = await page.goto(base + i.src); if (!r.ok()) check(`icon ${i.src}`, false); } check('all manifest icons load', true); }

await browser.close(); server.close();
const failed = results.filter((r) => !r.ok); console.log(`\n${results.length - failed.length}/${results.length} checks passed`); process.exit(failed.length ? 1 : 0);
