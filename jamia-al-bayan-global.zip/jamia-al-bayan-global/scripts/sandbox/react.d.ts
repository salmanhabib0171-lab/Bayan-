// SANDBOX-ONLY minimal typings (the real @types/react is used by `npm run typecheck` after `npm install`).
declare module 'react' {
  export type ReactNode = any; export type FormEvent = any; export type ButtonHTMLAttributes<T> = any; export type InputHTMLAttributes<T> = any;
  export type SelectHTMLAttributes<T> = any; export type TextareaHTMLAttributes<T> = any; export type AnchorHTMLAttributes<T> = any;
  export type Context<T> = { Provider: any; _t?: T }; export type LazyExoticComponent<T> = any;
  export function useState<T>(i: T | (() => T)): [T, (v: T | ((p: T) => T)) => void];
  export function useRef<T>(i: T): { current: T };
  export function useRef<T>(i: T | null): { current: T | null };
  export function useMemo<T>(f: () => T, d: readonly unknown[]): T;
  export function useCallback<T>(f: T, d: readonly unknown[]): T;
  export function useEffect(f: () => void | (() => void), d?: readonly unknown[]): void;
  export function useContext<T>(c: Context<T>): T;
  export function createContext<T>(d: T): Context<T>;
  export function useId(): string;
  export function lazy<T>(f: () => Promise<{ default: T }>): any;
  export const Suspense: any; export const StrictMode: any;
}
declare module 'react/jsx-runtime' { export namespace JSX { interface IntrinsicElements { [k: string]: any } interface Element {} interface ElementChildrenAttribute { children: {} } interface IntrinsicAttributes { key?: any } } export const jsx: any, jsxs: any, Fragment: any; }
declare module 'react-dom/client' { export const createRoot: any; }
declare namespace React { type LazyExoticComponent<T> = any; namespace JSX { type Element = any } }
declare module 'react-icons/lu' { export const LuBell, LuBookOpen, LuBookmark, LuBookmarkCheck, LuCalendarCheck, LuCalendarDays, LuCalendarPlus, LuChartColumn, LuCheck, LuChevronLeft, LuChevronRight, LuCircleAlert, LuClipboardList, LuClipboardPlus, LuCopy, LuDownload, LuEllipsis, LuGraduationCap, LuHouse, LuInbox, LuLock, LuLogOut, LuMessageCircle, LuPlus, LuScrollText, LuSearch, LuSend, LuSettings, LuTarget, LuTriangleAlert, LuUserPlus, LuUserRoundCog, LuUserRoundPlus, LuUsers, LuVideo, LuX: any; }
declare module '*.css' { const c: string; export default c }
