declare module 'node:crypto' { export function randomInt(n: number): number }
declare module 'node:test' { const t: any; export default t; export const test: any, describe: any, it: any }
declare module 'node:assert/strict' { const a: any; export default a }
declare const process: { env: Record<string, string | undefined> };
declare module 'node:child_process' { export function execSync(c: string, o?: any): any }
declare module 'node:fs' { export function readFileSync(p: string, e?: string): any; export function existsSync(p: string): boolean }
