// SANDBOX-ONLY type shims so the project can be type-checked where the firebase SDKs cannot be installed.
// The real build (npm install) uses the real SDK types; this file is not part of tsconfig.json.
declare module 'firebase/app' { export const initializeApp: any; }
declare module 'firebase/auth' { export const EmailAuthProvider: any, getAuth: any, onAuthStateChanged: any, reauthenticateWithCredential: any, sendPasswordResetEmail: any, signInWithEmailAndPassword: any, signOut: any, updatePassword: any; }
declare module 'firebase/firestore' { export const addDoc: any, collection: any, deleteDoc: any, doc: any, getDoc: any, getDocs: any, initializeFirestore: any, limit: any, memoryLocalCache: any, onSnapshot: any, orderBy: any, query: any, serverTimestamp: any, setDoc: any, updateDoc: any, where: any, writeBatch: any; export class Timestamp { toDate(): Date } export type DocumentData = { [k: string]: any } }
declare module 'firebase-admin/app' { export const cert: any, getApps: any, initializeApp: any; }
declare module 'firebase-admin/auth' { export const getAuth: any; }
declare module 'firebase-admin/firestore' { export const getFirestore: any; export const FieldValue: any; }
declare namespace FirebaseFirestore { type DocumentReference = any }
declare module 'react-icons/lu';
