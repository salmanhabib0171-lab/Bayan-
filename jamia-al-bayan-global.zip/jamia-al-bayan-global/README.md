# Jamia Al-Bayan Global — Academy Management PWA

React + TypeScript + Vite progressive web app for Android, iOS, Windows and macOS (browser or "Add to Home Screen"), backed by Firebase Authentication + Cloud Firestore, hosted on Netlify. Interface in **English and Bangla**. The supplied academy logo is used unmodified (only cropped/resized for icons).

> **Quran** is a course-track label only. There is no Quran reader, text, or audio anywhere in this project (a test enforces it).

## Status — what is verified and what is not

Be clear-eyed before inviting real students. This project was written in an environment **without network access**, so the real toolchain could not be installed.

| Area | Status |
|---|---|
| Unit tests (`npm test`): validation, time-zone maths, statistics, translation parity (EN/BN), config/PWA/CSP/secret-scan, **static** checks of the security rules, function-authorisation checks | ✅ **44/44 pass** (run in the build sandbox) |
| Type check of app + server code | ⚠️ Passed with *reduced strength* (offline stand-in typings for React/Firebase). Run `npm run typecheck` after `npm install` — fix anything the real types reveal |
| App behaviour in a real browser (headless Chrome, **explicit demo mode**, in-memory data): login, role routing, teacher/student isolation in the UI, Principal-only private tab, EN/BN switch, RTL Arabic, mobile layout, nested-route reload, manifest/icons | ✅ **43/43 checks pass** (`scripts/sandbox-e2e.mjs`) |
| `npm run build` (Vite production build) | ❌ **Not run** — Vite could not be installed offline. A functionally equivalent esbuild bundle was built and tested instead |
| Firebase Auth/Firestore integration against a real project | ❌ **Not run** — code written to the Firebase v11 / Admin v12 APIs and reviewed by hand, never executed against live Firebase |
| Firestore Security Rules behaviour | ❌ **Not run** — `test/rules/firestore.rules.test.ts` is written and must be run with the emulator (`npm run test:rules`) before go-live |
| Netlify Functions | ❌ Not executed; authorisation logic is unit-checked statically |
| ESLint | ❌ Config provided, not run |

**Do not put real student data into the system until `npm run build`, `npm run typecheck`, `npm test` and `npm run test:rules` all pass on your machine and you have tried the role checklist below on the deployed site.**

## Architecture & privacy model

* **Roles** (`principal`, `teacher`, `student`) are Firebase **custom claims** set only by the server (Admin SDK). Account *status* is read from `users/{uid}` inside the rules, so a deactivated account is refused immediately even while its token is still valid (and tokens are revoked on deactivation).
* **No self-registration.** Accounts are created by the Principal through Netlify Functions that verify the Firebase ID token, require an *active* Principal, validate input, and never trust a client-sent role. The **first Principal** is created offline with `npm run bootstrap:principal` (no public endpoint exists).
* **Private data is a separate collection**: `studentPrivate/{id}` (legal name, guardian details, address, contact) is readable/writable **only by the Principal** in `firestore.rules`. The educational profile (`students/{id}`) contains no private fields.
* Teachers read only records whose `teacherId` is theirs; students only records whose `studentId` is theirs; no student directory exists. Reassigning a student (server function) moves ownership of the history to the new teacher and removes the old teacher immediately.
* Student-visible feedback and teacher-internal notes are separate collections (`progress` vs `progressNotes`).
* Messaging is teacher ↔ assigned student only (no student-to-student). *The rules also allow the Principal to read conversations for safeguarding; there is no UI for it — remove that rule line if you do not want it.*
* Audit log (`audit`) is append-only. Exports contain educational data only and are themselves audited.
* Private records are never written to browser storage: Firestore uses an in-memory cache, the service worker caches only static public files, and sign-out clears local state (only the language preference remains).
* Religious content (Qaida lessons, duas) can be **published only** with a verified-source confirmation and a named reviewer (enforced in the rules). The app ships **no dua text**; only an empty, unpublished placeholder exists in demo data.

Student/teacher sign-in IDs are mapped to a never-deliverable address (`<id>@login.jamia-albayan.example`). Students without a real email cannot self-recover a password: the Principal issues a new temporary password (shown once, never stored).

## Local development

```bash
npm install
cp .env.example .env.local        # fill the VITE_FIREBASE_* values (Firebase console > Project settings > Your apps)
npm run dev                       # http://localhost:5173
```

Try the UI **without Firebase** (sample data, nothing saved, red/gold banner shown):
`VITE_DEMO_MODE=true npm run dev` → sign in as `PRINCIPAL`, `T-001` or `S-1001`, password `demo`. **Never set this on the production site.**

## Setup (summary — full Bangla guide: `README_BN.md`)

1. **Firebase project** → Authentication → enable **Email/Password**. Add your Netlify domain under *Authentication → Settings → Authorized domains*.
2. **Firestore** → create database (production mode). Deploy rules + indexes:
   `npx firebase-tools login && npx firebase-tools deploy --only firestore:rules,firestore:indexes --project <id>`
3. **Service account** (Project settings → Service accounts → Generate key). Keep the file **outside** the repo.
4. **First Principal** (on your own computer, once):
   ```bash
   FIREBASE_PROJECT_ID=... FIREBASE_CLIENT_EMAIL=... FIREBASE_PRIVATE_KEY="$(cat key.json | jq -r .private_key)" \
   PRINCIPAL_EMAIL=you@yourdomain.org PRINCIPAL_NAME="Principal" npm run bootstrap:principal
   ```
   Note the printed password, then delete the key file if you will not need it.
5. **Netlify** → Add site from Git. Build command `npm run build`, publish directory `dist` (already in `netlify.toml`, which also provides the SPA fallback, security headers and CSP). Set environment variables from `.env.example` (`VITE_*` for the browser; `FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL`, `FIREBASE_PRIVATE_KEY` (paste with `\n` line breaks), `LOGIN_EMAIL_DOMAIN`, `ALLOWED_ORIGINS`, `MAX_ACCOUNTS` as **server-side** variables; never prefix secrets with `VITE_`). Redeploy.
6. Sign in as the Principal → change password → add a teacher → add a student → test.

## Pre-launch checklist

- [ ] `npm run build`, `npm run typecheck`, `npm test`, `npm run test:rules`, `npm run lint` all pass.
- [ ] Deployed site: reloading `/teacher/classes` shows the app (not a 404).
- [ ] Role test with real accounts: a teacher cannot open Principal pages or see another teacher's students; a student cannot see anyone else; guardian details appear only for the Principal; a deactivated account is refused.
- [ ] Firebase **Usage and billing**: stay on the Spark (free) plan or set a budget alert; review current free quotas for Firestore reads/writes and Authentication. Rules use `get()` lookups, which count as reads. The app loads whole collections client-side, which is fine for hundreds of records but will need server-side pagination at larger scale.
- [ ] Netlify: review the current free-tier limits for builds and function invocations; `MAX_ACCOUNTS` caps account creation.
- [ ] Customise the Firebase password-reset email template; decide data-retention rules with the academy.
- [ ] Have the academy's religious reviewer approve every dua/lesson before publishing.

## Project layout

```
firestore.rules / firestore.indexes.json   security rules and indexes
netlify/functions/                         create-user, update-user-status, update-user-profile, reset-password, reassign-teacher
scripts/bootstrap-principal.mjs            one-time offline Principal creation
src/lib                                    data layer (Firebase + explicit demo), auth, hooks, dates, stats
src/i18n                                   en.ts (keys) / bn.ts (must match; tested)
src/pages/{principal,teacher,student,shared}
test/unit                                  runnable offline        test/rules   needs the emulator
scripts/sandbox*                           offline verification tooling (not used in production)
```

## Not built (documented future work)

Dark theme · push/SMS/email notifications (reminders are in-app only) · file attachments · group-class scheduling UI (rules already allow up to 10 students from the Principal) · Principal conversation-oversight screen · server-side pagination · native Capacitor shells (the project is structured so `npx cap add android ios` can wrap `dist`; store distribution is a separate step, and Netlify does not produce APK/IPA files).
