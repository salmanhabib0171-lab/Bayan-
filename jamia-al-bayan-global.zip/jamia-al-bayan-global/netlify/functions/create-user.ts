import { auth, audit, db, FieldValue, handle, HttpError } from './_lib/admin';
import { generateTempPassword, loginEmailFor, validateCreateUser } from './_lib/validate';

export default async (req: Request) =>
  handle(req, async (principalUid, body) => {
    const v = validateCreateUser(body);
    if (!v.ok) throw Object.assign(new HttpError(400, 'validation_failed'), { fields: v.errors });
    const d = v.data;
    const firestore = db();

    // Safeguard against runaway account creation.
    const max = Number(process.env.MAX_ACCOUNTS ?? 300);
    const count = (await firestore.collection('users').count().get()).data().count;
    if (count >= max) throw new HttpError(409, 'account_limit_reached');

    if (d.role === 'student') {
      const t = await firestore.doc(`teachers/${d.student!.teacherId}`).get();
      if (!t.exists || t.data()?.status !== 'active') throw new HttpError(400, 'teacher_not_active');
    }

    const domain = process.env.LOGIN_EMAIL_DOMAIN ?? 'login.jamia-albayan.example';
    const authEmail = d.email || loginEmailFor(d.code, domain);
    const password = generateTempPassword();

    // Unique academy ID: creating the registry document fails if the code is already taken.
    const codeRef = firestore.doc(`codes/${d.role}-${d.code}`);
    try { await codeRef.create({ role: d.role, createdAt: FieldValue.serverTimestamp() }); }
    catch { throw new HttpError(409, 'code_taken'); }

    let uid = '';
    try {
      const user = await auth().createUser({ email: authEmail, password, displayName: d.displayName, emailVerified: false });
      uid = user.uid;
      await auth().setCustomUserClaims(uid, { role: d.role });
      const now = FieldValue.serverTimestamp();
      const batch = firestore.batch();
      batch.set(codeRef, { role: d.role, uid, createdAt: now });
      batch.set(firestore.doc(`users/${uid}`), {
        role: d.role, status: 'active', displayName: d.displayName, code: d.code, language: d.language,
        mustChangePassword: true, createdAt: now,
      });
      if (d.role === 'student') {
        const s = d.student!;
        const teacher = await firestore.doc(`teachers/${s.teacherId}`).get();
        batch.set(firestore.doc(`students/${uid}`), {
          studentCode: d.code, displayName: d.displayName, track: s.track, level: s.level, teacherId: s.teacherId,
          teacherName: teacher.data()?.displayName ?? '', enrollmentDate: s.enrollmentDate, language: d.language,
          country: s.country, timeZone: s.timeZone, status: 'active', createdAt: now, updatedAt: now,
        });
        batch.set(firestore.doc(`studentPrivate/${uid}`), { ...d.private, loginContact: d.email, updatedAt: now });
      } else {
        batch.set(firestore.doc(`teachers/${uid}`), {
          teacherCode: d.code, displayName: d.displayName, language: d.language, status: 'active',
          responsibilities: d.teacher!.responsibilities, createdAt: now, updatedAt: now,
        });
      }
      await batch.commit();
      await audit(principalUid, `${d.role}.create`, uid, { code: d.code });
    } catch (e) {
      // Roll back so a half-created account can never exist.
      if (uid) await auth().deleteUser(uid).catch(() => undefined);
      await codeRef.delete().catch(() => undefined);
      const code = (e as { code?: string }).code;
      if (code === 'auth/email-already-exists') throw new HttpError(409, 'email_taken');
      if (e instanceof HttpError) throw e;
      throw new HttpError(500, 'create_failed');
    }
    // The temporary password is returned ONCE to the Principal and is never stored or logged.
    return { uid, loginId: d.code, authEmailIsReal: Boolean(d.email), temporaryPassword: password };
  });
