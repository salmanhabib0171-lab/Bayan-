import { auth, audit, db, FieldValue, handle, HttpError } from './_lib/admin';
import { LANGS } from './_lib/validate';

// Keeps the sign-in profile (users/{uid}) in step with the student/teacher record when the Principal edits a name or language.
export default async (req: Request) =>
  handle(req, async (principalUid, body) => {
    const uid = typeof body?.uid === 'string' ? body.uid : '';
    const displayName = typeof body?.displayName === 'string' ? body.displayName.trim().slice(0, 80) : '';
    const language = (LANGS as readonly string[]).includes(body?.language) ? (body.language as string) : '';
    if (!uid || (displayName.length < 2 && !language)) throw new HttpError(400, 'validation_failed');
    const ref = db().doc(`users/${uid}`);
    const snap = await ref.get();
    if (!snap.exists) throw new HttpError(404, 'not_found');
    if (snap.data()!.role === 'principal') throw new HttpError(403, 'cannot_change_principal');
    const patch: Record<string, unknown> = { updatedAt: FieldValue.serverTimestamp() };
    if (displayName.length >= 2) { patch.displayName = displayName; await auth().updateUser(uid, { displayName }); }
    if (language) patch.language = language;
    await ref.update(patch);
    await audit(principalUid, 'user.profile.update', uid);
    return { ok: true };
  });
