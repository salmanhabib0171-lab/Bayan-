import { auth, audit, db, FieldValue, handle, HttpError } from './_lib/admin';
import { isStatus } from './_lib/validate';

export default async (req: Request) =>
  handle(req, async (principalUid, body) => {
    const uid = typeof body?.uid === 'string' ? body.uid : '';
    if (!uid || !isStatus(body?.status)) throw new HttpError(400, 'validation_failed');
    if (uid === principalUid) throw new HttpError(400, 'cannot_change_self');
    const firestore = db();
    const ref = firestore.doc(`users/${uid}`);
    const snap = await ref.get();
    if (!snap.exists) throw new HttpError(404, 'not_found');
    const role = snap.data()!.role as string;
    if (role === 'principal') throw new HttpError(403, 'cannot_change_principal');

    const status = body.status as 'active' | 'inactive' | 'archived';
    await auth().updateUser(uid, { disabled: status !== 'active' });
    if (status !== 'active') await auth().revokeRefreshTokens(uid); // kills existing sessions
    const now = FieldValue.serverTimestamp();
    const batch = firestore.batch();
    batch.update(ref, { status, updatedAt: now });
    batch.update(firestore.doc(`${role === 'teacher' ? 'teachers' : 'students'}/${uid}`), { status, updatedAt: now });
    await batch.commit(); // academic history is untouched
    await audit(principalUid, `${role}.status.${status}`, uid);
    return { ok: true };
  });
