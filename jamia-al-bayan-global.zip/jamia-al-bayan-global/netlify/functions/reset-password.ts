import { auth, audit, db, FieldValue, handle, HttpError } from './_lib/admin';
import { generateTempPassword } from './_lib/validate';

export default async (req: Request) =>
  handle(req, async (principalUid, body) => {
    const uid = typeof body?.uid === 'string' ? body.uid : '';
    if (!uid) throw new HttpError(400, 'validation_failed');
    const ref = db().doc(`users/${uid}`);
    const snap = await ref.get();
    if (!snap.exists) throw new HttpError(404, 'not_found');
    if (snap.data()!.role === 'principal') throw new HttpError(403, 'cannot_change_principal');
    const password = generateTempPassword();
    await auth().updateUser(uid, { password });
    await auth().revokeRefreshTokens(uid);
    await ref.update({ mustChangePassword: true, updatedAt: FieldValue.serverTimestamp() });
    await audit(principalUid, 'user.password.reset', uid);
    return { temporaryPassword: password };
  });
