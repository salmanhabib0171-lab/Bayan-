// Server-only. Credentials come from Netlify environment variables, never from the browser bundle.
import { cert, getApps, initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { originAllowed } from './validate';

export { FieldValue };

function init() {
  if (getApps().length) return;
  const projectId = process.env.FIREBASE_PROJECT_ID;
  const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
  const privateKey = process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n');
  if (!projectId || !clientEmail || !privateKey) throw new HttpError(500, 'server_not_configured');
  initializeApp({ credential: cert({ projectId, clientEmail, privateKey }) });
}

export const db = () => { init(); return getFirestore(); };
export const auth = () => { init(); return getAuth(); };

export class HttpError extends Error {
  constructor(public status: number, public code: string) { super(code); }
}

export const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json', 'cache-control': 'no-store' } });

// Best-effort per-instance rate limit (serverless instances are ephemeral; Firestore rules + auth are the real guard).
const hits = new Map<string, number[]>();
function rateLimit(key: string, max = 30, windowMs = 60_000) {
  const now = Date.now();
  const arr = (hits.get(key) ?? []).filter((t) => now - t < windowMs);
  if (arr.length >= max) throw new HttpError(429, 'rate_limited');
  arr.push(now); hits.set(key, arr);
}

/** Verifies the Firebase ID token, checks it is not revoked, and requires an ACTIVE Principal. */
export async function requirePrincipal(req: Request): Promise<{ uid: string }> {
  const allowed = (process.env.ALLOWED_ORIGINS ?? process.env.URL ?? '').split(',').map((s) => s.trim()).filter(Boolean);
  if (!originAllowed(req.headers.get('origin'), allowed)) throw new HttpError(403, 'origin_not_allowed');
  if (req.method !== 'POST') throw new HttpError(405, 'method_not_allowed');
  const header = req.headers.get('authorization') ?? '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!token) throw new HttpError(401, 'missing_token');
  let decoded;
  try { decoded = await auth().verifyIdToken(token, true); } catch { throw new HttpError(401, 'invalid_token'); }
  // Never trust a client-supplied role: only the server-set claim AND the server-held user record count.
  if (decoded.role !== 'principal') throw new HttpError(403, 'forbidden');
  const snap = await db().doc(`users/${decoded.uid}`).get();
  if (!snap.exists || snap.data()?.role !== 'principal' || snap.data()?.status !== 'active') throw new HttpError(403, 'forbidden');
  rateLimit(decoded.uid);
  return { uid: decoded.uid };
}

export async function audit(actorId: string, action: string, targetId: string, meta: Record<string, string | number | boolean> = {}) {
  // Metadata must never contain personal details or credentials.
  await db().collection('audit').add({ actorId, action, targetId, meta, createdAt: FieldValue.serverTimestamp() });
}

export async function handle(req: Request, fn: (principalUid: string, body: any) => Promise<unknown>): Promise<Response> {
  try {
    const { uid } = await requirePrincipal(req);
    let body: unknown;
    try { body = await req.json(); } catch { throw new HttpError(400, 'invalid_json'); }
    return json(200, await fn(uid, body));
  } catch (e) {
    if (e instanceof HttpError) return json(e.status, { error: e.code, fields: (e as { fields?: string[] }).fields });
    console.error('function_error', (e as Error)?.name); // name only — never log payloads
    return json(500, { error: 'internal_error' });
  }
}
