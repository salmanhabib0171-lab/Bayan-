// Pure validation helpers — no I/O, unit-tested in test/unit/validate.test.ts.
import { randomInt } from 'node:crypto';

export type Role = 'student' | 'teacher';
export const TRACKS = ['qaida', 'ampara', 'quran'] as const;
export const LANGS = ['en', 'bn'] as const;
export const STATUSES = ['active', 'inactive', 'archived'] as const;

const CODE_RE = /^[A-Z0-9][A-Z0-9-]{2,19}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const TZ_RE = /^[A-Za-z_]+(?:\/[A-Za-z0-9_+-]+){0,2}$/;

export interface CreateUserInput {
  role: Role;
  code: string;
  displayName: string;
  email: string; // '' => login-ID-only account
  language: 'en' | 'bn';
  student?: { track: (typeof TRACKS)[number]; level: string; teacherId: string; enrollmentDate: string; country: string; timeZone: string };
  teacher?: { responsibilities: string[] };
  private?: { legalName: string; guardianName: string; guardianPhone: string; guardianEmail: string; address: string; notes: string };
}

const str = (v: unknown, max: number): string => (typeof v === 'string' ? v.trim().slice(0, max) : '');

export function normaliseCode(v: unknown): string {
  return str(v, 20).toUpperCase().replace(/\s+/g, '');
}

export function loginEmailFor(code: string, domain: string): string {
  return `${code.toLowerCase()}@${domain.toLowerCase()}`;
}

export function validateCreateUser(body: unknown): { ok: true; data: CreateUserInput } | { ok: false; errors: string[] } {
  const errors: string[] = [];
  const b = (body && typeof body === 'object' ? body : {}) as Record<string, any>;
  const role = b.role === 'student' || b.role === 'teacher' ? (b.role as Role) : null;
  if (!role) errors.push('role');
  const code = normaliseCode(b.code);
  if (!CODE_RE.test(code)) errors.push('code');
  const displayName = str(b.displayName, 80);
  if (displayName.length < 2) errors.push('displayName');
  const email = str(b.email, 120).toLowerCase();
  if (email && !EMAIL_RE.test(email)) errors.push('email');
  const language = (LANGS as readonly string[]).includes(b.language) ? (b.language as 'en' | 'bn') : 'en';
  const out: CreateUserInput = { role: role ?? 'student', code, displayName, email, language };

  if (role === 'student') {
    const s = (b.student ?? {}) as Record<string, any>;
    const track = (TRACKS as readonly string[]).includes(s.track) ? s.track : null;
    if (!track) errors.push('student.track');
    const teacherId = str(s.teacherId, 128);
    if (!teacherId) errors.push('student.teacherId');
    const enrollmentDate = str(s.enrollmentDate, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(enrollmentDate)) errors.push('student.enrollmentDate');
    const timeZone = str(s.timeZone, 64) || 'UTC';
    if (!TZ_RE.test(timeZone) && timeZone !== 'UTC') errors.push('student.timeZone');
    out.student = { track: (track ?? 'qaida') as (typeof TRACKS)[number], level: str(s.level, 80), teacherId, enrollmentDate, country: str(s.country, 60), timeZone };
    const p = (b.private ?? {}) as Record<string, any>;
    const guardianEmail = str(p.guardianEmail, 120);
    if (guardianEmail && !EMAIL_RE.test(guardianEmail)) errors.push('private.guardianEmail');
    out.private = {
      legalName: str(p.legalName, 100), guardianName: str(p.guardianName, 100), guardianPhone: str(p.guardianPhone, 30),
      guardianEmail, address: str(p.address, 200), notes: str(p.notes, 500),
    };
  }
  if (role === 'teacher') {
    const t = (b.teacher ?? {}) as Record<string, any>;
    const allowed = ['attendance', 'progress', 'messaging', 'scheduling'];
    const resp = Array.isArray(t.responsibilities) ? t.responsibilities.filter((x: unknown) => typeof x === 'string' && allowed.includes(x)) : allowed;
    out.teacher = { responsibilities: resp };
    if (!email) errors.push('email'); // teachers need a real, recoverable email
  }
  return errors.length ? { ok: false, errors } : { ok: true, data: out };
}

// 14 chars, no look-alike characters, cryptographically random.
export function generateTempPassword(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
  let out = '';
  for (let i = 0; i < 14; i++) out += chars[randomInt(chars.length)];
  return out;
}

export function isStatus(v: unknown): v is (typeof STATUSES)[number] {
  return typeof v === 'string' && (STATUSES as readonly string[]).includes(v);
}

export function originAllowed(origin: string | null, allowed: string[]): boolean {
  if (!origin) return true; // same-origin navigations & server tools send no Origin
  return allowed.includes(origin);
}
