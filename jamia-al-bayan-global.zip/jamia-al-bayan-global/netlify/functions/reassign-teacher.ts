import { audit, db, FieldValue, handle, HttpError } from './_lib/admin';

const OWNED = ['goals', 'progress', 'progressNotes', 'attendance', 'assignments'] as const;

export default async (req: Request) =>
  handle(req, async (principalUid, body) => {
    const studentId = typeof body?.studentId === 'string' ? body.studentId : '';
    const teacherId = typeof body?.teacherId === 'string' ? body.teacherId : '';
    if (!studentId || !teacherId) throw new HttpError(400, 'validation_failed');
    const firestore = db();
    const [student, teacher] = await Promise.all([firestore.doc(`students/${studentId}`).get(), firestore.doc(`teachers/${teacherId}`).get()]);
    if (!student.exists) throw new HttpError(404, 'student_not_found');
    if (!teacher.exists || teacher.data()?.status !== 'active') throw new HttpError(400, 'teacher_not_active');
    const oldTeacherId = student.data()!.teacherId as string;
    if (oldTeacherId === teacherId) return { ok: true, moved: 0 };

    // Current teacher owns the student's history so they can teach with full context;
    // the previous teacher immediately loses access. createdBy is never changed (audit trail stays true).
    let moved = 0;
    const refs = [] as FirebaseFirestore.DocumentReference[];
    for (const c of OWNED) {
      const q = await firestore.collection(c).where('studentId', '==', studentId).get();
      q.docs.forEach((d) => refs.push(d.ref));
    }
    const classes = await firestore.collection('classes').where('studentIds', 'array-contains', studentId).where('status', '==', 'scheduled').get();
    classes.docs.filter((d) => (d.data().studentIds as string[]).length === 1).forEach((d) => refs.push(d.ref));
    for (let i = 0; i < refs.length; i += 400) {
      const batch = firestore.batch();
      refs.slice(i, i + 400).forEach((r) => batch.update(r, { teacherId }));
      await batch.commit(); moved += Math.min(400, refs.length - i);
    }
    // Remove the previous teacher from the student's conversations (history stays with the student).
    const convs = await firestore.collection('conversations').where('studentId', '==', studentId).get();
    const cb = firestore.batch();
    convs.docs.forEach((d) => cb.update(d.ref, { participants: [studentId] }));
    cb.update(student.ref, { teacherId, teacherName: teacher.data()!.displayName, updatedAt: FieldValue.serverTimestamp() });
    await cb.commit();
    await audit(principalUid, 'student.reassign', studentId, { from: oldTeacherId, to: teacherId, records: moved });
    return { ok: true, moved };
  });
